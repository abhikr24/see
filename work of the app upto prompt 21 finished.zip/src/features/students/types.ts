import type { ID } from '@/core/contracts/models';
import { inr } from '@/lib/format';

export const PAGE_SIZE = 20;

export type SortKey = 'name' | 'roll' | 'dues' | 'attendance';
export type ChipKey = 'all' | 'overdue' | `batch:${string}`;

export interface StudentRow {
  id: ID;
  fullName: string;
  photoUrl: string | null;
  batchId: ID | null;
  batchName: string;
  roll: number | null;
  monthlyFee: number;
  due: number;
  absentToday: boolean;
  attendancePercent: number | null;
  parentName: string | null;
  parentPhone: string | null;
}

export interface AdmitDraft {
  fullName: string;
  batchId: ID | null;
  roll: string;
  parentName: string;
  parentPhone: string;
  monthlyFee: string;
  photoUri: string | null;
}

export interface AdmitErrors {
  fullName?: string;
  batchId?: string;
  roll?: string;
  parentPhone?: string;
  monthlyFee?: string;
}

export const EMPTY_DRAFT: AdmitDraft = {
  fullName: '',
  batchId: null,
  roll: '',
  parentName: '',
  parentPhone: '',
  monthlyFee: '',
  photoUri: null,
};

export function rowSubtitle(row: StudentRow): string {
  const batch = row.batchName || 'No batch';
  const roll = row.roll == null ? 'Roll \u2014' : `Roll ${row.roll}`;
  return `${batch} \u00b7 ${roll} \u00b7 ${inr(row.monthlyFee)} monthly`;
}

export function dueLabel(due: number): string {
  return due > 0 ? `${inr(due)} due` : 'Paid';
}

export function summaryLine(count: number, dues: number): string {
  const students = count === 1 ? '1 student' : `${count} students`;
  const withDues = dues === 1 ? '1 with dues' : `${dues} with dues`;
  return `${students} \u00b7 ${withDues}`;
}

function haystack(row: StudentRow): string {
  return [row.fullName, row.batchName, row.roll == null ? '' : String(row.roll), row.parentName ?? '', row.parentPhone ?? '']
    .join(' ')
    .toLowerCase();
}

export function matchesSearch(row: StudentRow, search: string): boolean {
  const q = search.trim().toLowerCase();
  if (!q) return true;
  return haystack(row).includes(q);
}

export function matchesChip(row: StudentRow, chip: ChipKey): boolean {
  if (chip === 'all') return true;
  if (chip === 'overdue') return row.due > 0;
  return row.batchId === chip.slice('batch:'.length);
}

function compare(a: StudentRow, b: StudentRow, sort: SortKey): number {
  if (sort === 'name') return a.fullName.localeCompare(b.fullName);
  if (sort === 'roll') return (a.roll ?? 1e9) - (b.roll ?? 1e9) || a.fullName.localeCompare(b.fullName);
  if (sort === 'dues') return b.due - a.due || a.fullName.localeCompare(b.fullName);
  const ap = a.attendancePercent ?? 101;
  const bp = b.attendancePercent ?? 101;
  return ap - bp || a.fullName.localeCompare(b.fullName);
}

/** Chip first, then search, then sort. Chip counts stay on the unsearched set. */
export function applyRoster(rows: StudentRow[], chip: ChipKey, search: string, sort: SortKey): StudentRow[] {
  return rows
    .filter((row) => matchesChip(row, chip) && matchesSearch(row, search))
    .sort((a, b) => compare(a, b, sort));
}

export function duesCount(rows: StudentRow[]): number {
  return rows.reduce((n, row) => n + (row.due > 0 ? 1 : 0), 0);
}

export function suggestMonthlyFee(batchId: ID, rows: StudentRow[]): number {
  const fees = rows
    .filter((row) => row.batchId === batchId && row.monthlyFee > 0)
    .map((row) => row.monthlyFee)
    .sort((a, b) => a - b);
  if (!fees.length) return 1500;
  return fees[Math.floor(fees.length / 2)] ?? 1500;
}

export function validateDraft(draft: AdmitDraft, rows: StudentRow[]): AdmitErrors {
  const errors: AdmitErrors = {};
  if (draft.fullName.trim().length < 2) errors.fullName = 'Name must be at least 2 characters';
  if (!draft.batchId) errors.batchId = 'Choose a batch';
  const rollText = draft.roll.trim();
  const roll = Number(rollText);
  if (!/^\d+$/.test(rollText) || !Number.isInteger(roll) || roll < 1) {
    errors.roll = 'Enter a roll number';
  } else if (draft.batchId && rows.some((row) => row.batchId === draft.batchId && row.roll === roll)) {
    errors.roll = 'That roll is already used in this batch';
  }
  if (!/^\d{10}$/.test(draft.parentPhone)) errors.parentPhone = 'Phone must be exactly 10 digits';
  const fee = Number(draft.monthlyFee);
  if (draft.monthlyFee.trim() === '' || !Number.isFinite(fee) || fee < 0) {
    errors.monthlyFee = 'Enter the monthly fee';
  }
  return errors;
}

/** Five fields the photo ring tracks: name, batch, roll, phone, monthly fee. */
export function ringFilled(draft: AdmitDraft): number {
  const checks = [
    draft.fullName.trim().length >= 2,
    Boolean(draft.batchId),
    /^\d+$/.test(draft.roll.trim()),
    /^\d{10}$/.test(draft.parentPhone),
    draft.monthlyFee.trim() !== '' && Number(draft.monthlyFee) >= 0,
  ];
  return checks.filter(Boolean).length;
}

export function isPlanLimit(error: { message?: string; details?: Record<string, unknown> } | null | undefined): boolean {
  if (!error) return false;
  if (error.message === 'plan_limit') return true;
  return error.details?.reason === 'plan_limit';
}

export function planCapOf(details: Record<string, unknown> | undefined): { cap: number | null; used: number | null } {
  const cap = typeof details?.cap === 'number' ? details.cap : null;
  const used = typeof details?.used === 'number' ? details.used : cap;
  return { cap, used };
}
