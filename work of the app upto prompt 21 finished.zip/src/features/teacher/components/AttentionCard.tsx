import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Text } from '@/components/ui';
import { C, R } from '@/lib/theme';
import type { TeacherLink } from '../links';
import type { AttentionView } from '../model';

const BAR = 4;

export interface AttentionCardProps {
  item: AttentionView;
  onOpen: (link: TeacherLink) => void;
}

/** "Needs attention": submissions waiting to be graded. The saffron bar is this screen's one spotlight. */
export function AttentionCard({ item, onOpen }: AttentionCardProps) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${item.title}. ${item.detail}`}
      onPress={() => onOpen(item.link)}
      style={({ pressed }) => ({
        flexDirection: 'row',
        alignItems: 'stretch',
        backgroundColor: C.surface,
        borderRadius: R.btn,
        borderWidth: 1,
        borderColor: C.hairline,
        overflow: 'hidden',
        opacity: pressed ? 0.85 : 1,
      })}
    >
      <View style={{ width: BAR, backgroundColor: C.accent }} />
      <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 14, paddingHorizontal: 14 }}>
        <View style={{ flex: 1 }}>
          <Text variant="body" weight={700} tabular>
            {item.title}
          </Text>
          <Text variant="caption" c={C.secondary} numberOfLines={2} style={{ marginTop: 2 }}>
            {item.detail}
          </Text>
        </View>
        <Ionicons name="chevron-forward" size={18} color={C.muted} />
      </View>
    </Pressable>
  );
}
