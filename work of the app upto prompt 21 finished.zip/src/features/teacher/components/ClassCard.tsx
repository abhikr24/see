import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { ProgressBar, Text } from '@/components/ui';
import { subjectTint } from '@/lib/subject-tint';
import { C, LAYOUT, R } from '@/lib/theme';
import type { TeacherLink } from '../links';
import type { ClassCardView, IconName } from '../model';

export interface ClassCardProps {
  card: ClassCardView;
  onOpen: (link: TeacherLink) => void;
}

function MetaLine({ icon, text }: { icon: IconName; text: string }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
      <Ionicons name={icon} size={15} color={C.muted} />
      <Text variant="caption" c={C.secondary} tabular numberOfLines={1} style={{ flex: 1 }}>
        {text}
      </Text>
    </View>
  );
}

function OutlineButton({
  label,
  icon,
  a11y,
  onPress,
}: {
  label: string;
  icon: IconName;
  a11y: string;
  onPress: () => void;
}) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={a11y}
      onPress={onPress}
      style={({ pressed }) => ({
        flex: 1,
        height: LAYOUT.hit,
        borderRadius: R.btn,
        borderWidth: 1,
        borderColor: C.navyPale,
        backgroundColor: pressed ? C.navySoft : C.surface,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 6,
      })}
    >
      <Ionicons name={icon} size={16} color={C.primary} />
      <Text weight={600} c={C.primary} style={{ fontSize: 14 }}>
        {label}
      </Text>
    </Pressable>
  );
}

/**
 * One of the teacher's own classes: subject tint, name, schedule, room, the
 * attendance bar with its percentage, the amber "submissions pending" pill and
 * the two outlined actions. Depth is one hairline; the percentage is the number.
 */
export function ClassCard({ card, onOpen }: ClassCardProps) {
  const tint = subjectTint(card.subject);
  return (
    <View
      style={{
        backgroundColor: C.surface,
        borderRadius: R.card,
        borderWidth: 1,
        borderColor: C.hairline,
        padding: LAYOUT.cardPad,
        gap: 14,
      }}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <View
          style={{
            width: 44,
            height: 44,
            borderRadius: R.field,
            backgroundColor: tint.bg,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Ionicons name={tint.icon} size={22} color={tint.fg} />
        </View>
        <View style={{ flex: 1 }}>
          <Text variant="title" numberOfLines={1}>
            {card.name}
          </Text>
          <Text variant="caption" c={C.secondary} numberOfLines={1} style={{ marginTop: 2 }}>
            {card.subject}
          </Text>
        </View>
      </View>

      {card.pendingLabel ? (
        <View
          style={{
            alignSelf: 'flex-start',
            flexDirection: 'row',
            alignItems: 'center',
            gap: 6,
            paddingHorizontal: 10,
            paddingVertical: 5,
            borderRadius: R.chip,
            backgroundColor: C.warningSoft,
          }}
        >
          <Ionicons name="document-text-outline" size={13} color={C.duesInk} />
          <Text weight={600} tabular c={C.duesInk} style={{ fontSize: 12 }}>
            {card.pendingLabel}
          </Text>
        </View>
      ) : null}

      <View style={{ gap: 8 }}>
        <MetaLine icon="time-outline" text={card.schedule} />
        <MetaLine icon="location-outline" text={card.place} />
      </View>

      <View style={{ gap: 8 }}>
        <View style={{ flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between' }}>
          <Text variant="caption" c={C.secondary}>
            Attendance
          </Text>
          <Text weight={800} tabular style={{ fontSize: 17 }}>
            {card.attendanceLabel}
          </Text>
        </View>
        <ProgressBar value={card.attendanceValue ?? 0} tone="teal" height={6} />
      </View>

      <View style={{ flexDirection: 'row', gap: 10 }}>
        <OutlineButton
          label="Attendance"
          icon="checkbox-outline"
          a11y={`Attendance for ${card.name}`}
          onPress={() => onOpen(card.attendanceLink)}
        />
        <OutlineButton
          label="Homework"
          icon="book-outline"
          a11y={`Homework for ${card.name}`}
          onPress={() => onOpen(card.homeworkLink)}
        />
      </View>
    </View>
  );
}
