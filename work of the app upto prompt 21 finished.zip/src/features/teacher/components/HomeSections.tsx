import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Card, EmptyState, ErrorState, Text } from '@/components/ui';
import { QuickActions } from '@/features/dashboard/components/QuickActions';
import { C, R, S } from '@/lib/theme';
import type { TeacherHomeView } from '../hooks/useTeacherHome';
import type { TeacherLink } from '../links';
import type { AlertRowView } from '../model';
import { AttentionCard } from './AttentionCard';
import { HomeSkeleton } from './HomeSkeleton';
import { StudentAlertsCard } from './StudentAlertsCard';
import { TeacherHero } from './TeacherHero';

function Section({ title, children }: { title: string; children?: React.ReactNode }) {
  return (
    <View style={{ gap: S.md }}>
      <Text variant="title">{title}</Text>
      {children}
    </View>
  );
}

/** Shown above stale numbers when a refresh failed, so they are never mistaken for current. */
function StaleNotice({ message }: { message: string }) {
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        paddingVertical: 12,
        paddingHorizontal: 14,
        borderRadius: R.btn,
        backgroundColor: C.dangerSoft,
      }}
    >
      <Ionicons name="cloud-offline-outline" size={18} color={C.danger} />
      <Text variant="caption" c={C.danger} weight={600} style={{ flex: 1 }}>
        Could not refresh. This is the last day we loaded. {message}
      </Text>
    </View>
  );
}

export interface HomeSectionProps {
  view: TeacherHomeView;
  onOpen: (link: TeacherLink) => void;
}

/**
 * Everything above the schedule rows. One of four shapes, chosen by
 * `view.status`: skeleton, error with retry, "no classes assigned yet", or the
 * hero with its two numbers and the schedule's title.
 */
export function HomeHeader({ view, onOpen }: HomeSectionProps) {
  if (view.status === 'loading') return <HomeSkeleton />;

  if (view.status === 'error') {
    return (
      <Card flat>
        <ErrorState
          title="Could not load your day"
          message={view.errorMessage ?? 'Something went wrong.'}
          onRetry={() => void view.refresh()}
        />
      </Card>
    );
  }

  if (view.status === 'empty') {
    return (
      <View style={{ gap: S.xxl }}>
        <TeacherHero hero={view.hero} onOpen={onOpen} />
        <Card flat>
          <EmptyState
            icon="library-outline"
            title="No classes assigned yet"
            text="When the institute makes you the teacher of a batch, your schedule and classes show up here."
          />
        </Card>
      </View>
    );
  }

  return (
    <View style={{ gap: S.xxl, paddingBottom: S.md }}>
      <TeacherHero hero={view.hero} stats={view.stats} onOpen={onOpen} />
      {view.errorMessage ? <StaleNotice message={view.errorMessage} /> : null}
      <Section title="Today's schedule" />
    </View>
  );
}

/** Everything below the schedule rows: needs attention, student alerts, quick actions. */
export function HomeFooter({
  view,
  onOpen,
  onViewStudent,
}: HomeSectionProps & { onViewStudent: (row: AlertRowView) => void }) {
  const showAlerts = view.alerts.rows.length > 0 || view.alerts.errorMessage !== null;
  return (
    <View style={{ gap: S.xxl, paddingTop: S.xxl }}>
      {view.attention ? (
        <Section title="Needs attention">
          <AttentionCard item={view.attention} onOpen={onOpen} />
        </Section>
      ) : null}
      {showAlerts ? (
        <Section title="Student alerts">
          <StudentAlertsCard alerts={view.alerts} onView={onViewStudent} />
        </Section>
      ) : null}
      <Section title="Quick actions">
        <QuickActions actions={view.quickActions} onOpen={onOpen} />
      </Section>
    </View>
  );
}
