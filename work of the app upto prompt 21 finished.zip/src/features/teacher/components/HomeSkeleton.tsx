import React from 'react';
import { View } from 'react-native';

import { Skeleton } from '@/components/ui';
import { C, R, S } from '@/lib/theme';
import { SCHEDULE_ROW_HEIGHT } from './ScheduleRow';

/** First-load placeholder, laid out like the real home so nothing jumps when the numbers land. */
export function HomeSkeleton() {
  return (
    <View accessibilityLabel="Loading your day" style={{ gap: S.xxl }}>
      <View>
        <Skeleton h={148} r={24} />
        <View
          style={{
            flexDirection: 'row',
            marginTop: -22,
            marginHorizontal: 12,
            paddingVertical: 16,
            borderRadius: R.card,
            borderWidth: 1,
            borderColor: C.hairline,
            backgroundColor: C.surface,
          }}
        >
          {[0, 1].map((column) => (
            <View key={column} style={{ flex: 1, alignItems: 'center', gap: 10 }}>
              <Skeleton h={28} w={48} />
              <Skeleton h={10} w={96} />
            </View>
          ))}
        </View>
      </View>

      <View style={{ gap: S.md }}>
        <Skeleton h={16} w={140} />
        <Skeleton h={SCHEDULE_ROW_HEIGHT} r={R.card} />
        <Skeleton h={SCHEDULE_ROW_HEIGHT} r={R.card} />
      </View>

      <View style={{ gap: S.md }}>
        <Skeleton h={16} w={120} />
        <View style={{ flexDirection: 'row' }}>
          {[0, 1, 2, 3].map((square) => (
            <View key={square} style={{ flex: 1, alignItems: 'center', gap: 8 }}>
              <Skeleton h={56} w={56} r={R.btn} />
              <Skeleton h={10} w={48} />
            </View>
          ))}
        </View>
      </View>
    </View>
  );
}
