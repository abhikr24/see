import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Text } from '@/components/ui';
import { C, R } from '@/lib/theme';
import type { TeacherLink } from '../links';
import type { ScheduleRowView } from '../model';

export const SCHEDULE_ROW_HEIGHT = 72;
const CHIP = 48;

/** Rounds only the outer corners so consecutive rows read as one card split by hairlines. */
function edges(first: boolean, last: boolean) {
  return {
    borderTopLeftRadius: first ? R.card : 0,
    borderTopRightRadius: first ? R.card : 0,
    borderBottomLeftRadius: last ? R.card : 0,
    borderBottomRightRadius: last ? R.card : 0,
    borderTopWidth: 1,
    borderBottomWidth: last ? 1 : 0,
  };
}

export interface ScheduleRowProps {
  row: ScheduleRowView;
  first: boolean;
  last: boolean;
  onOpen: (link: TeacherLink) => void;
}

/**
 * One 72pt period: navy time chip · subject and batch · room and student count ·
 * the Attendance button, which opens Take Attendance with this batch, today's
 * date and this period prefilled. A period already marked shows a teal check.
 */
export function ScheduleRow({ row, first, last, onOpen }: ScheduleRowProps) {
  return (
    <View
      style={{
        height: SCHEDULE_ROW_HEIGHT,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        paddingHorizontal: 12,
        backgroundColor: C.surface,
        borderColor: C.hairline,
        borderLeftWidth: 1,
        borderRightWidth: 1,
        ...edges(first, last),
      }}
    >
      <View
        style={{
          width: CHIP,
          height: CHIP,
          borderRadius: R.field,
          backgroundColor: C.primary,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Text c={C.surface} weight={700} tabular numberOfLines={1} style={{ fontSize: 14, lineHeight: 18 }}>
          {row.clock}
        </Text>
        <Text c={C.surface} weight={600} style={{ fontSize: 10, lineHeight: 12, opacity: 0.7, letterSpacing: 0.5 }}>
          {row.meridiem}
        </Text>
      </View>

      {/* Subject and batch share a line when it fits; on a narrow phone the batch drops below, never cut off. */}
      <View accessibilityLabel={`${row.title}. ${row.meta}`} style={{ flex: 1 }}>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', alignItems: 'baseline', columnGap: 6 }}>
          {row.subject ? (
            <Text variant="body" weight={600} numberOfLines={1} style={{ lineHeight: 19 }}>
              {row.subject}
            </Text>
          ) : null}
          <Text variant="body" weight={row.subject ? 500 : 600} c={row.subject ? C.secondary : C.ink} numberOfLines={1} style={{ lineHeight: 19 }}>
            {row.batchName}
          </Text>
        </View>
        <Text variant="caption" c={C.secondary} tabular numberOfLines={1} style={{ marginTop: 1 }}>
          {row.meta}
        </Text>
      </View>

      <Pressable
        accessibilityRole="button"
        accessibilityLabel={
          row.marked ? `Attendance for ${row.batchName}, already marked` : `Take attendance for ${row.batchName}`
        }
        onPress={() => onOpen(row.link)}
        hitSlop={6}
        style={({ pressed }) => ({
          height: 36,
          paddingHorizontal: 12,
          borderRadius: R.chip,
          flexDirection: 'row',
          alignItems: 'center',
          gap: 4,
          borderWidth: 1,
          borderColor: row.marked ? C.hairline : C.primary,
          backgroundColor: pressed ? C.navySoft : C.surface,
        })}
      >
        {row.marked ? <Ionicons name="checkmark-done" size={14} color={C.teal} /> : null}
        <Text weight={600} c={C.primary} style={{ fontSize: 13 }}>
          Attendance
        </Text>
      </Pressable>
    </View>
  );
}

/** The teacher has classes, but none is on the timetable for today. */
export function NoClassesToday() {
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 10,
        paddingVertical: 16,
        paddingHorizontal: 16,
        borderRadius: R.btn,
        borderWidth: 1,
        borderColor: C.hairline,
        backgroundColor: C.surface,
      }}
    >
      <Ionicons name="calendar-outline" size={20} color={C.muted} />
      <Text variant="body" c={C.secondary} style={{ flex: 1 }}>
        No classes on your timetable today.
      </Text>
    </View>
  );
}
