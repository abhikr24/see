import React from 'react';
import { View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Avatar, Button, Sheet, Text } from '@/components/ui';
import type { FallingSignal, FallingStudent } from '@/core/contracts/models';
import { C, R } from '@/lib/theme';
import { signalFigures, studentLine } from '../model';

export interface StudentAlertSheetProps {
  /** null keeps the sheet closed. */
  student: FallingStudent | null;
  onClose: () => void;
  /** Opens Take Attendance for the student's batch. */
  onOpenAttendance: (student: FallingStudent) => void;
}

const LABEL: Record<FallingSignal['kind'], string> = { attendance: 'Attendance', marks: 'Marks' };

function Signal({ signal }: { signal: FallingSignal }) {
  const figures = signalFigures(signal);
  return (
    <View style={{ borderRadius: R.btn, borderWidth: 1, borderColor: C.hairline, padding: 14, gap: 6 }}>
      <Text variant="label" c={C.muted}>
        {LABEL[signal.kind]}
      </Text>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <Text weight={800} tabular c={C.secondary} style={{ fontSize: 22, lineHeight: 28 }}>
          {figures.from}
        </Text>
        <Ionicons name="arrow-forward" size={16} color={C.muted} />
        <Text weight={800} tabular style={{ fontSize: 22, lineHeight: 28 }}>
          {figures.to}
        </Text>
        <Ionicons name="trending-down" size={18} color={C.warning} />
      </View>
      <Text variant="caption" c={C.secondary} tabular>
        {signal.detail}
      </Text>
    </View>
  );
}

/**
 * What "View" on a student alert opens: who it is, and the two numbers behind
 * each drop. It states what changed and never a judgement about the student.
 */
export function StudentAlertSheet({ student, onClose, onOpenAttendance }: StudentAlertSheetProps) {
  return (
    <Sheet visible={student !== null} onClose={onClose} snapPoints={['62%', '88%']}>
      {student ? (
        <View style={{ gap: 14 }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
            <Avatar name={student.fullName} uri={student.photoUrl} size={48} />
            <View style={{ flex: 1 }}>
              <Text variant="title" numberOfLines={1}>
                {student.fullName}
              </Text>
              <Text variant="caption" c={C.secondary} tabular style={{ marginTop: 2 }}>
                {studentLine(student)}
              </Text>
            </View>
          </View>
          {student.signals.map((signal) => (
            <Signal key={signal.kind} signal={signal} />
          ))}
          <Button
            title={`Open attendance for ${student.batchName}`}
            icon="checkbox-outline"
            size="md"
            onPress={() => onOpenAttendance(student)}
          />
        </View>
      ) : null}
    </Sheet>
  );
}
