import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Avatar, Text } from '@/components/ui';
import { C, R } from '@/lib/theme';
import type { AlertsView } from '../hooks/useTeacherHome';
import type { AlertRowView } from '../model';

/** Rows shown before the rest fold into one "and N more" line. */
const MAX_ROWS = 4;

export interface StudentAlertsCardProps {
  alerts: AlertsView;
  onView: (row: AlertRowView) => void;
}

function AlertRow({ row, first, onView }: { row: AlertRowView; first: boolean; onView: (row: AlertRowView) => void }) {
  return (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        paddingVertical: 12,
        paddingHorizontal: 14,
        borderTopWidth: first ? 0 : 1,
        borderTopColor: C.hairline,
      }}
    >
      <Avatar name={row.name} uri={row.photoUrl} size={36} />
      <View style={{ flex: 1 }}>
        <Text variant="body" weight={600} numberOfLines={1}>
          {row.name}
        </Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 2 }}>
          <Ionicons name="trending-down" size={14} color={C.warning} />
          <Text variant="caption" c={C.secondary} tabular numberOfLines={1} style={{ flex: 1 }}>
            {row.reason}
          </Text>
        </View>
      </View>
      <Pressable
        accessibilityRole="link"
        accessibilityLabel={`View ${row.name}`}
        onPress={() => onView(row)}
        hitSlop={10}
        style={({ pressed }) => ({ paddingVertical: 6, paddingLeft: 6, opacity: pressed ? 0.6 : 1 })}
      >
        <Text variant="caption" weight={700} c={C.primary}>
          View
        </Text>
      </Pressable>
    </View>
  );
}

/**
 * "Student alerts": students in this teacher's own batches whose attendance or
 * marks are falling, each with one line of why. Renders nothing when nobody is
 * falling; says so plainly when the check itself could not run.
 */
export function StudentAlertsCard({ alerts, onView }: StudentAlertsCardProps) {
  if (alerts.errorMessage) {
    return (
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 10,
          paddingVertical: 12,
          paddingHorizontal: 14,
          borderRadius: R.btn,
          borderWidth: 1,
          borderColor: C.hairline,
          backgroundColor: C.surface,
        }}
      >
        <Ionicons name="cloud-offline-outline" size={18} color={C.muted} />
        <Text variant="caption" c={C.secondary} style={{ flex: 1 }}>
          Could not check student alerts. {alerts.errorMessage}
        </Text>
        <Pressable accessibilityRole="button" onPress={alerts.retry} hitSlop={10}>
          <Text variant="caption" weight={700} c={C.primary}>
            Retry
          </Text>
        </Pressable>
      </View>
    );
  }
  if (alerts.rows.length === 0) return null;

  const shown = alerts.rows.slice(0, MAX_ROWS);
  const hidden = alerts.rows.length - shown.length;
  return (
    <View
      style={{
        backgroundColor: C.surface,
        borderRadius: R.card,
        borderWidth: 1,
        borderColor: C.hairline,
        overflow: 'hidden',
      }}
    >
      {shown.map((row, index) => (
        <AlertRow key={row.key} row={row} first={index === 0} onView={onView} />
      ))}
      {hidden > 0 ? (
        <View style={{ paddingVertical: 10, paddingHorizontal: 14, borderTopWidth: 1, borderTopColor: C.hairline }}>
          <Text variant="caption" c={C.muted} tabular>
            and {hidden} more {hidden === 1 ? 'student' : 'students'}
          </Text>
        </View>
      ) : null}
    </View>
  );
}
