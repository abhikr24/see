import React from 'react';
import { Pressable, View } from 'react-native';

import { Avatar, GradientHeader, OverlapCard, Text } from '@/components/ui';
import { C } from '@/lib/theme';
import type { HeroView } from '../hooks/useTeacherHome';
import type { TeacherLink } from '../links';
import type { StatView } from '../model';

const HERO_RADIUS = 24;
const HERO_PAD = 20;
/** How far the stat card rides up over the hero (OverlapCard's own negative margin). */
const OVERLAP = 22;

export interface TeacherHeroProps {
  hero: HeroView;
  /** Omit to show the hero on its own (no classes assigned yet). */
  stats?: StatView[];
  onOpen: (link: TeacherLink) => void;
}

function Stat({ stat, onOpen }: { stat: StatView; onOpen: (link: TeacherLink) => void }) {
  const body = (
    <>
      <Text weight={800} tabular numberOfLines={1} style={{ fontSize: 28, lineHeight: 34 }}>
        {stat.value}
      </Text>
      <Text variant="label" c={C.muted} numberOfLines={2} style={{ textAlign: 'center', marginTop: 4 }}>
        {stat.label}
      </Text>
    </>
  );
  const frame = { flex: 1, alignItems: 'center' as const, paddingHorizontal: 8 };
  const link = stat.link;
  if (!link) return <View style={frame}>{body}</View>;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`${stat.value} ${stat.label}`}
      onPress={() => onOpen(link)}
      style={({ pressed }) => ({ ...frame, opacity: pressed ? 0.6 : 1 })}
    >
      {body}
    </Pressable>
  );
}

/** Navy hero (date, greeting, the day in one line, avatar) with two numbers on a white card over its bottom edge. */
export function TeacherHero({ hero, stats, onOpen }: TeacherHeroProps) {
  return (
    <View>
      <GradientHeader
        style={{
          borderRadius: HERO_RADIUS,
          padding: HERO_PAD,
          paddingBottom: stats ? HERO_PAD + OVERLAP : HERO_PAD,
        }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 12 }}>
          <View style={{ flex: 1 }}>
            <Text variant="caption" c={C.surface} numberOfLines={1} style={{ opacity: 0.7 }}>
              {hero.date}
            </Text>
            <Text c={C.surface} weight={800} numberOfLines={2} style={{ fontSize: 24, lineHeight: 30, marginTop: 4 }}>
              {hero.greeting}
            </Text>
            {hero.meta ? (
              <Text variant="caption" c={C.surface} tabular numberOfLines={1} style={{ opacity: 0.75, marginTop: 6 }}>
                {hero.meta}
              </Text>
            ) : null}
          </View>
          <Avatar name={hero.userName} uri={hero.avatarUrl} size={40} />
        </View>
      </GradientHeader>

      {stats ? (
        <OverlapCard style={{ paddingHorizontal: 6, paddingVertical: 16 }}>
          <View style={{ flexDirection: 'row', alignItems: 'stretch' }}>
            {stats.map((stat, index) => (
              <React.Fragment key={stat.key}>
                {index > 0 ? <View style={{ width: 1, backgroundColor: C.hairline }} /> : null}
                <Stat stat={stat} onOpen={onOpen} />
              </React.Fragment>
            ))}
          </View>
        </OverlapCard>
      ) : null}
    </View>
  );
}
