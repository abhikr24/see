import { useCallback, useMemo, useState } from 'react';

import { useMyClasses } from '@/core/backend';
import { todayIso } from '@/features/attendance/model';
import { classCardsOf, filterClasses, plural, type ClassCardView } from '../model';

export type MyClassesStatus = 'loading' | 'error' | 'empty' | 'no-match' | 'ready';

export interface MyClassesView {
  status: MyClassesStatus;
  cards: ClassCardView[];
  /** "2 classes", once known. */
  countLabel: string;
  query: string;
  setQuery: (text: string) => void;
  errorMessage: string | null;
  refreshing: boolean;
  refresh: () => Promise<void>;
}

/**
 * My Classes view model. The list is already the teacher's own: the backend
 * scopes `BatchRepo.listMyClasses` to the assigned teacher, so the search here
 * only narrows cards this teacher is allowed to see.
 */
export function useMyClassesView(): MyClassesView {
  const classes = useMyClasses();
  const [query, setQuery] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  const refetch = classes.refetch;
  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await refetch();
    } finally {
      setRefreshing(false);
    }
  }, [refetch]);

  const all = useMemo(() => (classes.data ? classCardsOf(classes.data, todayIso()) : []), [classes.data]);
  const cards = useMemo(() => filterClasses(all, query), [all, query]);

  let status: MyClassesStatus;
  if (!classes.data) status = classes.error && !classes.loading ? 'error' : 'loading';
  else if (all.length === 0) status = 'empty';
  else status = cards.length === 0 ? 'no-match' : 'ready';

  return {
    status,
    cards,
    countLabel: classes.data ? plural(all.length, 'class', 'classes') : '',
    query,
    setQuery,
    errorMessage: classes.error?.message ?? null,
    refreshing,
    refresh,
  };
}
