import { useCallback, useMemo, useState } from 'react';

import { useFallingStudents, useTeacherHome } from '@/core/backend';
import type { FallingStudent } from '@/core/contracts/models';
import { todayIso } from '@/features/attendance/model';
import { useSessionStore } from '@/store/session';
import { teacherLinks, type TeacherLink } from '../links';
import {
  alertRowsOf,
  attentionOf,
  dateLine,
  greeting,
  heroLine,
  quickActionsOf,
  scheduleRowsOf,
  statsOf,
  type AlertRowView,
  type AttentionView,
  type QuickActionView,
  type ScheduleRowView,
  type StatView,
} from '../model';

/** loading = first load only. A background refresh keeps the last numbers on screen. */
export type TeacherHomeStatus = 'loading' | 'error' | 'empty' | 'ready';

export interface HeroView {
  date: string;
  greeting: string;
  /** "3 classes · 2 homework due" once the numbers are known. */
  meta: string;
  userName: string;
  avatarUrl: string | null;
}

export interface AlertsView {
  rows: AlertRowView[];
  /** Set when the alert check itself failed; the rest of the home still stands. */
  errorMessage: string | null;
  retry: () => void;
}

export interface TeacherHomeView {
  status: TeacherHomeStatus;
  hero: HeroView;
  stats: StatView[];
  schedule: ScheduleRowView[];
  attention: AttentionView | null;
  alerts: AlertsView;
  quickActions: QuickActionView[];
  /** Take Attendance for a flagged student's batch, on the day the home was loaded for. */
  attendanceLinkFor: (student: FallingStudent) => TeacherLink;
  /** Set when a load failed. With `status: 'ready'` the numbers shown are the last good ones. */
  errorMessage: string | null;
  refreshing: boolean;
  refresh: () => Promise<void>;
}

/**
 * The teacher home's view model. `AnalyticsRepo.teacherHome` is the screen's
 * one loading state; the student alerts come from `ProgressPort` beside it and
 * fail on their own without taking the schedule down.
 */
export function useTeacherHomeView(): TeacherHomeView {
  const home = useTeacherHome();
  const falling = useFallingStudents();
  // Read the person through the session store, the same source the shell guards on.
  const profile = useSessionStore().user;
  const [refreshing, setRefreshing] = useState(false);

  const refetchHome = home.refetch;
  const refetchFalling = falling.refetch;
  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await Promise.all([refetchHome(), refetchFalling()]);
    } finally {
      setRefreshing(false);
    }
  }, [refetchHome, refetchFalling]);

  const data = home.data;
  const sections = useMemo(
    () => ({
      stats: data ? statsOf(data) : [],
      schedule: data ? scheduleRowsOf(data) : [],
      attention: data ? attentionOf(data) : null,
      quickActions: data ? quickActionsOf(data) : [],
    }),
    [data],
  );
  const alertRows = useMemo(() => (falling.data ? alertRowsOf(falling.data) : []), [falling.data]);
  const date = data?.date ?? null;
  const attendanceLinkFor = useCallback(
    (student: FallingStudent) => teacherLinks.attendance({ batchId: student.batchId, date: date ?? todayIso() }),
    [date],
  );

  const hero: HeroView = {
    date: data ? dateLine(data.date) : '',
    greeting: greeting(profile?.fullName, new Date().getHours()),
    meta: data ? heroLine(data) : '',
    userName: profile?.fullName ?? '',
    avatarUrl: profile?.avatarUrl ?? null,
  };

  let status: TeacherHomeStatus;
  if (data) status = data.classCount === 0 ? 'empty' : 'ready';
  else status = home.error && !home.loading ? 'error' : 'loading';

  return {
    status,
    hero,
    ...sections,
    alerts: {
      rows: alertRows,
      errorMessage: falling.error && !falling.data ? falling.error.message : null,
      retry: () => void refetchFalling(),
    },
    attendanceLinkFor,
    errorMessage: home.error?.message ?? null,
    refreshing,
    refresh,
  };
}
