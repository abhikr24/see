import type { Ionicons } from '@expo/vector-icons';

import type { FallingStudent, ISODate, TeacherClass, TeacherHome } from '@/core/contracts/models';
import { pct, timeShort } from '@/lib/format';
import { teacherLinks, type TeacherLink } from './links';

/**
 * The teacher screens' view models. Pure: every number arrives ready-made from
 * the repos (`AnalyticsRepo.teacherHome`, `BatchRepo.listMyClasses`,
 * `ProgressPort.listFallingStudents`). This file only words and formats them
 * and attaches where each tap goes. No screen does any of it itself.
 */

export type IconName = keyof typeof Ionicons.glyphMap;

export interface StatView {
  key: string;
  value: string;
  label: string;
  link?: TeacherLink;
}

export interface ScheduleRowView {
  key: string;
  /** "4:00" and "PM", split so the chip can stack them. */
  clock: string;
  meridiem: string;
  /** "Mathematics · Class 10-A", for screen readers and tests. The row shows the two parts side by side. */
  title: string;
  subject: string | null;
  /** "Room 1 · 12 students" */
  meta: string;
  marked: boolean;
  batchName: string;
  link: TeacherLink;
}

export interface AttentionView {
  title: string;
  detail: string;
  link: TeacherLink;
}

export interface AlertRowView {
  key: string;
  name: string;
  photoUrl: string | null;
  reason: string;
  student: FallingStudent;
}

export interface QuickActionView {
  key: string;
  label: string;
  icon: IconName;
  link: TeacherLink;
}

export interface ClassCardView {
  key: string;
  name: string;
  /** Names the card's tint too: the card looks the subject up in `subjectTint`. */
  subject: string;
  schedule: string;
  /** "Room 1 · 12 students" */
  place: string;
  /** null until a roll call exists: the bar stays empty and the label is a dash, never 0%. */
  attendanceValue: number | null;
  attendanceLabel: string;
  pendingLabel: string | null;
  attendanceLink: TeacherLink;
  homeworkLink: TeacherLink;
  /** Lower-cased text the header search matches against. */
  haystack: string;
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const DAYS_LONG = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December',
];

export const plural = (count: number, one: string, many: string): string => `${count} ${count === 1 ? one : many}`;

export function greetingFor(hour: number): string {
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

export function greeting(fullName: string | null | undefined, hour: number): string {
  const first = fullName?.trim().split(/\s+/)[0];
  return first ? `${greetingFor(hour)}, ${first}` : greetingFor(hour);
}

/** `2026-11-13` → `Friday, 13 November`. Built from the parts so no timezone can shift the day. */
export function dateLine(date: ISODate): string {
  const [year, month, day] = date.split('-').map(Number);
  const weekday = new Date(Date.UTC(year, month - 1, day)).getUTCDay();
  return `${DAYS_LONG[weekday]}, ${day} ${MONTHS[month - 1]}`;
}

/** "3 classes · 2 homework due" */
export function heroLine(home: TeacherHome): string {
  const classes = home.periods.length === 0 ? 'No classes today' : plural(home.periods.length, 'class', 'classes');
  return `${classes} · ${home.homeworkDue} homework due`;
}

export function statsOf(home: TeacherHome): StatView[] {
  return [
    { key: 'classes', value: String(home.periods.length), label: 'Classes today' },
    {
      key: 'grade',
      value: String(home.submissionsToGrade),
      label: 'Submissions to grade',
      link: home.submissionsToGrade > 0 ? teacherLinks.homework(home.pending[0]?.batchId) : undefined,
    },
  ];
}

export function scheduleRowsOf(home: TeacherHome): ScheduleRowView[] {
  return home.periods.map((period) => {
    const [clock, meridiem = ''] = timeShort(period.startsAt).split(' ');
    return {
      key: period.id,
      clock,
      meridiem,
      title: [period.subjectName, period.batchName].filter(Boolean).join(' · '),
      subject: period.subjectName,
      meta: [period.roomName, plural(period.studentCount, 'student', 'students')].filter(Boolean).join(' · '),
      marked: period.attendanceMarked,
      batchName: period.batchName,
      link: teacherLinks.attendance({
        batchId: period.batchId,
        date: home.date,
        period: period.period,
        subjectId: period.subjectId,
      }),
    };
  });
}

/** Only when something is waiting. Zero submissions never becomes a card. */
export function attentionOf(home: TeacherHome): AttentionView | null {
  const [first, ...rest] = home.pending;
  if (!first || home.submissionsToGrade === 0) return null;
  const more = rest.length > 0 ? ` and ${plural(rest.length, 'more set', 'more sets')}` : '';
  return {
    title: `${plural(home.submissionsToGrade, 'submission', 'submissions')} to grade`,
    detail: `${first.title} · ${first.batchName}${more}`,
    link: teacherLinks.homework(first.batchId),
  };
}

export function alertRowsOf(falling: FallingStudent[]): AlertRowView[] {
  return falling.map((student) => ({
    key: `${student.batchId}:${student.studentId}`,
    name: student.fullName,
    photoUrl: student.photoUrl,
    reason: student.signals[0].reason,
    student,
  }));
}

/** "Class 10-A · Roll 18" */
export function studentLine(student: FallingStudent): string {
  return student.rollNumber === null ? student.batchName : `${student.batchName} · Roll ${student.rollNumber}`;
}

/** "93% → 86%", whole numbers like every other percentage in the app. */
export function signalFigures(signal: { from: number; to: number }): { from: string; to: string } {
  return { from: pct(signal.from), to: pct(signal.to) };
}

/** The four shortcuts. Each carries the batch in session now (or next today), so the form opens prefilled. */
export function quickActionsOf(home: TeacherHome): QuickActionView[] {
  const batchId = home.currentBatchId;
  const period = home.periods.find((p) => p.batchId === batchId);
  const attendance = batchId
    ? teacherLinks.attendance({ batchId, date: home.date, period: period?.period, subjectId: period?.subjectId })
    : teacherLinks.classes();
  return [
    { key: 'attendance', label: 'Take attendance', icon: 'checkbox-outline', link: attendance },
    { key: 'homework', label: 'Assign homework', icon: 'book-outline', link: teacherLinks.assignHomework(batchId) },
    { key: 'marks', label: 'Enter marks', icon: 'create-outline', link: teacherLinks.enterMarks(batchId) },
    { key: 'material', label: 'Share material', icon: 'share-social-outline', link: teacherLinks.shareMaterial(batchId) },
  ];
}

/** `[1,2,3,4,5]` → "Mon – Fri"; `[1,3,5]` → "Mon, Wed, Fri". Monday first. */
export function daysLabel(days: readonly number[]): string {
  const ordered = [...new Set(days)].sort((a, b) => ((a + 6) % 7) - ((b + 6) % 7));
  if (ordered.length === 0) return 'No days set';
  if (ordered.length === 7) return 'Every day';
  const consecutive = ordered.every((day, i) => i === 0 || (day + 6) % 7 === ((ordered[i - 1] + 6) % 7) + 1);
  if (ordered.length >= 3 && consecutive) return `${DAYS[ordered[0]]} – ${DAYS[ordered[ordered.length - 1]]}`;
  return ordered.map((day) => DAYS[day]).join(', ');
}

function scheduleLabel(item: TeacherClass): string {
  const days = daysLabel(item.days);
  if (!item.startsAt) return days;
  const hours = item.endsAt ? `${timeShort(item.startsAt)} – ${timeShort(item.endsAt)}` : timeShort(item.startsAt);
  return `${days} · ${hours}`;
}

export function classCardsOf(classes: TeacherClass[], today: ISODate): ClassCardView[] {
  return classes.map((item) => {
    const subject = item.subjectName ?? 'General';
    const room = item.roomName ?? 'No room set';
    return {
      key: item.batchId,
      name: item.name,
      subject,
      schedule: scheduleLabel(item),
      place: `${room} · ${plural(item.studentCount, 'student', 'students')}`,
      attendanceValue: item.attendancePercent,
      attendanceLabel: item.attendancePercent === null ? '—' : pct(item.attendancePercent),
      pendingLabel:
        item.pendingSubmissions > 0
          ? `${plural(item.pendingSubmissions, 'submission', 'submissions')} pending`
          : null,
      attendanceLink: teacherLinks.attendance({ batchId: item.batchId, date: today, subjectId: item.subjectId }),
      homeworkLink: teacherLinks.homework(item.batchId),
      haystack: [item.name, subject, item.roomName ?? ''].join(' ').toLowerCase(),
    };
  });
}

/** Header search over the teacher's own cards: every word typed must appear in name, subject or room. */
export function filterClasses(cards: ClassCardView[], query: string): ClassCardView[] {
  const words = query.trim().toLowerCase().split(/\s+/).filter(Boolean);
  if (words.length === 0) return cards;
  return cards.filter((card) => words.every((word) => card.haystack.includes(word)));
}
