import React, { useCallback } from 'react';
import { FlatList, RefreshControl, View } from 'react-native';
import { router } from 'expo-router';

import { Card, EmptyState, ErrorState, SearchBar, Skeleton, Text } from '@/components/ui';
import { C, LAYOUT, R, S } from '@/lib/theme';
import { ClassCard } from '../components/ClassCard';
import { useMyClassesView } from '../hooks/useMyClasses';
import type { TeacherLink } from '../links';
import type { ClassCardView } from '../model';

/** Clears the floating tab bar the teacher shell draws over the bottom of every tab. */
const TAB_BAR_INSET = 136;

function CardSkeleton() {
  return (
    <View
      style={{
        backgroundColor: C.surface,
        borderRadius: R.card,
        borderWidth: 1,
        borderColor: C.hairline,
        padding: LAYOUT.cardPad,
        gap: 14,
      }}
    >
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
        <Skeleton h={44} w={44} r={R.field} />
        <View style={{ flex: 1, gap: 8 }}>
          <Skeleton h={14} w="50%" />
          <Skeleton h={10} w="30%" />
        </View>
      </View>
      <Skeleton h={10} w="70%" />
      <Skeleton h={10} w="45%" />
      <Skeleton h={6} r={6} />
      <View style={{ flexDirection: 'row', gap: 10 }}>
        <Skeleton h={LAYOUT.hit} w="48%" r={R.btn} />
        <Skeleton h={LAYOUT.hit} w="48%" r={R.btn} />
      </View>
    </View>
  );
}

/**
 * My Classes: the batches this teacher is the assigned teacher of, and no
 * others. Title with the header search, then one card per class. Layout only;
 * the list, its scoping and the search all arrive from `useMyClassesView`.
 */
export function MyClassesScreen() {
  const view = useMyClassesView();
  const open = useCallback((link: TeacherLink) => router.push(link as never), []);
  const searchable = view.status === 'ready' || view.status === 'no-match';

  return (
    <View style={{ flex: 1, backgroundColor: C.canvas }}>
      <View style={{ paddingHorizontal: LAYOUT.margin, paddingTop: 8, paddingBottom: S.md, gap: S.md }}>
        <View style={{ flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between', gap: 12 }}>
          <Text variant="h1" numberOfLines={1}>
            My classes
          </Text>
          {view.countLabel ? (
            <Text variant="caption" c={C.secondary} tabular>
              {view.countLabel}
            </Text>
          ) : null}
        </View>
        {searchable ? (
          <SearchBar
            compact
            value={view.query}
            onChangeText={view.setQuery}
            placeholder="Search by class, subject or room"
          />
        ) : null}
      </View>

      <FlatList<ClassCardView>
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: TAB_BAR_INSET, gap: 14 }}
        data={view.status === 'ready' ? view.cards : []}
        keyExtractor={(card) => card.key}
        renderItem={({ item }) => <ClassCard card={item} onOpen={open} />}
        keyboardShouldPersistTaps="handled"
        ListEmptyComponent={
          view.status === 'loading' ? (
            <View accessibilityLabel="Loading your classes" style={{ gap: 14 }}>
              <CardSkeleton />
              <CardSkeleton />
            </View>
          ) : view.status === 'error' ? (
            <Card flat>
              <ErrorState
                title="Could not load your classes"
                message={view.errorMessage ?? 'Something went wrong.'}
                onRetry={() => void view.refresh()}
              />
            </Card>
          ) : view.status === 'no-match' ? (
            <Card flat>
              <EmptyState
                icon="search-outline"
                title="No class matches"
                text={`Nothing in your classes matches “${view.query.trim()}”.`}
                actionLabel="Clear search"
                onAction={() => view.setQuery('')}
              />
            </Card>
          ) : (
            <Card flat>
              <EmptyState
                icon="library-outline"
                title="No classes assigned yet"
                text="When the institute makes you the teacher of a batch, it appears here."
              />
            </Card>
          )
        }
        refreshControl={
          <RefreshControl
            refreshing={view.refreshing}
            onRefresh={() => void view.refresh()}
            tintColor={C.primary}
            colors={[C.primary]}
          />
        }
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}
