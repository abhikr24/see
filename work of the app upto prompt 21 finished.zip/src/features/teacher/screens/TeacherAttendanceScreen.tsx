import React from 'react';
import { useLocalSearchParams } from 'expo-router';

import { takeParamsFromRoute, type TakeNav, type TakeRouteParams } from '@/features/attendance/links';
import { todayIso } from '@/features/attendance/model';
import { TakeAttendanceScreen } from '@/features/attendance/take';
import { teacherLinks } from '../links';

/**
 * Where Take Attendance sends a teacher. The monthly register and "Add a
 * student" are owner screens, so a teacher is not offered either.
 */
const TEACHER_TAKE_NAV: TakeNav = { home: teacherLinks.home().pathname, register: null, addStudent: null };

/**
 * Take Attendance (P13) for one of the teacher's own batches, opened by the
 * home schedule's and the class card's Attendance buttons with the batch,
 * date, period and subject prefilled.
 *
 * The screen never checks whose batch it is: `AttendanceRepo.openRoll` does.
 * Another teacher's batch id comes back `NOT_FOUND` and the screen shows
 * "Class not found", exactly as it would for an id that does not exist.
 */
export function TeacherAttendanceScreen() {
  const params = useLocalSearchParams<TakeRouteParams & { batchId: string }>();
  return <TakeAttendanceScreen {...takeParamsFromRoute(params, todayIso())} nav={TEACHER_TAKE_NAV} />;
}
