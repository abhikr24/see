import React, { useCallback, useState } from 'react';
import { FlatList, RefreshControl } from 'react-native';
import { router } from 'expo-router';

import type { FallingStudent } from '@/core/contracts/models';
import { C, LAYOUT } from '@/lib/theme';
import { HomeFooter, HomeHeader } from '../components/HomeSections';
import { NoClassesToday, ScheduleRow } from '../components/ScheduleRow';
import { StudentAlertSheet } from '../components/StudentAlertSheet';
import { useTeacherHomeView } from '../hooks/useTeacherHome';
import type { TeacherLink } from '../links';
import type { ScheduleRowView } from '../model';

/** Clears the floating tab bar the teacher shell draws over the bottom of every tab. */
const TAB_BAR_INSET = 136;

/**
 * Teacher home (shape A): the day in one glance, then today's own periods,
 * what is waiting to be graded, who is slipping, and four shortcuts. Layout
 * only: the numbers, wording and destinations all come from `useTeacherHomeView`.
 */
export function TeacherHomeScreen() {
  const view = useTeacherHomeView();
  const [viewing, setViewing] = useState<FallingStudent | null>(null);
  const ready = view.status === 'ready';
  const rows = ready ? view.schedule : [];

  const open = useCallback((link: TeacherLink) => router.push(link as never), []);

  return (
    <>
      <FlatList<ScheduleRowView>
        style={{ flex: 1, backgroundColor: C.canvas }}
        contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingTop: 8, paddingBottom: TAB_BAR_INSET }}
        data={rows}
        keyExtractor={(row) => row.key}
        renderItem={({ item, index }) => (
          <ScheduleRow row={item} first={index === 0} last={index === rows.length - 1} onOpen={open} />
        )}
        ListHeaderComponent={<HomeHeader view={view} onOpen={open} />}
        ListEmptyComponent={ready ? <NoClassesToday /> : null}
        ListFooterComponent={
          ready ? <HomeFooter view={view} onOpen={open} onViewStudent={(row) => setViewing(row.student)} /> : null
        }
        refreshControl={
          <RefreshControl
            refreshing={view.refreshing}
            onRefresh={() => void view.refresh()}
            tintColor={C.primary}
            colors={[C.primary]}
          />
        }
        showsVerticalScrollIndicator={false}
      />
      <StudentAlertSheet
        student={viewing}
        onClose={() => setViewing(null)}
        onOpenAttendance={(student) => {
          setViewing(null);
          open(view.attendanceLinkFor(student));
        }}
      />
    </>
  );
}
