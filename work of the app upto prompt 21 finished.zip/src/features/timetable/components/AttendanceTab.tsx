import React from 'react';
import { FlatList, Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import { EmptyState, ErrorState, ListSkeleton, Text } from '@/components/ui';
import { pct } from '@/lib/format';
import { C, LAYOUT, R } from '@/lib/theme';
import type { useDayAttendance } from '../hooks/useDayAttendance';
import { DAY_NAMES, type PeriodRowView } from '../model';

export interface AttendanceTabProps {
  rows: PeriodRowView[];
  day: number;
  attendance: ReturnType<typeof useDayAttendance>;
  bottomInset: number;
}

/**
 * Timetable › Attendance: one card per period on the selected day with the
 * register's state for that date — the count once saved, "Not marked" before —
 * and the button that opens Take Attendance with everything prefilled.
 */
export function AttendanceTab({ rows, day, attendance, bottomInset }: AttendanceTabProps) {
  if (attendance.loading) {
    return (
      <View style={{ paddingHorizontal: LAYOUT.margin }}>
        <ListSkeleton rows={4} h={84} />
      </View>
    );
  }
  if (attendance.error) {
    return <ErrorState title="Could not load attendance" message={attendance.error.message} onRetry={() => void attendance.refetch()} />;
  }
  return (
    <FlatList
      data={rows}
      keyExtractor={(row) => row.id}
      refreshing={false}
      onRefresh={() => void attendance.refetch()}
      contentContainerStyle={{ paddingHorizontal: LAYOUT.margin, paddingBottom: bottomInset, gap: 10 }}
      ListHeaderComponent={
        <Text variant="caption" c={C.secondary} style={{ marginBottom: 2 }}>
          Register for {attendance.dateLabel.toLowerCase() === 'today' ? 'today' : attendance.dateLabel}
        </Text>
      }
      ListEmptyComponent={
        <EmptyState icon="calendar-outline" title={`Nothing on ${DAY_NAMES[day]}`} text="No batch meets on this day, so there is no register to take." />
      }
      renderItem={({ item }) => {
        const state = attendance.forRow(item.id);
        const counts = state?.counts ?? null;
        const percent = counts && counts.total > 0 ? ((counts.present + counts.late) / counts.total) * 100 : null;
        return (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel={`${item.badge} ${item.subject}, ${counts ? `${counts.present} of ${counts.total} present` : 'not marked'}`}
            onPress={() => state && router.push(state.href as never)}
            style={({ pressed }) => ({
              padding: 16,
              borderRadius: R.card,
              backgroundColor: pressed ? C.track : C.surface,
              borderWidth: 1,
              borderColor: C.hairline,
              gap: 10,
            })}
          >
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <View style={{ flex: 1 }}>
                <Text weight={600} numberOfLines={1} style={{ fontSize: 15 }}>
                  {item.badge} · {item.subject}
                </Text>
                <Text variant="caption" c={C.muted}>
                  {item.range}
                </Text>
              </View>
              {counts ? (
                <Text tabular weight={800} style={{ fontSize: 22 }}>
                  {pct(percent)}
                </Text>
              ) : (
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, paddingHorizontal: 12, height: 34, borderRadius: R.chip, backgroundColor: C.primary }}>
                  <Ionicons name="checkbox-outline" size={15} color={C.surface} />
                  <Text weight={700} c={C.surface} style={{ fontSize: 13 }}>
                    Take
                  </Text>
                </View>
              )}
            </View>
            {counts ? (
              <View style={{ gap: 6 }}>
                <View style={{ flexDirection: 'row', height: 6, borderRadius: 3, overflow: 'hidden', backgroundColor: C.track }}>
                  <View style={{ flex: counts.present, backgroundColor: C.teal }} />
                  <View style={{ flex: counts.late, backgroundColor: C.warning }} />
                  <View style={{ flex: counts.absent, backgroundColor: C.danger }} />
                </View>
                <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                  <Text tabular variant="caption" c={C.secondary} style={{ flex: 1 }}>
                    <Text tabular variant="caption" weight={700} c={C.teal}>{counts.present} present</Text>
                    {'  ·  '}
                    <Text tabular variant="caption" weight={700} c={C.warning}>{counts.late} late</Text>
                    {'  ·  '}
                    <Text tabular variant="caption" weight={700} c={C.danger}>{counts.absent} absent</Text>
                  </Text>
                  <Text variant="caption" weight={700} c={C.primary}>
                    Edit
                  </Text>
                </View>
              </View>
            ) : (
              <Text variant="caption" c={C.muted}>
                Not marked yet
              </Text>
            )}
          </Pressable>
        );
      }}
    />
  );
}
