import React from 'react';
import { Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Button, Text } from '@/components/ui';
import { C, LAYOUT, R, SHADOW } from '@/lib/theme';
import { DAY_NAMES, type RoomClash, type TeacherClash } from '../model';

export interface ClashCardsProps {
  /** The clash to name: a blocking one when the save is held, else the first. */
  teacher: TeacherClash | null;
  blocking: boolean;
  room: RoomClash | null;
  onFix: (clash: TeacherClash) => void;
  onDismissRoom: (key: string) => void;
  /** Distance from the bottom of the screen (clears the floating tab bar). */
  bottom: number;
}

/**
 * The amber warning card at the bottom of the board.
 *
 * A teacher clash is hard: it names both batches and the teacher, and while it
 * sits on a day the owner just edited, the save is blocked — "Fix" jumps to
 * the two rows. A room clash is softer: a warning only, the change still
 * saves, and the card can be dismissed.
 */
export function ClashCards({ teacher, blocking, room, onFix, onDismissRoom, bottom }: ClashCardsProps) {
  if (!teacher && !room) return null;
  return (
    <View
      pointerEvents="box-none"
      style={{ position: 'absolute', left: LAYOUT.margin, right: LAYOUT.margin, bottom, gap: 10, zIndex: 20 }}
    >
      {room ? (
        <View
          style={{
            backgroundColor: C.surface,
            borderWidth: 1,
            borderColor: C.hairline,
            borderLeftWidth: 3,
            borderLeftColor: C.warning,
            borderRadius: R.card,
            padding: 12,
            flexDirection: 'row',
            gap: 10,
            ...SHADOW,
          }}
        >
          <Ionicons name="business-outline" size={18} color={C.warning} style={{ marginTop: 2 }} />
          <View style={{ flex: 1, gap: 2 }}>
            <Text variant="label" c={C.duesInk}>
              ROOM CLASH · WARNING ONLY
            </Text>
            <Text variant="caption" c={C.secondary} style={{ lineHeight: 17 }}>
              {`${room.roomName} is booked twice on ${DAY_NAMES[room.dayOfWeek]} — ${room.a.batchName} (${room.a.range}) and ${room.b.batchName} (${room.b.range}). Saved anyway.`}
            </Text>
          </View>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Dismiss room warning"
            onPress={() => onDismissRoom(room.key)}
            hitSlop={8}
            style={{ width: 28, height: 28, alignItems: 'center', justifyContent: 'center' }}
          >
            <Ionicons name="close" size={16} color={C.muted} />
          </Pressable>
        </View>
      ) : null}

      {teacher ? (
        <View
          style={{
            backgroundColor: C.warningSoft,
            borderWidth: 1,
            borderColor: C.warning,
            borderRadius: R.card,
            padding: 14,
            gap: 10,
            ...SHADOW,
          }}
        >
          <View style={{ flexDirection: 'row', gap: 10 }}>
            <Ionicons name="alert-circle" size={20} color={C.warning} style={{ marginTop: 1 }} />
            <View style={{ flex: 1, gap: 3 }}>
              <Text variant="label" c={C.duesInk}>
                {blocking ? 'TEACHER CLASH · SAVE BLOCKED' : 'TEACHER CLASH'}
              </Text>
              <Text variant="caption" c={C.ink} style={{ fontSize: 13, lineHeight: 18 }}>
                {`${teacher.teacherName} is double-booked on ${DAY_NAMES[teacher.dayOfWeek]} — ${teacher.a.batchName} (${teacher.a.range}) overlaps ${teacher.b.batchName} (${teacher.b.range}).`}
              </Text>
            </View>
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
            <Text weight={600} c={C.duesInk} style={{ fontSize: 11.5, flex: 1, lineHeight: 15 }}>
              {blocking
                ? 'These changes stay unsaved until the overlap is gone.'
                : 'This clash is already in the saved timetable.'}
            </Text>
            <Button title="Fix" size="sm" full={false} onPress={() => onFix(teacher)} />
          </View>
        </View>
      ) : null}
    </View>
  );
}
