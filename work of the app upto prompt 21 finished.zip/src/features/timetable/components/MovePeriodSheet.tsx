import React from 'react';
import { Modal, Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Button, Text } from '@/components/ui';
import { C, R } from '@/lib/theme';
import { DAY_SHORT, WEEK_ORDER, type PeriodRowView } from '../model';

export interface MovePeriodSheetProps {
  row: PeriodRowView | null;
  /** Position of the row in its day, for the up/down actions. */
  index: number;
  count: number;
  selectedDay: number;
  onClose: () => void;
  onNudge: (delta: number) => void;
  onPickDay: (day: number) => void;
}

/**
 * Tap fallback for the drag handle: nudge a period one slot up or down, or
 * send it to another weekday. Same mutations the drag performs — one table,
 * one conflict gate — just reachable without a gesture.
 */
export function MovePeriodSheet({ row, index, count, selectedDay, onClose, onNudge, onPickDay }: MovePeriodSheetProps) {
  return (
    <Modal visible={row !== null} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable style={{ flex: 1, backgroundColor: C.scrim, justifyContent: 'flex-end' }} onPress={onClose}>
        <Pressable
          onPress={(e) => e.stopPropagation()}
          style={{
            backgroundColor: C.surface,
            borderTopLeftRadius: R.sheet,
            borderTopRightRadius: R.sheet,
            padding: 20,
            paddingBottom: 32,
            gap: 16,
          }}
        >
          <View style={{ alignSelf: 'center', width: 36, height: 4, borderRadius: 2, backgroundColor: C.track }} />
          {row ? (
            <>
              <View style={{ gap: 3 }}>
                <Text variant="title">Move period</Text>
                <Text variant="caption" c={C.secondary}>
                  {`${row.subject} · ${row.badge} · ${row.range}`}
                </Text>
              </View>

              <View style={{ flexDirection: 'row', gap: 10 }}>
                <View style={{ flex: 1 }}>
                  <Button
                    title="Move up"
                    icon="chevron-up"
                    variant="outline"
                    size="md"
                    disabled={index <= 0}
                    onPress={() => onNudge(-1)}
                  />
                </View>
                <View style={{ flex: 1 }}>
                  <Button
                    title="Move down"
                    icon="chevron-down"
                    variant="outline"
                    size="md"
                    disabled={index >= count - 1}
                    onPress={() => onNudge(1)}
                  />
                </View>
              </View>

              <View style={{ gap: 8 }}>
                <Text variant="label" c={C.muted}>
                  MOVE TO DAY
                </Text>
                <View style={{ flexDirection: 'row', gap: 6 }}>
                  {WEEK_ORDER.map((day) => {
                    const current = day === selectedDay;
                    return (
                      <Pressable
                        key={day}
                        accessibilityRole="button"
                        accessibilityLabel={`Move to ${DAY_SHORT[day]}`}
                        disabled={current}
                        onPress={() => onPickDay(day)}
                        style={{
                          flex: 1,
                          height: 40,
                          borderRadius: R.chip,
                          alignItems: 'center',
                          justifyContent: 'center',
                          backgroundColor: current ? C.primary : C.track,
                        }}
                      >
                        <Text weight={700} c={current ? C.surface : C.secondary} style={{ fontSize: 12 }}>
                          {DAY_SHORT[day]}
                        </Text>
                      </Pressable>
                    );
                  })}
                </View>
              </View>

              <Button title="Cancel" variant="ghost" size="md" onPress={onClose} />
            </>
          ) : null}
        </Pressable>
      </Pressable>
    </Modal>
  );
}
