import React, { useMemo, useRef, useState } from 'react';
import { PanResponder, Pressable, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

import { Text } from '@/components/ui';
import { C, R, SHADOW } from '@/lib/theme';
import type { PeriodRowView } from '../model';

export const PERIOD_ROW_HEIGHT = 64;
export const TIME_CHIP_SIZE = 44;

/** Claim the drag once the pointer leaves a 5pt box, so a tap still opens the move sheet. */
const DRAG_SLOP = 5;

export interface PeriodRowProps {
  row: PeriodRowView;
  first?: boolean;
  last?: boolean;
  /** Renders the drag handle with pan + tap negotiation. */
  draggable?: boolean;
  /** The row being dragged: soft navy tint, 1px navy ring. */
  dragging?: boolean;
  /** The floating copy that follows the finger. */
  ghost?: boolean;
  insertBefore?: boolean;
  insertAfter?: boolean;
  /** Amber flash on the two rows a clash card's "Fix" points at. */
  highlighted?: boolean;
  onDragGrant?: (pageY: number) => void;
  onDragMove?: (pageY: number, pageX: number) => void;
  onDragEnd?: () => void;
  onDragCancel?: () => void;
  onHandleTap?: () => void;
  /** Opens Take Attendance for this period. Absent on the ghost and on read-only boards. */
  onAttendance?: () => void;
  /** A register is already saved for this period's date: teal check instead of the outline. */
  attendanceMarked?: boolean;
}

/**
 * One 64pt period row: 44pt time chip · subject 15/600 with the batch pill ·
 * teacher 13 secondary · room 13 muted · drag handle on the right. Rows sit in
 * one white card split by 1px hairlines, like the dashboard's batch rows.
 */
export function PeriodRow({
  row,
  first = false,
  last = false,
  draggable = false,
  dragging = false,
  ghost = false,
  insertBefore = false,
  insertAfter = false,
  highlighted = false,
  onDragGrant,
  onDragMove,
  onDragEnd,
  onDragCancel,
  onHandleTap,
  onAttendance,
  attendanceMarked = false,
}: PeriodRowProps) {
  const latest = useRef({ onDragGrant, onDragMove, onDragEnd, onDragCancel, onHandleTap });
  latest.current = { onDragGrant, onDragMove, onDragEnd, onDragCancel, onHandleTap };
  const [pressed, setPressed] = useState(false);

  const pan = useMemo(
    () => {
      const start = { x: 0, y: 0, moved: false };
      return PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: () => true,
        onPanResponderGrant: (e) => {
          start.x = e.nativeEvent.pageX;
          start.y = e.nativeEvent.pageY;
          start.moved = false;
          setPressed(true);
        },
        onPanResponderMove: (e) => {
          const { pageX, pageY } = e.nativeEvent;
          if (!start.moved) {
            if (Math.abs(pageX - start.x) < DRAG_SLOP && Math.abs(pageY - start.y) < DRAG_SLOP) return;
            start.moved = true;
            setPressed(false);
            latest.current.onDragGrant?.(start.y);
          }
          latest.current.onDragMove?.(pageY, pageX);
        },
        onPanResponderRelease: () => {
          setPressed(false);
          if (start.moved) latest.current.onDragEnd?.();
          else latest.current.onHandleTap?.();
        },
        onPanResponderTerminationRequest: () => true,
        onPanResponderTerminate: () => {
          setPressed(false);
          if (start.moved) latest.current.onDragCancel?.();
        },
      });
    },
    [],
  );

  const accent = dragging || ghost;
  const background = accent ? C.navySoft : highlighted ? C.warningSoft : C.surface;
  const border = accent ? C.primary : highlighted ? C.warning : C.hairline;

  return (
    <View
      accessibilityLabel={`${row.subject}, ${row.badge}, ${row.range}`}
      style={{
        height: PERIOD_ROW_HEIGHT,
        flexDirection: 'row',
        alignItems: 'center',
        gap: 12,
        paddingHorizontal: 14,
        backgroundColor: background,
        borderColor: border,
        borderWidth: 1,
        borderBottomWidth: accent || last ? 1 : 0,
        borderTopLeftRadius: first ? R.card : accent ? 16 : 0,
        borderTopRightRadius: first ? R.card : accent ? 16 : 0,
        borderBottomLeftRadius: last ? R.card : accent ? 16 : 0,
        borderBottomRightRadius: last ? R.card : accent ? 16 : 0,
        ...(ghost ? SHADOW : null),
      }}
    >
      {insertBefore ? (
        <View
          pointerEvents="none"
          style={{ position: 'absolute', top: -2, left: 12, right: 12, height: 3, borderRadius: 2, backgroundColor: C.primary, zIndex: 3 }}
        />
      ) : null}
      {insertAfter ? (
        <View
          pointerEvents="none"
          style={{ position: 'absolute', bottom: -2, left: 12, right: 12, height: 3, borderRadius: 2, backgroundColor: C.primary, zIndex: 3 }}
        />
      ) : null}

      <View
        style={{
          width: TIME_CHIP_SIZE,
          height: TIME_CHIP_SIZE,
          borderRadius: 14,
          backgroundColor: accent ? C.surface : C.navySoft,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Text c={C.primary} weight={700} tabular style={{ fontSize: 12.5, lineHeight: 15 }}>
          {row.clock}
        </Text>
        {row.meridiem ? (
          <Text c={C.primary2} weight={700} style={{ fontSize: 8.5, lineHeight: 10 }}>
            {row.meridiem}
          </Text>
        ) : null}
      </View>

      <View style={{ flex: 1, gap: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Text variant="body" weight={600} numberOfLines={1} style={{ fontSize: 15, flexShrink:1 }}>
            {row.subject}
          </Text>
          <View style={{ paddingHorizontal: 7, paddingVertical: 2, borderRadius: R.chip, backgroundColor: accent ? C.surface : C.track }}>
            <Text weight={600} c={C.secondary} numberOfLines={1} style={{ fontSize: 10.5 }}>
              {row.badge}
            </Text>
          </View>
        </View>
        {row.lines[0] ? (
          <Text variant="caption" c={C.secondary} numberOfLines={1}>
            {row.lines[0]}
          </Text>
        ) : null}
        {row.lines[1] ? (
          <Text variant="caption" c={C.muted} numberOfLines={1}>
            {row.lines[1]}
          </Text>
        ) : null}
      </View>

      {onAttendance ? (
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={`${attendanceMarked ? 'Edit' : 'Take'} attendance for ${row.badge}, ${row.subject}`}
          onPress={onAttendance}
          hitSlop={4}
          style={({ pressed }) => ({
            width: 36,
            height: 36,
            borderRadius: 12,
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: attendanceMarked ? C.tealSoft : pressed ? C.navySoft : C.track,
          })}
        >
          <Ionicons
            name={attendanceMarked ? 'checkmark-done' : 'checkbox-outline'}
            size={18}
            color={attendanceMarked ? C.teal : C.primary}
          />
        </Pressable>
      ) : null}

      {draggable ? (
        <View
          {...pan.panHandlers}
          accessibilityRole="button"
          accessibilityLabel={`Move ${row.subject}, ${row.badge}`}
          style={{ width: 36, height: 48, alignItems: 'center', justifyContent: 'center', opacity: pressed ? 0.45 : 1 }}
        >
          <Ionicons name="menu" size={20} color={C.muted} />
        </View>
      ) : ghost ? (
        <View style={{ width: 36, height: 48, alignItems: 'center', justifyContent: 'center' }}>
          <Ionicons name="menu" size={20} color={C.muted} />
        </View>
      ) : null}
    </View>
  );
}
