import React from 'react';
import { Pressable, View } from 'react-native';

import { Text } from '@/components/ui';
import { C, R } from '@/lib/theme';
import { DAY_SHORT, WEEK_ORDER } from '../model';

export const WEEK_CHIP_HEIGHT = 40;

export interface WeekStripProps {
  selected: number;
  today: number;
  /** The day chip the dragged row is hovering — drawn with a navy ring. */
  hoverDay: number | null;
  onSelect: (day: number) => void;
  registerChip: (day: number, view: View | null) => void;
}

/**
 * Seven 40pt day chips, Monday first. The selected day is filled navy; today
 * carries a saffron dot. During a drag the chips double as drop targets: the
 * hovered one lights up and releasing moves the period to that weekday.
 */
export function WeekStrip({ selected, today, hoverDay, onSelect, registerChip }: WeekStripProps) {
  return (
    <View style={{ flexDirection: 'row', gap: 6 }}>
      {WEEK_ORDER.map((day) => {
        const isSelected = day === selected;
        const isHover = day === hoverDay;
        const isToday = day === today;
        const background = isHover ? C.navySoft : isSelected ? C.primary : C.surface;
        const borderColor = isHover || isSelected ? C.primary : C.hairline;
        const labelColor = isHover ? C.primary : isSelected ? C.surface : C.secondary;
        return (
          <Pressable
            key={day}
            ref={(view) => registerChip(day, view)}
            accessibilityRole="tab"
            accessibilityState={{ selected: isSelected }}
            accessibilityLabel={DAY_SHORT[day]}
            onPress={() => onSelect(day)}
            style={({ pressed }) => ({
              flex: 1,
              height: WEEK_CHIP_HEIGHT,
              borderRadius: R.chip,
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: background,
              borderWidth: isHover ? 1.5 : 1,
              borderColor,
              opacity: pressed && !isHover ? 0.85 : 1,
            })}
          >
            <Text weight={700} c={labelColor} style={{ fontSize: 12 }}>
              {DAY_SHORT[day]}
            </Text>
            {isToday ? (
              <View
                style={{
                  position: 'absolute',
                  bottom: 4,
                  width: 4,
                  height: 4,
                  borderRadius: 2,
                  backgroundColor: C.accent,
                }}
              />
            ) : null}
          </Pressable>
        );
      })}
    </View>
  );
}
