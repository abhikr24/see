import { useCallback, useMemo } from 'react';

import { useInstitute } from '@/core/backend';
import type { AttendanceSheet } from '@/core/contracts/models';
import { useDaySheets } from '@/core/hooks/academics';
import { takeAttendanceHref } from '@/features/attendance/links';
import { countMarks, dateChipLabel, latestDateForWeekday, marksFrom, type Counts } from '@/features/attendance/model';
import type { PeriodRowView } from '../model';

export interface PeriodAttendance {
  sheet: AttendanceSheet | null;
  counts: Counts | null;
  href: ReturnType<typeof takeAttendanceHref>;
}

/**
 * The timetable's view of attendance for one weekday: the most recent date on
 * that weekday (never a future one), the sheets saved for it, and for every
 * period row the register link with batch, date, period and subject prefilled.
 * Reads the same `attendance` cache a save updates optimistically.
 */
export function useDayAttendance(dayOfWeek: number, rows: readonly PeriodRowView[]) {
  const date = latestDateForWeekday(dayOfWeek);
  const sheets = useDaySheets(date);
  const institute = useInstitute();
  const perPeriod = institute.data?.settings.attendanceMode === 'period';

  /** Daily mode: one roll call per batch per day (period 1). Period mode: the row's ordinal for its batch. */
  const periodOf = useCallback(
    (row: PeriodRowView): number => {
      if (!perPeriod) return 1;
      const sameBatch = rows.filter((r) => r.period.batchId === row.period.batchId);
      return Math.max(1, sameBatch.findIndex((r) => r.id === row.id) + 1);
    },
    [rows, perPeriod],
  );

  const byRow = useMemo(() => {
    const map = new Map<string, PeriodAttendance>();
    for (const row of rows) {
      const period = periodOf(row);
      const sheet =
        sheets.data?.find((s) => s.session.batchId === row.period.batchId && s.session.period === period) ?? null;
      const students = sheet?.records.map((r) => ({
        studentId: r.studentId, fullName: '', photoUrl: null, rollNumber: null, parentName: null, parentPhone: null,
      }));
      map.set(row.id, {
        sheet,
        counts: sheet && students ? countMarks(students, marksFrom(students, sheet)) : null,
        href: takeAttendanceHref({ batchId: row.period.batchId, date, period, subjectId: row.period.subjectId }),
      });
    }
    return map;
  }, [rows, sheets.data, periodOf, date]);

  return {
    date,
    dateLabel: dateChipLabel(date),
    loading: sheets.loading && !sheets.data,
    error: sheets.error && !sheets.data ? sheets.error : null,
    refetch: sheets.refetch,
    forRow: (id: string): PeriodAttendance | undefined => byRow.get(id),
  };
}
