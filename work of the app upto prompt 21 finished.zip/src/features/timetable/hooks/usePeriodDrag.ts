import { useCallback, useRef, useState } from 'react';
import type { NativeScrollEvent, NativeSyntheticEvent, View } from 'react-native';

import type { ID } from '@/core/contracts/models';
import { PERIOD_ROW_HEIGHT } from '../components/PeriodRow';
import { WEEK_ORDER } from '../model';

interface Frame {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface PeriodDragState {
  id: ID;
  fromIndex: number;
  /** Ghost top, in the screen root's coordinate space. */
  ghostTop: number;
  hoverDay: number | null;
  /** Insertion boundary 0..n in the day's current order. */
  hoverIndex: number | null;
}

export interface PeriodDragOptions {
  rowCount: () => number;
  currentDay: () => number;
  onReorder: (periodId: ID, fromIndex: number, toIndex: number) => void;
  onMoveDay: (periodId: ID, day: number) => void;
}

/**
 * Pointer drag for the period list, built on plain responder events so it
 * behaves the same with touch and with a mouse on web.
 *
 * The list never reorders while the finger is down — rows keep their places,
 * the dragged row tints navy, a ghost follows the pointer, and a navy line
 * marks the insertion boundary. Dropping on a day chip moves the period to
 * that weekday; dropping on the list hands (from, to) back to the board.
 */
export function usePeriodDrag(options: PeriodDragOptions) {
  const opts = useRef(options);
  opts.current = options;

  const [drag, setDragState] = useState<PeriodDragState | null>(null);
  const dragRef = useRef<PeriodDragState | null>(null);
  const setDrag = useCallback((next: PeriodDragState | null) => {
    dragRef.current = next;
    setDragState(next);
  }, []);

  const rootView = useRef<View | null>(null);
  const listView = useRef<View | null>(null);
  const chipViews = useRef<Record<number, View | null>>({});
  const chipFrames = useRef<Record<number, Frame | undefined>>({});
  const rootTop = useRef(0);
  const listTop = useRef(0);
  const scrollY = useRef(0);
  const grabDelta = useRef(0);

  const measure = useCallback(() => {
    rootView.current?.measureInWindow((_x, y) => {
      rootTop.current = y;
    });
    listView.current?.measureInWindow((_x, y) => {
      listTop.current = y;
    });
    for (const day of WEEK_ORDER) {
      chipViews.current[day]?.measureInWindow((x, y, w, h) => {
        chipFrames.current[day] = { x, y, w, h };
      });
    }
  }, []);

  const setRootView = useCallback((view: View | null) => {
    rootView.current = view;
  }, []);
  const setListView = useCallback((view: View | null) => {
    listView.current = view;
  }, []);
  const registerChip = useCallback((day: number, view: View | null) => {
    chipViews.current[day] = view;
  }, []);
  const onScroll = useCallback((e: NativeSyntheticEvent<NativeScrollEvent>) => {
    scrollY.current = e.nativeEvent.contentOffset.y;
  }, []);

  const grant = useCallback(
    (id: ID, index: number, pageY: number) => {
      measure();
      const rowTopWindow = listTop.current - scrollY.current + index * PERIOD_ROW_HEIGHT;
      grabDelta.current = pageY - rowTopWindow;
      setDrag({
        id,
        fromIndex: index,
        ghostTop: rowTopWindow - rootTop.current,
        hoverDay: null,
        hoverIndex: null,
      });
    },
    [measure, setDrag],
  );

  const move = useCallback(
    (pageY: number, pageX: number) => {
      const current = dragRef.current;
      if (!current) return;
      let hoverDay: number | null = null;
      for (const day of WEEK_ORDER) {
        const frame = chipFrames.current[day];
        if (
          frame &&
          pageX >= frame.x - 4 &&
          pageX <= frame.x + frame.w + 4 &&
          pageY >= frame.y - 20 &&
          pageY <= frame.y + frame.h + 20
        ) {
          hoverDay = day;
          break;
        }
      }
      let hoverIndex: number | null = null;
      if (hoverDay === null) {
        const count = opts.current.rowCount();
        const relative = pageY - listTop.current + scrollY.current;
        hoverIndex = Math.max(0, Math.min(count, Math.round(relative / PERIOD_ROW_HEIGHT)));
      }
      setDrag({
        ...current,
        ghostTop: pageY - grabDelta.current - rootTop.current,
        hoverDay,
        hoverIndex,
      });
    },
    [setDrag],
  );

  const end = useCallback(() => {
    const current = dragRef.current;
    setDrag(null);
    if (!current) return;
    if (current.hoverDay !== null) {
      if (current.hoverDay !== opts.current.currentDay()) {
        opts.current.onMoveDay(current.id, current.hoverDay);
      }
      return;
    }
    const { hoverIndex, fromIndex } = current;
    if (hoverIndex !== null && hoverIndex !== fromIndex && hoverIndex !== fromIndex + 1) {
      opts.current.onReorder(current.id, fromIndex, hoverIndex);
    }
  }, [setDrag]);

  const cancel = useCallback(() => setDrag(null), [setDrag]);

  return { drag, grant, move, end, cancel, measure, setRootView, setListView, registerChip, onScroll };
}

export type PeriodDrag = ReturnType<typeof usePeriodDrag>;
