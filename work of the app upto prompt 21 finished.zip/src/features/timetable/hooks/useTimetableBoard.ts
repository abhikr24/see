import { useCallback, useEffect, useMemo, useState } from 'react';

import type { ID, Timetable } from '@/core/contracts/models';
import type { Backend } from '@/core/contracts/ports';
import { useDomainMutation, useDomainQuery } from '@/core/hooks/domain';
import {
  buildRows,
  diffPeriods,
  findClashes,
  makeNames,
  moveToDay,
  reorderDay,
  sortDay,
  touchedDays,
  type Audience,
  type Clashes,
  type PeriodChange,
  type PeriodRowView,
  type TimetableBoardData,
} from '../model';

const NO_PERIODS: Timetable[] = [];

/** One call loads the whole board: every period plus the names each row shows. */
export async function loadBoard(b: Backend, i: ID): Promise<TimetableBoardData> {
  const [periods, batches, subjects, teachers, classrooms] = await Promise.all([
    b.timetable.list(i, { limit: 200 }),
    b.batches.list(i, { limit: 50 }),
    b.subjects.list(i, { limit: 50 }),
    b.staff.listTeachers(i, { limit: 50 }),
    b.timetable.listClassrooms(i),
  ]);
  return {
    periods: periods.items,
    batches: batches.items,
    subjects: subjects.items,
    teachers: teachers.items,
    classrooms,
  };
}

/**
 * The owner's timetable board.
 *
 * One table, one source: everything reads `TimetableRepo` through the shared
 * query cache — the teacher's "Today's schedule" and the student's "My Day"
 * read the very same rows (`useTodaySchedule`), so a period moved here is a
 * period moved for them. Nothing is duplicated.
 *
 * Edits are optimistic. A drag updates a local overlay first; the change list
 * is diffed against the loaded base, gated by conflict detection, then flushed
 * through the standard mutation path (snapshot → run → toast, or roll back +
 * error toast). A teacher clash on a touched day blocks the flush entirely —
 * the amber card names it and the rows stay unsaved until it is resolved.
 */
export function useTimetableBoard() {
  const query = useDomainQuery<TimetableBoardData>('timetable', ['board'], loadBoard);
  const base = query.data?.periods ?? NO_PERIODS;
  const [overlay, setOverlay] = useState<Record<ID, Timetable> | null>(null);

  const periods = useMemo(
    () => (overlay ? base.map((p) => overlay[p.id] ?? p) : base),
    [base, overlay],
  );
  const names = useMemo(() => makeNames(query.data), [query.data]);
  const changes = useMemo(() => (overlay ? diffPeriods(base, periods) : []), [overlay, base, periods]);
  const days = useMemo(() => touchedDays(base, changes), [base, changes]);
  const clashes: Clashes = useMemo(() => findClashes(periods, names), [periods, names]);
  const blockedDays = useMemo(
    () => new Set(clashes.teacher.filter((c) => days.has(c.dayOfWeek)).map((c) => c.dayOfWeek)),
    [clashes, days],
  );
  const saveBlocked = changes.length > 0 && blockedDays.size > 0;

  const flush = useDomainMutation<PeriodChange[], void>(
    ['timetable', 'analytics', 'batches'],
    async (b, i, list) => {
      for (const change of list) await b.timetable.update(i, change.id, change.patch);
    },
    {
      success: (_result, vars) =>
        vars.length === 1 ? 'Timetable updated' : `Timetable updated · ${vars.length} periods`,
      failure: 'Could not save the timetable',
    },
  );

  /** Apply a new draft; save it unless a teacher clash on a touched day blocks. */
  const commit = useCallback(
    (next: Timetable[]) => {
      const pending = diffPeriods(base, next);
      if (pending.length === 0) {
        setOverlay(null);
        return;
      }
      const byId: Record<ID, Timetable> = {};
      for (const row of next) byId[row.id] = row;
      setOverlay(byId);
      const nextClashes = findClashes(next, names);
      const nextDays = touchedDays(base, pending);
      const blocked = nextClashes.teacher.some((c) => nextDays.has(c.dayOfWeek));
      if (blocked) return; // the amber card explains; the draft stays unsaved
      void flush.mutate(pending).then((result) => {
        if (!result.ok) setOverlay(null); // rollback — cache + toast handled by runMutation
      });
    },
    [base, names, flush],
  );

  // Once a flush lands, the refetched base catches up with the overlay and the
  // diff goes empty — drop the overlay so external writes are never masked.
  useEffect(() => {
    if (overlay && changes.length === 0) setOverlay(null);
  }, [overlay, changes]);

  const reorder = useCallback(
    (day: number, periodId: ID, toIndex: number) => commit(reorderDay(periods, day, periodId, toIndex)),
    [commit, periods],
  );
  const moveDay = useCallback(
    (periodId: ID, day: number) => commit(moveToDay(periods, periodId, day)),
    [commit, periods],
  );
  const nudge = useCallback(
    (day: number, periodId: ID, delta: number) => {
      const rows = sortDay(periods.filter((p) => p.dayOfWeek === day));
      const from = rows.findIndex((p) => p.id === periodId);
      const to = from + delta;
      if (from < 0 || to < 0 || to >= rows.length) return;
      commit(reorderDay(periods, day, periodId, to));
    },
    [commit, periods],
  );
  const rowsFor = useCallback(
    (day: number, audience: Audience = 'owner'): PeriodRowView[] =>
      buildRows(
        periods.filter((p) => p.dayOfWeek === day),
        names,
        audience,
      ),
    [periods, names],
  );

  return {
    data: query.data,
    loading: query.loading,
    error: query.error,
    refetch: query.refetch,
    periods,
    names,
    changes,
    clashes,
    blockedDays,
    saveBlocked,
    saving: flush.loading,
    reorder,
    moveDay,
    nudge,
    rowsFor,
  };
}

export type TimetableBoard = ReturnType<typeof useTimetableBoard>;
