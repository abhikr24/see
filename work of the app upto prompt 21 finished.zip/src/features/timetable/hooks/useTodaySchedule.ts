import { useMemo } from 'react';

import type { BackendError } from '@/core/contracts/errors';
import type { Timetable } from '@/core/contracts/models';
import { useDomainQuery } from '@/core/hooks/domain';
import { useSessionStore } from '@/store/session';
import {
  buildRows,
  dayOfWeekOf,
  makeNames,
  sortDay,
  todayIso,
  type PeriodRowView,
  type TimetableBoardData,
} from '../model';
import { loadBoard } from './useTimetableBoard';

const NO_ROWS: PeriodRowView[] = [];

interface TodayBoard {
  board: TimetableBoardData;
  mine: Timetable[];
}

export interface TodaySchedule {
  rows: PeriodRowView[];
  loading: boolean;
  error: BackendError | null;
  refetch: () => Promise<void>;
  dayOfWeek: number;
}

/**
 * The teacher's "Today's schedule" and the student's "My Day".
 *
 * Both read the institute's one timetable — the same `TimetableRepo` rows the
 * owner's board edits, through the same query cache scope. Nothing here keeps
 * its own copy: a period the owner moves is a period moved for the teacher
 * and the student the moment the cache refreshes.
 */
export function useTodaySchedule(role: 'teacher' | 'student'): TodaySchedule {
  const { user } = useSessionStore();
  const userId = user?.userId ?? null;
  const dayOfWeek = dayOfWeekOf(todayIso());

  const query = useDomainQuery<TodayBoard>(
    'timetable',
    ['today', role, userId, dayOfWeek],
    async (b, i) => {
      const board = await loadBoard(b, i);
      let mine: Timetable[];
      if (role === 'teacher') {
        const me = userId ? board.teachers.find((t) => t.userId === userId) : undefined;
        mine = me ? board.periods.filter((p) => p.teacherId === me.id && p.dayOfWeek === dayOfWeek) : [];
      } else {
        const myBatches = await b.batches.listMine(i);
        const ids = new Set(myBatches.map((batch) => batch.id));
        mine = board.periods.filter((p) => ids.has(p.batchId) && p.dayOfWeek === dayOfWeek);
      }
      return { board, mine };
    },
    userId !== null,
  );

  const names = useMemo(() => makeNames(query.data?.board), [query.data]);
  const rows = useMemo(
    () => (query.data ? buildRows(sortDay(query.data.mine), names, role) : NO_ROWS),
    [query.data, names, role],
  );

  return { rows, loading: query.loading, error: query.error, refetch: query.refetch, dayOfWeek };
}
