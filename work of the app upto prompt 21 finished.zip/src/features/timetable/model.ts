import type { Batch, Classroom, ID, Subject, Teacher, Timetable } from '@/core/contracts/models';
import { timeShort } from '@/lib/format';

/**
 * Pure timetable logic: ordering, slot reassignment, diffs and conflict
 * detection. No React, no backend — everything here can be (and is) exercised
 * by `tests/timetable.acceptance.ts`. The screen and the hooks only compose.
 */

export const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
export const DAY_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
/** The week strip reads Monday-first, like a coaching week. */
export const WEEK_ORDER: readonly number[] = [1, 2, 3, 4, 5, 6, 0];

/** The backends keep "today" as the UTC calendar day; the strip agrees with them. */
export const todayIso = (): string => new Date().toISOString().slice(0, 10);
export const dayOfWeekOf = (iso: string): number => new Date(`${iso}T00:00:00Z`).getUTCDay();

/** HH:MM strings compare lexicographically; touching edges (10:00/10:00) do NOT overlap. */
export const overlaps = (aS: string, aE: string, bS: string, bE: string): boolean => aS < bE && bS < aE;

export interface PeriodPatch {
  dayOfWeek?: number;
  startsAt?: string;
  endsAt?: string;
}

export interface PeriodChange {
  id: ID;
  patch: PeriodPatch;
}

/** The canonical order of one day: by start time, id as the tie-break. */
export function sortDay(periods: readonly Timetable[]): Timetable[] {
  return [...periods].sort((a, b) => a.startsAt.localeCompare(b.startsAt) || a.id.localeCompare(b.id));
}

/** Only the three draggable fields are ever written; everything else is untouched. */
export function diffPeriods(base: readonly Timetable[], next: readonly Timetable[]): PeriodChange[] {
  const before = new Map<ID, Timetable>(base.map((p) => [p.id, p]));
  const changes: PeriodChange[] = [];
  for (const row of next) {
    const old = before.get(row.id);
    if (!old) continue;
    const patch: PeriodPatch = {};
    if (old.dayOfWeek !== row.dayOfWeek) patch.dayOfWeek = row.dayOfWeek;
    if (old.startsAt !== row.startsAt) patch.startsAt = row.startsAt;
    if (old.endsAt !== row.endsAt) patch.endsAt = row.endsAt;
    if (Object.keys(patch).length > 0) changes.push({ id: row.id, patch });
  }
  return changes;
}

/** Days a change list touches, counting both the day a period left and the day it landed on. */
export function touchedDays(base: readonly Timetable[], changes: readonly PeriodChange[]): Set<number> {
  const days = new Set<number>();
  for (const change of changes) {
    const old = base.find((p) => p.id === change.id);
    if (old) days.add(old.dayOfWeek);
    if (change.patch.dayOfWeek !== undefined) days.add(change.patch.dayOfWeek);
  }
  return days;
}

/**
 * Reorder one day: the dragged period takes the slot at `toIndex` (an insertion
 * boundary 0..n in the day's current order) and every other period shifts into
 * the freed slot. Slots — not durations — belong to the day, so the grid of
 * start/end times stays exactly as the institute set it up.
 */
export function reorderDay(all: readonly Timetable[], day: number, periodId: ID, toIndex: number): Timetable[] {
  const rows = sortDay(all.filter((p) => p.dayOfWeek === day));
  const fromIndex = rows.findIndex((p) => p.id === periodId);
  if (fromIndex < 0) return [...all];
  const slots = rows.map((p) => ({ startsAt: p.startsAt, endsAt: p.endsAt }));
  const order = [...rows];
  const [moved] = order.splice(fromIndex, 1);
  const insertAt = Math.max(0, Math.min(order.length, toIndex > fromIndex ? toIndex - 1 : toIndex));
  order.splice(insertAt, 0, moved);
  const patches = new Map<ID, PeriodPatch>();
  order.forEach((period, k) => {
    const slot = slots[k];
    if (slot && (period.startsAt !== slot.startsAt || period.endsAt !== slot.endsAt)) {
      patches.set(period.id, { startsAt: slot.startsAt, endsAt: slot.endsAt });
    }
  });
  return all.map((p) => {
    const patch = patches.get(p.id);
    return patch ? { ...p, ...patch } : p;
  });
}

/** Move one period to another weekday. It keeps its time slot. */
export function moveToDay(all: readonly Timetable[], periodId: ID, day: number): Timetable[] {
  return all.map((p) => (p.id === periodId ? { ...p, dayOfWeek: day } : p));
}

export interface ClashSide {
  periodId: ID;
  batchName: string;
  startsAt: string;
  endsAt: string;
  /** "4:00 PM – 5:00 PM" */
  range: string;
}

export interface TeacherClash {
  key: string;
  dayOfWeek: number;
  teacherId: ID;
  teacherName: string;
  a: ClashSide;
  b: ClashSide;
}

export interface RoomClash {
  key: string;
  dayOfWeek: number;
  roomName: string;
  a: ClashSide;
  b: ClashSide;
}

export interface Clashes {
  /** Hard: blocks the save until resolved. */
  teacher: TeacherClash[];
  /** Soft: a warning the owner can dismiss. */
  room: RoomClash[];
}

export interface TimetableBoardData {
  periods: Timetable[];
  batches: Batch[];
  subjects: Subject[];
  teachers: Teacher[];
  classrooms: Classroom[];
}

export interface BoardNames {
  batch: Map<ID, string>;
  subject: Map<ID, string>;
  teacher: Map<ID, string>;
  room: Map<ID, string>;
}

export function makeNames(board: TimetableBoardData | null | undefined): BoardNames {
  return {
    batch: new Map((board?.batches ?? []).map((b) => [b.id, b.name])),
    subject: new Map((board?.subjects ?? []).map((s) => [s.id, s.name])),
    teacher: new Map((board?.teachers ?? []).map((t) => [t.id, t.fullName])),
    room: new Map((board?.classrooms ?? []).map((r) => [r.id, r.name])),
  };
}

const pairKey = (x: ID, y: ID): string => (x < y ? `${x}|${y}` : `${y}|${x}`);

const inForce = (p: Timetable, today: string): boolean =>
  (!p.validFrom || p.validFrom <= today) && (!p.validTo || p.validTo >= today);

/**
 * Same teacher, overlapping time, same day → a teacher clash (hard).
 * Same room, overlapping time, same day, different teachers → a room clash
 * (soft). A pair that clashes on the teacher never also reports the room —
 * the harder warning subsumes the softer one.
 */
export function findClashes(periods: readonly Timetable[], names: BoardNames): Clashes {
  const today = todayIso();
  const live = periods.filter((p) => inForce(p, today));
  const byDay = new Map<number, Timetable[]>();
  for (const p of live) {
    const rows = byDay.get(p.dayOfWeek);
    if (rows) rows.push(p);
    else byDay.set(p.dayOfWeek, [p]);
  }
  const teacher: TeacherClash[] = [];
  const room: RoomClash[] = [];
  for (const [dayOfWeek, rows] of byDay) {
    const side = (p: Timetable): ClashSide => ({
      periodId: p.id,
      batchName: names.batch.get(p.batchId) ?? 'Another batch',
      startsAt: p.startsAt,
      endsAt: p.endsAt,
      range: `${timeShort(p.startsAt)} – ${timeShort(p.endsAt)}`,
    });
    for (let x = 0; x < rows.length; x += 1) {
      for (let y = x + 1; y < rows.length; y += 1) {
        const a = rows[x];
        const b = rows[y];
        if (!a || !b || !overlaps(a.startsAt, a.endsAt, b.startsAt, b.endsAt)) continue;
        if (a.teacherId !== null && a.teacherId === b.teacherId) {
          teacher.push({
            key: pairKey(a.id, b.id),
            dayOfWeek,
            teacherId: a.teacherId,
            teacherName: names.teacher.get(a.teacherId) ?? 'A teacher',
            a: side(a),
            b: side(b),
          });
        } else if (a.classroomId !== null && a.classroomId === b.classroomId) {
          room.push({
            key: pairKey(a.id, b.id),
            dayOfWeek,
            roomName: names.room.get(a.classroomId) ?? 'A room',
            a: side(a),
            b: side(b),
          });
        }
      }
    }
  }
  const byTime = (x: { dayOfWeek: number; a: ClashSide }, y: { dayOfWeek: number; a: ClashSide }) =>
    x.dayOfWeek - y.dayOfWeek || x.a.startsAt.localeCompare(y.a.startsAt);
  teacher.sort(byTime);
  room.sort(byTime);
  return { teacher, room };
}

export type Audience = 'owner' | 'teacher' | 'student';

export interface PeriodRowView {
  id: ID;
  period: Timetable;
  /** 15/600 line. */
  subject: string;
  /** Batch pill beside the subject. */
  badge: string;
  /** 13pt meta lines under the subject: teacher and/or room, per audience. */
  lines: string[];
  /** "4:00" — the big line of the 44pt time chip. */
  clock: string;
  /** "PM" — the small line of the time chip. */
  meridiem: string;
  range: string;
}

function splitClock(time: string): { clock: string; meridiem: string } {
  const label = timeShort(time);
  const parts = label.split(' ');
  return { clock: parts[0] ?? label, meridiem: parts[1] ?? '' };
}

/** One day's rows, in canonical order, ready to render. */
export function buildRows(
  periods: readonly Timetable[],
  names: BoardNames,
  audience: Audience,
): PeriodRowView[] {
  return sortDay(periods).map((period) => {
    const teacher = period.teacherId ? names.teacher.get(period.teacherId) ?? 'Unknown teacher' : 'No teacher yet';
    const room = period.classroomId ? names.room.get(period.classroomId) ?? null : null;
    const roomLine = room ?? 'No room';
    const { clock, meridiem } = splitClock(period.startsAt);
    return {
      id: period.id,
      period,
      subject: period.subjectId ? names.subject.get(period.subjectId) ?? 'Period' : 'Period',
      badge: names.batch.get(period.batchId) ?? 'Batch',
      lines: audience === 'teacher' ? [roomLine] : [teacher, roomLine],
      clock,
      meridiem,
      range: `${timeShort(period.startsAt)} – ${timeShort(period.endsAt)}`,
    };
  });
}
