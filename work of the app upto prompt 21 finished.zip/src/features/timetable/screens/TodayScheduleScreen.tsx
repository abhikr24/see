import React from 'react';
import { View } from 'react-native';

import { Card, EmptyState, ErrorState, ListSkeleton, Screen, Text } from '@/components/ui';
import { useInstitute } from '@/core/backend';
import { C } from '@/lib/theme';
import { dateShort } from '@/lib/format';
import { PeriodRow, PERIOD_ROW_HEIGHT } from '../components/PeriodRow';
import { useTodaySchedule } from '../hooks/useTodaySchedule';
import { DAY_NAMES, todayIso } from '../model';

export interface TodayScheduleScreenProps {
  role: 'teacher' | 'student';
}

/**
 * The teacher's "Today's schedule" and the student's "My Day".
 *
 * Both are read-only views over the institute's one timetable — the same
 * `TimetableRepo` rows the owner's board drags around. No copy, no mirror:
 * when the owner moves a period, these rows move with it.
 */
export function TodayScheduleScreen({ role }: TodayScheduleScreenProps) {
  const schedule = useTodaySchedule(role);
  const institute = useInstitute();
  const title = role === 'teacher' ? "Today's schedule" : 'My Day';
  const subtitle = `${DAY_NAMES[schedule.dayOfWeek]}, ${dateShort(todayIso())} · ${institute.data?.name ?? '…'}`;

  return (
    <Screen title={title} subtitle={subtitle} safeTop={false} tabBarInset={96}>
      {schedule.loading && schedule.rows.length === 0 ? <ListSkeleton rows={3} h={PERIOD_ROW_HEIGHT} /> : null}

      {!schedule.loading && schedule.error && schedule.rows.length === 0 ? (
        <Card flat>
          <ErrorState
            title="Could not load today"
            message={schedule.error.message}
            onRetry={() => void schedule.refetch()}
          />
        </Card>
      ) : null}

      {!schedule.error && schedule.rows.length === 0 && !schedule.loading ? (
        <Card flat>
          <EmptyState
            icon="calendar-outline"
            title="No classes today"
            text={
              role === 'teacher'
                ? 'Nothing on your timetable today. The week strip on the owner\u2019s timetable is where your periods are set.'
                : 'No periods on your timetable today. Enjoy the break!'
            }
          />
        </Card>
      ) : null}

      {schedule.rows.length > 0 ? (
        <View>
          {schedule.rows.map((row, index) => (
            <PeriodRow
              key={row.id}
              row={row}
              first={index === 0}
              last={index === schedule.rows.length - 1}
            />
          ))}
        </View>
      ) : null}

      <Text variant="caption" c={C.muted} style={{ textAlign: 'center' }}>
        Reads live from the institute timetable — no copy is kept here.
      </Text>
    </Screen>
  );
}
