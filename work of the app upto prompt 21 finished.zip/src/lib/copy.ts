/** User-facing copy for the design-system gallery and feature screens. */
export const copy = {
  dev: {
    eyebrow: 'DESIGN SYSTEM · QA GALLERY',
    title: 'Design system',
    subtitle: 'All 35 GuruFlow primitives in every variant and state — zero hardcoded colours.',
    heroTitle: 'Sunrise Coaching Classes',
    heroBody: 'Patna, Bihar · SUNRISE-PAT · Academic Year 2026–27',
    heroStat: 'TODAY ATTENDANCE',
    heroNote: '46 present · 1 late · 3 absent of 50',
  },
  fees: {
    title: 'Fees',
    paid: 'Paid',
    pending: 'Pending',
    overdue: 'Overdue',
  },
  common: {
    cancel: 'Cancel',
    done: 'Done',
    retry: 'Try again',
  },
  auth: {
    splash: {
      title: 'GuruFlow',
      tagline: 'One app. Every class. Every child.',
    },
    onboarding: {
      slides: [
        { title: 'Teach more, manage less', body: 'Attendance, fees and homework in one quiet place.' },
        { title: 'Parents stay in the loop', body: 'Notices and payments reach home instantly.' },
        { title: 'Every child seen', body: 'Spot who needs help before the exam.' },
      ],
      skip: 'Skip',
      next: 'Continue',
      start: 'Get started',
    },
    login: {
      title: 'Welcome back',
      subtitle: 'Sign in to your institute',
      identifierLabel: 'Mobile or email',
      identifierPlaceholder: 'e.g. 90000 00000 or owner@sunrise.test',
      passwordLabel: 'Password',
      passwordPlaceholder: '••••••••',
      forgot: 'Forgot?',
      signIn: 'Sign in',
      divider: 'or',
      google: 'Continue with Google',
      demoTitle: 'Try a demo account',
      errors: {
        identifier: 'Enter your mobile or email',
        password: 'Enter your password',
        invalid: 'Wrong email or password',
      },
    },
    otp: {
      title: 'Enter code',
      subtitle: 'We sent a 6-digit code to your phone/email',
      verify: 'Verify',
      resend: 'Resend code',
      change: 'Change number',
      errors: {
        invalid: 'Wrong code — try again',
        expired: 'Code expired — request a new one',
      },
      hint: 'Any 6-digit code works in development',
    },
    role: {
      title: 'Choose your role',
      subtitle: 'You’ll join as this member',
      roles: {
        owner: { label: 'Owner', desc: 'Create institute' },
        teacher: { label: 'Teacher', desc: 'Manage classes' },
        student: { label: 'Student', desc: 'View homework & results' },
        parent: { label: 'Parent', desc: 'Track your child' },
      },
      continue: 'Continue',
    },
  },
} as const;
