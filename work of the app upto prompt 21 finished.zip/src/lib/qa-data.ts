import type {
  AvatarStackUser,
  BarDatum,
  HeatmapDay,
  SelectOption,
  TableColumn,
  TrendPoint,
  UnderlineTab,
} from '@/components/ui';

/**
 * Canonical GuruFlow seed data for the /dev/components Design QA page.
 * Matches AGENTS.md and supabase/seed.sql (Sunrise Coaching Classes, SUNRISE-PAT).
 */

export const QA_STUDENTS: readonly AvatarStackUser[] = [
  { name: 'Aarav Sharma' },
  { name: 'Ishita Bose' },
  { name: 'Kabir Singh' },
  { name: 'Ananya Gupta' },
  { name: 'Ritesh Mehta' },
  { name: 'Zoya Ahmed' },
  { name: 'Kabeer Singh' },
  { name: 'Diya Patel' },
  { name: 'Manav Sethi' },
  { name: 'Priya Menon' },
  { name: 'Rohan Das' },
  { name: 'Sara Khan' },
];

export const QA_TEACHERS: readonly AvatarStackUser[] = [
  { name: 'Rohit Verma' },
  { name: 'Priya Nair' },
  { name: 'Meera Iyer' },
  { name: 'Sneha Iyer' },
  { name: 'Arun Kumar' },
];

export const QA_BATCH_OPTIONS: readonly SelectOption[] = [
  { value: '10-a', label: 'Class 10-A · Foundation', subtitle: 'Rohit Verma · 12 students', badge: '92% ATT' },
  { value: '10-b', label: 'Class 10-B · Evening', subtitle: 'Priya Nair · Physics & Maths', badge: 'ACTIVE' },
  { value: '11-jee', label: 'Class 11 · Target JEE', subtitle: 'Meera Iyer · Chemistry', badge: 'NEW' },
  { value: '12-neet', label: 'Class 12 · Target NEET', subtitle: 'Arun Kumar · Biology', badge: 'FULL' },
];

export const QA_TEACHER_OPTIONS: readonly SelectOption[] = [
  { value: 'rohit', label: 'Rohit Verma', subtitle: 'Mathematics · Senior Faculty', badge: 'MATHS' },
  { value: 'priya', label: 'Priya Nair', subtitle: 'Physics · Lab Coordinator', badge: 'PHYSICS' },
  { value: 'meera', label: 'Meera Iyer', subtitle: 'Chemistry · Organic & Physical', badge: 'CHEM' },
  { value: 'sneha', label: 'Sneha Iyer', subtitle: 'English · Communication', badge: 'ENG' },
  { value: 'arun', label: 'Arun Kumar', subtitle: 'Biology · Botany & Zoology', badge: 'BIO' },
];

export const QA_DETAIL_TABS_PRIMARY: readonly UnderlineTab[] = [
  { key: 'overview', label: 'Overview' },
  { key: 'students', label: 'Students', count: 12 },
  { key: 'exams', label: 'Exams', count: 3 },
  { key: 'fees', label: 'Pending Fees', count: 12 },
];

export const QA_DETAIL_TABS_ACCENT: readonly UnderlineTab[] = [
  { key: 'ut1', label: 'Unit Test 1' },
  { key: 'ut2', label: 'Unit Test 2' },
  { key: 'ut3', label: 'Unit Test 3', count: 9 },
];

export interface MarkRow extends Record<string, unknown> {
  id: string;
  roll: string;
  student: string;
  marks: string;
  pct: string;
}

export const QA_MARK_COLUMNS: readonly TableColumn<MarkRow>[] = [
  { key: 'roll', title: 'Roll', width: 52 },
  { key: 'student', title: 'Student (10-A)', flex: 1.6 },
  { key: 'marks', title: 'Marks / 100', numeric: true, flex: 1 },
  { key: 'pct', title: 'Score', numeric: true, width: 72 },
];

export const QA_MARK_ROWS: readonly MarkRow[] = [
  { id: '1', roll: '14', student: 'Aarav Sharma', marks: '86', pct: '86%' },
  { id: '2', roll: '15', student: 'Ishita Bose', marks: '74', pct: '74%' },
  { id: '3', roll: '16', student: 'Kabir Singh', marks: '62', pct: '62%' },
  { id: '4', roll: '17', student: 'Ananya Gupta', marks: '88', pct: '88%' },
  { id: '5', roll: '18', student: 'Ritesh Mehta', marks: '55', pct: '55%' },
  { id: '6', roll: '19', student: 'Zoya Ahmed', marks: '79', pct: '79%' },
  { id: '7', roll: '20', student: 'Kabeer Singh', marks: '41', pct: '41%' },
  { id: '8', roll: '21', student: 'Diya Patel', marks: '93', pct: '93%' },
  { id: '9', roll: '22', student: 'Manav Sethi', marks: '71', pct: '71%' },
];

export interface FeeRow extends Record<string, unknown> {
  id: string;
  term: string;
  status: string;
  amount: string;
}

export const QA_FEE_COLUMNS: readonly TableColumn<FeeRow>[] = [
  { key: 'term', title: 'Installment', flex: 1.4 },
  { key: 'status', title: 'Status', flex: 1 },
  { key: 'amount', title: 'Amount', numeric: true, flex: 1 },
];

export const QA_FEE_ROWS: readonly FeeRow[] = [
  { id: 't1', term: 'Term 1 · Apr–Jul', status: 'Paid', amount: '₹4,999' },
  { id: 't2', term: 'Term 2 · Aug–Nov', status: 'Paid', amount: '₹4,999' },
  { id: 't3', term: 'Term 3 · Dec–Mar', status: 'Due', amount: '₹4,999' },
];

export const QA_ATTENDANCE_TREND: readonly TrendPoint[] = [
  { label: 'Mon', value: 84 },
  { label: 'Tue', value: 88 },
  { label: 'Wed', value: 86 },
  { label: 'Thu', value: 90 },
  { label: 'Fri', value: 89 },
  { label: 'Sat', value: 92 },
];

export const QA_SCORE_TREND: readonly TrendPoint[] = [
  { label: 'UT 1', value: 64 },
  { label: 'Quiz 1', value: 68 },
  { label: 'UT 2', value: 66 },
  { label: 'Mid', value: 70 },
  { label: 'UT 3', value: 72 },
];

export const QA_UT3_BARS: readonly BarDatum[] = [
  { label: 'Aarav', value: 86 },
  { label: 'Ishita', value: 74 },
  { label: 'Kabir', value: 62 },
  { label: 'Ananya', value: 88 },
  { label: 'Ritesh', value: 55 },
  { label: 'Zoya', value: 79 },
  { label: 'Kabeer', value: 41 },
  { label: 'Diya', value: 93, highlight: true },
  { label: 'Manav', value: 71 },
];

export const QA_FEE_BARS: readonly BarDatum[] = [
  { label: 'Jun', value: 42 },
  { label: 'Jul', value: 48 },
  { label: 'Aug', value: 51 },
  { label: 'Sep', value: 46 },
  { label: 'Oct', value: 54 },
  { label: 'Nov', value: 60, highlight: true },
];

export const QA_HEATMAP_ATTENDANCE: readonly HeatmapDay[] = Array.from({ length: 30 }, (_, i) => {
  const day = i + 1;
  if (day % 7 === 0) return { day, status: 'holiday' };
  if (day === 5 || day === 18 || day === 24) return { day, status: 'absent' };
  if (day === 11) return { day, status: 'late' };
  return { day, status: 'present' };
});

export const QA_HEATMAP_INTENSITY: readonly HeatmapDay[] = Array.from({ length: 28 }, (_, i) => {
  const day = i + 1;
  const levels: (0 | 1 | 2 | 3 | 4)[] = [1, 2, 3, 2, 4, 3, 0];
  return { day, intensity: levels[i % levels.length] };
});
