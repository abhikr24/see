import type { Ionicons } from '@expo/vector-icons';

import { C } from './theme';

export interface SubjectTint {
  fg: string;
  bg: string;
  icon: keyof typeof Ionicons.glyphMap;
}

const TINT_BY_KEYWORD: [string, SubjectTint][] = [
  ['math', { fg: C.primary, bg: C.navySoft, icon: 'calculator-outline' }],
  ['phys', { fg: C.teal, bg: C.tealSoft, icon: 'planet-outline' }],
  ['chem', { fg: C.accent, bg: C.accentSoft, icon: 'flask-outline' }],
  ['bio', { fg: C.success, bg: C.successSoft, icon: 'leaf-outline' }],
  ['eng', { fg: C.duesInk, bg: C.warningSoft, icon: 'book-outline' }],
];

const FALLBACK: SubjectTint = { fg: C.primary, bg: C.navySoft, icon: 'document-text-outline' };

/** The tinted icon square a subject gets on a card: one look per subject, everywhere. */
export function subjectTint(subjectName: string | null | undefined): SubjectTint {
  const lower = (subjectName ?? '').toLowerCase();
  for (const [key, tint] of TINT_BY_KEYWORD) {
    if (lower.includes(key)) return tint;
  }
  return FALLBACK;
}
