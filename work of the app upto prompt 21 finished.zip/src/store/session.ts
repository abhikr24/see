/**
 * The whole app's session, in one place.
 *
 * Every screen that needs "who is signed in / which institute / which role"
 * reads `useSessionStore()` instead of touching AuthPort, InstituteRepo or
 * MembershipRepo directly. It is built only on top of the existing hooks in
 * `src/core/backend.tsx` (never on a backend SDK), so it obeys the same
 * tenancy rule as every other screen: a user is not tied to one institute,
 * and switching institute never remounts the app.
 */
import { useCallback, useEffect, useMemo, useRef } from 'react';

import type { ID, Institute, Membership, Profile, Role } from '@/core/contracts/models';
import type { Backend } from '@/core/contracts/ports';
import { useBackend, useMyInstitutes, useSession } from '@/core/backend';
import { queryKey } from '@/core/hooks/cache';
import { useQuery } from '@/core/hooks/useQuery';

export type RoleGroup = '/(owner)' | '/(teacher)' | '/(student)' | '/(parent)';

/**
 * Dev-only auth bypass.
 *
 * Set `EXPO_PUBLIC_DEV_AUTH=owner` in a local `.env` (see `.env.example`) to
 * open the app straight on the owner dashboard for the seeded Sunrise
 * institute — no sign-in, no OTP, no session queries, no async. This exists
 * so the dashboard can be eyeballed / screenshot-tested without a working
 * login in this environment.
 *
 * Production safety: the whole bypass is behind `__DEV__`, which Expo/Metro
 * sets to `false` for every release / export bundle. The value is also
 * inlined at bundle time from a local env file, so a production bundle built
 * without that local `.env` does not contain the pinned session at all.
 * Never ship a build made with `EXPO_PUBLIC_DEV_AUTH` set.
 */
export function isDevAuthBypassEnabled(): boolean {
  if (__DEV__ && process.env.EXPO_PUBLIC_DEV_AUTH) {
    return process.env.EXPO_PUBLIC_DEV_AUTH === 'owner';
  }
  return false;
}

const DEV_AT = '2026-11-12T00:00:00.000Z';
/** Seeded Sunrise institute — `00000000-0000-4000-8000-000000000001` in supabase/seed.sql / src/backends/memory/seed.ts. */
const DEV_SUNRISE_INSTITUTE: Institute = {
  id: '00000000-0000-4000-8000-000000000001',
  name: 'Sunrise Coaching Classes',
  code: 'SUNRISE-PAT',
  ownerId: '00000000-0000-4000-8000-000000000002',
  tagline: null,
  phone: null,
  email: null,
  address: null,
  city: 'Patna',
  state: 'Bihar',
  pincode: null,
  country: 'IN',
  logoUrl: null,
  status: 'active',
  settings: {
    academicYear: '2026-27',
    timezone: 'Asia/Kolkata',
    currency: 'INR',
    locale: 'en-IN',
    workingDays: [1, 2, 3, 4, 5, 6],
    attendanceMode: 'daily',
    minAttendancePercent: 75,
    passPercent: 33,
    lateFeePerDay: 0,
    receiptPrefix: 'SCC',
    allowJoinRequests: true,
    features: {},
  },
  createdAt: DEV_AT,
  updatedAt: DEV_AT,
};

/** Seeded owner Rahul Sharma — profile `…0102`, user `…0002` in the seed. */
const DEV_OWNER_PROFILE: Profile = {
  id: '00000000-0000-4000-8000-000000000102',
  userId: '00000000-0000-4000-8000-000000000002',
  fullName: 'Rahul Sharma',
  email: 'owner@sunrise.test',
  phone: null,
  avatarUrl: null,
  gender: null,
  dateOfBirth: null,
  city: null,
  state: null,
  bio: null,
  createdAt: DEV_AT,
  updatedAt: DEV_AT,
};

const DEV_OWNER_MEMBERSHIP: Membership = {
  id: '00000000-0000-4000-8000-000000000202',
  instituteId: DEV_SUNRISE_INSTITUTE.id,
  userId: DEV_OWNER_PROFILE.userId,
  branchId: '00000000-0000-4000-8000-000000000008',
  role: 'owner',
  status: 'active',
  permissions: [],
  requestNote: null,
  requestedAt: DEV_AT,
  decidedBy: DEV_OWNER_PROFILE.userId,
  decidedAt: DEV_AT,
  createdAt: DEV_AT,
  updatedAt: DEV_AT,
};

const DEV_PINNED_INSTITUTES: InstituteMembership[] = [
  { institute: DEV_SUNRISE_INSTITUTE, membership: DEV_OWNER_MEMBERSHIP },
];

const devSwitchInstitute = (_instituteId: ID): void => {
  // Pinned: the bypass owns exactly one institute, so there is nowhere to switch to.
};

const DEV_OWNER_SESSION: SessionStore = {
  status: 'ready',
  loading: false,
  user: DEV_OWNER_PROFILE,
  role: 'owner',
  group: '/(owner)',
  activeInstituteId: DEV_SUNRISE_INSTITUTE.id,
  institutes: DEV_PINNED_INSTITUTES,
  switchInstitute: devSwitchInstitute,
};

/** owner and admin share one shell; the other three roles each get their own. */
export function groupForRole(role: Role): RoleGroup {
  if (role === 'teacher') return '/(teacher)';
  if (role === 'student') return '/(student)';
  if (role === 'parent') return '/(parent)';
  return '/(owner)';
}

export interface InstituteMembership {
  institute: Institute;
  membership: Membership;
}

export type SessionStatus =
  /** Session + memberships are still loading for the first time. */
  | 'loading'
  /** No one is signed in. */
  | 'signed-out'
  /** Signed in, but every membership the person holds is awaiting approval. */
  | 'pending'
  /** Signed in, the institute they tried turned them down and they hold no other. */
  | 'rejected'
  /** Signed in, but has never requested to join or create an institute. */
  | 'no-membership'
  /** Signed in with at least one active membership — the normal case. */
  | 'ready';

export interface SessionStore {
  status: SessionStatus;
  loading: boolean;
  user: Profile | null;
  /** The role the active institute knows this person as. null until `status` is `ready`. */
  role: Role | null;
  group: RoleGroup | null;
  activeInstituteId: ID | null;
  /** Every institute this person can open right now, for the switcher. */
  institutes: InstituteMembership[];
  /** Moves the whole app to a different institute. Callers also navigate to `groupForRole`. */
  switchInstitute: (instituteId: ID) => void;
}

/** Where a signed-in-but-unresolved person should land. Shared by the resolver and every guard. */
export function destinationFor(status: SessionStatus, group: RoleGroup | null): string {
  switch (status) {
    case 'loading':
      return '';
    case 'signed-out':
      return '/(auth)/splash';
    case 'pending':
      return '/(pending)';
    case 'rejected':
    case 'no-membership':
      return '/(auth)/role';
    case 'ready':
      return group ?? '/(owner)';
  }
}

/**
 * Where a just-authenticated person belongs, read from the live ports — not
 * from a cache that may still hold the signed-out snapshot. Call after
 * `queryCache.invalidate` so the shell and this result agree.
 */
export async function resolveAuthenticatedDestination(backend: Backend, instituteId: ID | null): Promise<string> {
  const session = await backend.auth.getSession(instituteId);
  if (!session) return '/(auth)/login';
  const mine = await backend.institutes.listMine(null);
  const membership =
    (mine[0] ? await backend.memberships.getMine(mine[0].id) : null) ?? session.membership;
  if (membership?.status === 'active') return groupForRole(membership.role);
  if (membership?.status === 'pending') return '/(pending)';
  if (membership?.status === 'rejected') return '/(auth)/role';
  return '/(auth)/role';
}

export function useSessionStore(): SessionStore {
  if (__DEV__ && process.env.EXPO_PUBLIC_DEV_AUTH) {
    if (isDevAuthBypassEnabled()) {
      // Synchronous pinned session: no hooks below this line run, so no
      // session / institute / membership query is started and nothing is
      // awaited. `__DEV__` and the env value are both build-time constants,
      // so this branch is stable for the lifetime of a bundle and the hook
      // order never changes between renders of the same build.
      return DEV_OWNER_SESSION;
    }
  }
  return useRealSessionStore();
}

function useRealSessionStore(): SessionStore {
  const { backend, instituteId, setInstituteId } = useBackend();
  const session = useSession();
  const myInstitutes = useMyInstitutes();

  const activeInstitutes = useMemo(() => myInstitutes.data ?? [], [myInstitutes.data]);
  const instituteIds = useMemo(() => activeInstitutes.map((i) => i.id).sort(), [activeInstitutes]);

  // One membership lookup per institute the person is active in, so the
  // switcher can show each one's role without guessing.
  const membershipsKey =
    session.data && instituteIds.length ? queryKey(backend.name, 'my-memberships', null, instituteIds) : null;
  const memberships = useQuery<Membership[]>(membershipsKey, async () => {
    const found = await Promise.all(instituteIds.map((id) => backend.memberships.getMine(id)));
    return found.filter((m): m is Membership => m !== null && m.status === 'active');
  });

  const institutes: InstituteMembership[] = useMemo(() => {
    const byId = new Map(activeInstitutes.map((institute) => [institute.id, institute]));
    return (memberships.data ?? [])
      .map((membership) => {
        const institute = byId.get(membership.instituteId);
        return institute ? { institute, membership } : null;
      })
      .filter((row): row is InstituteMembership => row !== null);
  }, [activeInstitutes, memberships.data]);

  const loading = session.loading || myInstitutes.loading || (membershipsKey !== null && memberships.loading);

  // Auth invalidates the session scope, and useQuery reloads when this store
  // is mounted. A signed-out `my-institutes: []` can still be on screen for a
  // frame, which would pin status at 'no-membership'. Re-read getSession (and
  // the institute list) once per user so status can move to 'ready' without a
  // reload. A person who truly has no membership is not retried.
  const rereadFor = useRef<string | null>(null);
  const refetchSession = session.refetch;
  const refetchInstitutes = myInstitutes.refetch;
  const sessionUserId = session.data?.user.id ?? null;
  useEffect(() => {
    if (!sessionUserId) {
      rereadFor.current = null;
      return;
    }
    if (loading || institutes.length > 0) return;
    if (rereadFor.current === sessionUserId) return;
    rereadFor.current = sessionUserId;
    void (async () => {
      await backend.auth.getSession(instituteId);
      await Promise.all([refetchSession(), refetchInstitutes()]);
    })();
  }, [backend, instituteId, sessionUserId, institutes.length, loading, refetchSession, refetchInstitutes]);

  // If the institute currently open is not one the person is active in
  // (first launch, stale pick, got removed), hop to one that is — quietly,
  // no remount, no flash.
  useEffect(() => {
    if (loading || institutes.length === 0) return;
    if (!institutes.some((row) => row.institute.id === instituteId)) {
      setInstituteId(institutes[0].institute.id);
    }
  }, [loading, institutes, instituteId, setInstituteId]);

  const sessionMembership = session.data?.membership ?? null;
  const activeRow = institutes.find((row) => row.institute.id === instituteId) ?? institutes[0] ?? null;
  // Prefer the institute list. Fall back to the membership getSession just
  // re-read, so a stale empty institute cache cannot hide an active role.
  const role = activeRow?.membership.role ?? (sessionMembership?.status === 'active' ? sessionMembership.role : null);
  const group = role ? groupForRole(role) : null;

  let status: SessionStatus;
  if (!session.data) {
    status = loading ? 'loading' : 'signed-out';
  } else if (institutes.length > 0) {
    status = 'ready';
  } else if (loading) {
    status = 'loading';
  } else if (sessionMembership?.status === 'active') {
    status = 'ready';
  } else if (sessionMembership?.status === 'pending') {
    status = 'pending';
  } else if (sessionMembership?.status === 'rejected') {
    status = 'rejected';
  } else {
    status = 'no-membership';
  }

  const switchInstitute = useCallback((id: ID) => setInstituteId(id), [setInstituteId]);

  return {
    status,
    loading,
    user: session.data?.profile ?? null,
    role,
    group,
    activeInstituteId: instituteId,
    institutes,
    switchInstitute,
  };
}

export interface RouteResolution {
  status: SessionStatus;
  group: RoleGroup | null;
  /** Where to go. Empty while `status` is `loading` — render a loading state instead of redirecting. */
  destination: string;
}

/**
 * The single rule every guard shares: no session → (auth); every membership
 * pending → (pending); otherwise the group of the active membership's role.
 * Used by `app/index.tsx` and by each role layout to bounce a visitor who
 * lands on a group that is not theirs.
 */
export function useRouteResolution(): RouteResolution {
  const { status, group } = useSessionStore();
  return { status, group, destination: destinationFor(status, group) };
}
