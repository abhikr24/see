-- =====================================================================
-- 0003_core.sql · GuruFlow data model, part 1 of 6
--   GLOBAL : users, profiles, user_preferences, sessions
--   TENANT : institutes, branches, memberships, invitations,
--            institute_settings
--
-- Conventions used by every table in 0003–0007
--   · id uuid primary key
--   · institute_id uuid not null (tenant tables only)
--   · created_at / updated_at + trg_<table>_updated_at
--   · unique (institute_id, id) on tenant tables so that children can
--     use composite foreign keys – a row can never point at a parent
--     that belongs to a different institute.
--   · text + check constraints instead of enum types.
-- Requires PostgreSQL 15+ (on delete set null (column)).
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Retire the previous schema
--    DESTRUCTIVE: every table in schema public is dropped, with its data.
--    The old model is replaced, not migrated.
-- ---------------------------------------------------------------------
do $$
declare
  r record;
begin
  -- app-defined triggers on auth.users point at the old tables
  for r in
    select t.tgname
    from pg_trigger t
    join pg_proc p on p.oid = t.tgfoid
    join pg_namespace n on n.oid = p.pronamespace
    where t.tgrelid = 'auth.users'::regclass
      and not t.tgisinternal
      and n.nspname = 'public'
  loop
    execute format('drop trigger %I on auth.users', r.tgname);
  end loop;

  for r in
    select c.relname
    from pg_class c
    join pg_namespace n on n.oid = c.relnamespace
    where n.nspname = 'public'
      and c.relkind in ('r', 'p')
      and not exists (                       -- leave extension-owned tables alone
        select 1 from pg_depend d
        where d.classid = 'pg_class'::regclass and d.objid = c.oid and d.deptype = 'e')
  loop
    execute format('drop table if exists public.%I cascade', r.relname);
  end loop;
end $$;

-- ---------------------------------------------------------------------
-- 2. Shared trigger function
-- ---------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- =====================================================================
-- GLOBAL
-- =====================================================================

-- Mirror of auth.users. Kept in sync by handle_auth_user(); clients read only.
create table public.users (
  id            uuid primary key references auth.users (id) on delete cascade,
  email         text,
  phone         text,
  status        text not null default 'active' check (status in ('active', 'disabled')),
  last_seen_at  timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table public.profiles (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null unique references public.users (id) on delete cascade,
  full_name      text not null default '',
  avatar_url     text,
  gender         text check (gender in ('male', 'female', 'other')),
  date_of_birth  date,
  city           text,
  state          text,
  bio            text,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create table public.user_preferences (
  id                    uuid primary key default gen_random_uuid(),
  user_id               uuid not null unique references public.users (id) on delete cascade,
  theme                 text not null default 'system' check (theme in ('system', 'light', 'dark')),
  language              text not null default 'en',
  default_institute_id  uuid,                      -- fk added below, after institutes
  push_enabled          boolean not null default true,
  email_enabled         boolean not null default true,
  sms_enabled           boolean not null default false,
  whatsapp_enabled      boolean not null default false,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

-- App-level device sessions (push tokens, "signed-in devices"). Not auth.sessions.
create table public.sessions (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references public.users (id) on delete cascade,
  device_id       text,
  device_name     text,
  platform        text check (platform in ('ios', 'android', 'web')),
  app_version     text,
  push_token      text,
  ip_address      inet,
  last_active_at  timestamptz not null default now(),
  expires_at      timestamptz,
  revoked_at      timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index sessions_user_idx on public.sessions (user_id);

-- =====================================================================
-- TENANT
-- =====================================================================

create table public.institutes (
  id            uuid primary key default gen_random_uuid(),
  -- An institute is its own tenant. Generated so every tenant table exposes
  -- the same institute_id column to RLS and tooling.
  institute_id  uuid generated always as (id) stored,
  name          text not null,
  code          text not null unique check (code ~ '^[A-Z0-9][A-Z0-9-]{2,23}$'),
  owner_id      uuid not null references public.users (id) on delete restrict,
  tagline       text,
  phone         text,
  email         text,
  address       text,
  city          text,
  state         text,
  pincode       text,
  country       text not null default 'IN',
  logo_url      text,
  status        text not null default 'active' check (status in ('active', 'suspended', 'archived')),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index institutes_owner_idx on public.institutes (owner_id);

alter table public.user_preferences
  add constraint user_preferences_default_institute_fk
  foreign key (default_institute_id) references public.institutes (id) on delete set null;

create table public.branches (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  name          text not null,
  code          text not null,
  address       text,
  city          text,
  state         text,
  pincode       text,
  phone         text,
  is_main       boolean not null default false,
  status        text not null default 'active' check (status in ('active', 'inactive')),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, code)
);

create table public.memberships (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  user_id       uuid not null references public.users (id) on delete cascade,
  branch_id     uuid,
  role          text not null check (role in ('owner', 'admin', 'teacher', 'student', 'parent')),
  status        text not null default 'pending' check (status in ('pending', 'active', 'suspended', 'rejected')),
  -- Delegated powers for role = 'admin'. Owners implicitly hold all of them.
  permissions   text[] not null default '{}'
                check (permissions <@ array['institute', 'members', 'staff', 'fees', 'leads', 'billing', 'audit']),
  request_note  text,
  requested_at  timestamptz not null default now(),
  decided_by    uuid references public.users (id) on delete set null,
  decided_at    timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, user_id),            -- one role per person per institute
  unique (institute_id, id),
  unique (institute_id, id, role),           -- lets children pin the role they expect
  foreign key (institute_id, branch_id) references public.branches (institute_id, id) on delete set null (branch_id)
);
create index memberships_user_idx on public.memberships (user_id, status);

create table public.invitations (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  email         text,
  phone         text,
  full_name     text,
  role          text not null check (role in ('admin', 'teacher', 'student', 'parent')),
  token         text not null unique
                default replace(gen_random_uuid()::text || gen_random_uuid()::text, '-', ''),
  status        text not null default 'pending' check (status in ('pending', 'accepted', 'revoked', 'expired')),
  invited_by    uuid references public.users (id) on delete set null,
  expires_at    timestamptz not null default now() + interval '7 days',
  accepted_by   uuid references public.users (id) on delete set null,
  accepted_at   timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  check (email is not null or phone is not null)
);

create table public.institute_settings (
  id                      uuid primary key default gen_random_uuid(),
  institute_id            uuid not null unique references public.institutes (id) on delete cascade,
  academic_year           text,
  timezone                text not null default 'Asia/Kolkata',
  currency                text not null default 'INR',
  locale                  text not null default 'en-IN',
  working_days            smallint[] not null default '{1,2,3,4,5,6}',   -- 0 = Sunday
  attendance_mode         text not null default 'daily' check (attendance_mode in ('daily', 'period')),
  min_attendance_percent  numeric(5, 2) not null default 75 check (min_attendance_percent between 0 and 100),
  pass_percent            numeric(5, 2) not null default 33 check (pass_percent between 0 and 100),
  late_fee_per_day        numeric(12, 2) not null default 0 check (late_fee_per_day >= 0),
  receipt_prefix          text,
  allow_join_requests     boolean not null default true,
  features                jsonb not null default '{}',
  created_at              timestamptz not null default now(),
  updated_at              timestamptz not null default now(),
  unique (institute_id, id)
);

-- ---------------------------------------------------------------------
-- auth.users → public.users / profiles / user_preferences
-- ---------------------------------------------------------------------
create or replace function public.handle_auth_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if tg_op = 'INSERT' then
    insert into public.users (id, email, phone)
    values (new.id, new.email, new.phone)
    on conflict (id) do update set email = excluded.email, phone = excluded.phone;

    -- profile and preferences share the user's id so they are predictable
    insert into public.profiles (id, user_id, full_name)
    values (new.id, new.id, coalesce(trim(new.raw_user_meta_data ->> 'full_name'), ''))
    on conflict (user_id) do nothing;

    insert into public.user_preferences (id, user_id)
    values (new.id, new.id)
    on conflict (user_id) do nothing;
  else
    update public.users
       set email = new.email, phone = new.phone
     where id = new.id;
  end if;
  return new;
end $$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_auth_user();

create trigger on_auth_user_updated
  after update of email, phone on auth.users
  for each row execute function public.handle_auth_user();

-- accounts that already exist (their old profile rows were dropped above)
insert into public.users (id, email, phone)
select u.id, u.email, u.phone from auth.users u
on conflict (id) do nothing;

insert into public.profiles (id, user_id, full_name)
select u.id, u.id, coalesce(trim(u.raw_user_meta_data ->> 'full_name'), '') from auth.users u
on conflict (user_id) do nothing;

insert into public.user_preferences (id, user_id)
select u.id, u.id from auth.users u
on conflict (user_id) do nothing;

-- ---------------------------------------------------------------------
-- Whoever creates an institute becomes its first (active) owner
-- ---------------------------------------------------------------------
create or replace function public.handle_new_institute()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.memberships (institute_id, user_id, role, status, decided_by, decided_at)
  values (new.id, new.owner_id, 'owner', 'active', new.owner_id, now())
  on conflict (institute_id, user_id) do nothing;
  return new;
end $$;

create trigger trg_institutes_owner_membership
  after insert on public.institutes
  for each row execute function public.handle_new_institute();

-- ---------------------------------------------------------------------
-- updated_at triggers
-- ---------------------------------------------------------------------
do $$
declare
  t text;
begin
  foreach t in array array[
    'users', 'profiles', 'user_preferences', 'sessions',
    'institutes', 'branches', 'memberships', 'invitations', 'institute_settings'
  ] loop
    execute format(
      'create trigger trg_%1$s_updated_at before update on public.%1$I
         for each row execute function public.set_updated_at()', t);
  end loop;
end $$;
