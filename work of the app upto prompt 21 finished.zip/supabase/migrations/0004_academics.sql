-- =====================================================================
-- 0004_academics.sql · GuruFlow data model, part 2 of 6
--   ACADEMICS  : student_profiles, guardians, student_memberships,
--                parent_links, student_history, teacher_profiles,
--                staff_records, teacher_assignments, workloads,
--                leave_requests
--   BATCHES    : batches, subjects, batch_students, batch_teachers,
--                timetables, classrooms
--   ATTENDANCE : attendance_sessions, attendance_records,
--                attendance_corrections
--   HOMEWORK   : assignments, submissions, attachments, feedback
--   EXAMS      : exams, exam_questions, marks, results
--   LEARNING   : materials, material_access, bookmarks,
--                practice_questions, quizzes, quiz_attempts,
--                study_tasks, student_goals
--
-- Tables are created in dependency order, not in the order above.
-- Rows that carry both batch_id and student_id reference
-- batch_students (institute_id, batch_id, student_id): a teacher can only
-- ever write about a student who is really enrolled in that batch.
-- =====================================================================

-- ---------------------------------------------------------------------
-- ACADEMICS · people
-- ---------------------------------------------------------------------

create table public.student_profiles (
  id             uuid primary key default gen_random_uuid(),
  institute_id   uuid not null references public.institutes (id) on delete cascade,
  branch_id      uuid,
  admission_no   text,
  full_name      text not null,
  date_of_birth  date,
  gender         text check (gender in ('male', 'female', 'other')),
  phone          text,
  email          text,
  address        text,
  city           text,
  school_name    text,
  class_grade    text,
  blood_group    text,
  photo_url      text,
  admitted_on    date not null default current_date,
  status         text not null default 'active' check (status in ('active', 'inactive', 'alumni', 'dropped')),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, admission_no),
  foreign key (institute_id, branch_id) references public.branches (institute_id, id) on delete set null (branch_id)
);

-- Parent / guardian contact record. membership_id is set once they have a login.
create table public.guardians (
  id             uuid primary key default gen_random_uuid(),
  institute_id   uuid not null references public.institutes (id) on delete cascade,
  membership_id  uuid unique,
  full_name      text not null,
  relation       text not null default 'guardian' check (relation in ('father', 'mother', 'guardian', 'other')),
  phone          text,
  email          text,
  occupation     text,
  address        text,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, membership_id) references public.memberships (institute_id, id) on delete set null (membership_id)
);

-- Student record ↔ the student's own login. The role is pinned to 'student'
-- by the composite foreign key, so a teacher/admin/owner/parent membership
-- can never be attached to a student record.
create table public.student_memberships (
  id               uuid primary key default gen_random_uuid(),
  institute_id     uuid not null references public.institutes (id) on delete cascade,
  student_id       uuid not null unique,
  membership_id    uuid not null unique,
  membership_role  text not null default 'student' check (membership_role = 'student'),
  linked_by        uuid references public.users (id) on delete set null,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, student_id) references public.student_profiles (institute_id, id) on delete cascade,
  foreign key (institute_id, membership_id, membership_role)
    references public.memberships (institute_id, id, role) on delete cascade
);

-- Student record ↔ guardian
create table public.parent_links (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  student_id    uuid not null,
  guardian_id   uuid not null,
  is_primary    boolean not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  unique (student_id, guardian_id),
  foreign key (institute_id, student_id) references public.student_profiles (institute_id, id) on delete cascade,
  foreign key (institute_id, guardian_id) references public.guardians (institute_id, id) on delete cascade
);
create index parent_links_guardian_idx on public.parent_links (guardian_id);

-- Public-facing teacher card (students can read it). Contact and pay
-- details live in staff_records.
create table public.teacher_profiles (
  id                uuid primary key default gen_random_uuid(),
  institute_id      uuid not null references public.institutes (id) on delete cascade,
  user_id           uuid,
  branch_id         uuid,
  full_name         text not null,
  specialization    text,
  qualification     text,
  experience_years  smallint check (experience_years >= 0),
  bio               text,
  photo_url         text,
  status            text not null default 'active' check (status in ('active', 'inactive')),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, user_id),
  foreign key (institute_id, user_id) references public.memberships (institute_id, user_id) on delete set null (user_id),
  foreign key (institute_id, branch_id) references public.branches (institute_id, id) on delete set null (branch_id)
);

-- Teachers are never students: a login whose membership role is 'student'
-- cannot be attached to a teacher profile. (The reverse direction is
-- enforced by student_memberships' role-pinned fk and by membership_guard.)
create or replace function public.teacher_not_student()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.user_id is not null and exists (
    select 1 from public.memberships m
    where m.institute_id = new.institute_id
      and m.user_id = new.user_id
      and m.role = 'student'
  ) then
    raise exception 'a student account cannot be a teacher in the same institute'
      using errcode = 'check_violation';
  end if;
  return new;
end $$;

create trigger trg_teacher_profiles_not_student
  before insert or update of user_id, institute_id on public.teacher_profiles
  for each row execute function public.teacher_not_student();

-- HR record. Owner / admin with 'staff' permission only (plus the person themself).
create table public.staff_records (
  id                 uuid primary key default gen_random_uuid(),
  institute_id       uuid not null references public.institutes (id) on delete cascade,
  user_id            uuid references public.users (id) on delete set null,
  teacher_id         uuid,
  employee_code      text,
  designation        text,
  department         text,
  employment_type    text not null default 'full_time'
                     check (employment_type in ('full_time', 'part_time', 'contract', 'visiting')),
  joined_on          date,
  left_on            date,
  salary_amount      numeric(12, 2) check (salary_amount >= 0),
  salary_period      text not null default 'monthly' check (salary_period in ('monthly', 'hourly', 'per_class')),
  phone              text,
  email              text,
  emergency_contact  text,
  bank_details       jsonb not null default '{}',
  status             text not null default 'active' check (status in ('active', 'on_leave', 'resigned', 'terminated')),
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, employee_code),
  foreign key (institute_id, teacher_id) references public.teacher_profiles (institute_id, id) on delete set null (teacher_id)
);

-- ---------------------------------------------------------------------
-- BATCHES
-- ---------------------------------------------------------------------

create table public.classrooms (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  branch_id     uuid,
  name          text not null,
  capacity      integer check (capacity > 0),
  floor         text,
  facilities    text[] not null default '{}',
  status        text not null default 'active' check (status in ('active', 'inactive')),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, branch_id) references public.branches (institute_id, id) on delete set null (branch_id)
);

create table public.subjects (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  name          text not null,
  code          text not null,
  color         text,
  description   text,
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, code)
);

create table public.batches (
  id             uuid primary key default gen_random_uuid(),
  institute_id   uuid not null references public.institutes (id) on delete cascade,
  branch_id      uuid,
  classroom_id   uuid,
  name           text not null,
  grade          text,
  section        text,
  academic_year  text not null,
  capacity       integer check (capacity > 0),
  starts_on      date,
  ends_on        date,
  status         text not null default 'active' check (status in ('upcoming', 'active', 'completed', 'archived')),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, name, academic_year),
  check (ends_on is null or starts_on is null or ends_on >= starts_on),
  foreign key (institute_id, branch_id) references public.branches (institute_id, id) on delete set null (branch_id),
  foreign key (institute_id, classroom_id) references public.classrooms (institute_id, id) on delete set null (classroom_id)
);

create table public.batch_students (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  batch_id      uuid not null,
  student_id    uuid not null,
  roll_number   integer check (roll_number > 0),
  joined_on     date not null default current_date,
  left_on       date,
  status        text not null default 'active' check (status in ('active', 'left', 'transferred')),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, batch_id, student_id),
  unique (batch_id, roll_number),
  foreign key (institute_id, batch_id) references public.batches (institute_id, id) on delete cascade,
  foreign key (institute_id, student_id) references public.student_profiles (institute_id, id) on delete cascade
);
create index batch_students_student_idx on public.batch_students (student_id);

-- Who teaches in a batch. This is the table that defines a teacher's
-- "own batches" for RLS, so writes need the 'staff' permission.
create table public.batch_teachers (
  id                uuid primary key default gen_random_uuid(),
  institute_id      uuid not null references public.institutes (id) on delete cascade,
  batch_id          uuid not null,
  teacher_id        uuid not null,
  subject_id        uuid,
  is_class_teacher  boolean not null default false,
  assigned_on       date not null default current_date,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, batch_id) references public.batches (institute_id, id) on delete cascade,
  foreign key (institute_id, teacher_id) references public.teacher_profiles (institute_id, id) on delete cascade,
  foreign key (institute_id, subject_id) references public.subjects (institute_id, id) on delete set null (subject_id)
);
create unique index batch_teachers_unique_idx
  on public.batch_teachers (batch_id, teacher_id, coalesce(subject_id, '00000000-0000-0000-0000-000000000000'));
create index batch_teachers_teacher_idx on public.batch_teachers (teacher_id);

create table public.timetables (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  batch_id      uuid not null,
  subject_id    uuid,
  teacher_id    uuid,
  classroom_id  uuid,
  day_of_week   smallint not null check (day_of_week between 0 and 6),   -- 0 = Sunday
  starts_at     time not null,
  ends_at       time not null,
  valid_from    date,
  valid_to      date,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  check (ends_at > starts_at),
  foreign key (institute_id, batch_id) references public.batches (institute_id, id) on delete cascade,
  foreign key (institute_id, subject_id) references public.subjects (institute_id, id) on delete set null (subject_id),
  foreign key (institute_id, teacher_id) references public.teacher_profiles (institute_id, id) on delete set null (teacher_id),
  foreign key (institute_id, classroom_id) references public.classrooms (institute_id, id) on delete set null (classroom_id)
);
create index timetables_batch_idx on public.timetables (batch_id, day_of_week);

-- ---------------------------------------------------------------------
-- ACADEMICS · records that depend on batches
-- ---------------------------------------------------------------------

create table public.student_history (
  id             uuid primary key default gen_random_uuid(),
  institute_id   uuid not null references public.institutes (id) on delete cascade,
  student_id     uuid not null,
  event_type     text not null
                 check (event_type in ('admitted', 'batch_joined', 'batch_left', 'promoted', 'status_changed', 'note')),
  title          text not null,
  details        jsonb not null default '{}',
  from_batch_id  uuid,
  to_batch_id    uuid,
  occurred_on    date not null default current_date,
  recorded_by    uuid references public.users (id) on delete set null,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, student_id) references public.student_profiles (institute_id, id) on delete cascade,
  foreign key (institute_id, from_batch_id) references public.batches (institute_id, id) on delete set null (from_batch_id),
  foreign key (institute_id, to_batch_id) references public.batches (institute_id, id) on delete set null (to_batch_id)
);
create index student_history_student_idx on public.student_history (student_id, occurred_on);

-- Staffing plan: which subject a teacher is engaged to teach, and how much.
create table public.teacher_assignments (
  id                uuid primary key default gen_random_uuid(),
  institute_id      uuid not null references public.institutes (id) on delete cascade,
  teacher_id        uuid not null,
  subject_id        uuid not null,
  batch_id          uuid,
  assignment_role   text not null default 'subject_teacher'
                    check (assignment_role in ('subject_teacher', 'class_teacher', 'substitute')),
  periods_per_week  smallint check (periods_per_week >= 0),
  starts_on         date,
  ends_on           date,
  status            text not null default 'active' check (status in ('active', 'ended')),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, teacher_id) references public.teacher_profiles (institute_id, id) on delete cascade,
  foreign key (institute_id, subject_id) references public.subjects (institute_id, id) on delete cascade,
  foreign key (institute_id, batch_id) references public.batches (institute_id, id) on delete cascade
);
create index teacher_assignments_teacher_idx on public.teacher_assignments (teacher_id);

create table public.workloads (
  id                uuid primary key default gen_random_uuid(),
  institute_id      uuid not null references public.institutes (id) on delete cascade,
  teacher_id        uuid not null,
  week_start        date not null,
  periods_assigned  smallint not null default 0 check (periods_assigned >= 0),
  periods_taken     smallint not null default 0 check (periods_taken >= 0),
  hours_assigned    numeric(5, 2) not null default 0 check (hours_assigned >= 0),
  hours_taken       numeric(5, 2) not null default 0 check (hours_taken >= 0),
  notes             text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (institute_id, id),
  unique (teacher_id, week_start),
  foreign key (institute_id, teacher_id) references public.teacher_profiles (institute_id, id) on delete cascade
);

-- Staff leave
create table public.leave_requests (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  user_id       uuid not null references public.users (id) on delete cascade,
  teacher_id    uuid,
  leave_type    text not null default 'casual' check (leave_type in ('casual', 'sick', 'earned', 'unpaid', 'other')),
  from_date     date not null,
  to_date       date not null,
  reason        text,
  status        text not null default 'pending' check (status in ('pending', 'approved', 'rejected', 'cancelled')),
  reviewed_by   uuid references public.users (id) on delete set null,
  reviewed_at   timestamptz,
  review_note   text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  check (to_date >= from_date),
  foreign key (institute_id, teacher_id) references public.teacher_profiles (institute_id, id) on delete set null (teacher_id)
);
create index leave_requests_user_idx on public.leave_requests (user_id);

-- ---------------------------------------------------------------------
-- ATTENDANCE
-- ---------------------------------------------------------------------

create table public.attendance_sessions (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  batch_id      uuid not null,
  subject_id    uuid,
  teacher_id    uuid,
  session_date  date not null,
  period        smallint not null default 1 check (period > 0),
  status        text not null default 'submitted' check (status in ('open', 'submitted', 'locked')),
  marked_by     uuid references public.users (id) on delete set null,
  marked_at     timestamptz,
  notes         text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, id, batch_id),
  unique (batch_id, session_date, period),
  foreign key (institute_id, batch_id) references public.batches (institute_id, id) on delete cascade,
  foreign key (institute_id, subject_id) references public.subjects (institute_id, id) on delete set null (subject_id),
  foreign key (institute_id, teacher_id) references public.teacher_profiles (institute_id, id) on delete set null (teacher_id)
);

create table public.attendance_records (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  session_id    uuid not null,
  batch_id      uuid not null,
  student_id    uuid not null,
  status        text not null check (status in ('present', 'absent', 'late', 'leave')),
  remark        text,
  marked_by     uuid references public.users (id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  unique (session_id, student_id),
  foreign key (institute_id, session_id, batch_id)
    references public.attendance_sessions (institute_id, id, batch_id) on delete cascade,
  foreign key (institute_id, batch_id, student_id)
    references public.batch_students (institute_id, batch_id, student_id) on delete cascade
);
create index attendance_records_student_idx on public.attendance_records (student_id);
create index attendance_records_batch_idx on public.attendance_records (batch_id);

create table public.attendance_corrections (
  id                uuid primary key default gen_random_uuid(),
  institute_id      uuid not null references public.institutes (id) on delete cascade,
  record_id         uuid not null,
  batch_id          uuid not null,
  student_id        uuid not null,
  requested_by      uuid references public.users (id) on delete set null,
  current_status    text not null check (current_status in ('present', 'absent', 'late', 'leave')),
  requested_status  text not null check (requested_status in ('present', 'absent', 'late', 'leave')),
  reason            text,
  status            text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  reviewed_by       uuid references public.users (id) on delete set null,
  reviewed_at       timestamptz,
  review_note       text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, record_id) references public.attendance_records (institute_id, id) on delete cascade,
  foreign key (institute_id, batch_id, student_id)
    references public.batch_students (institute_id, batch_id, student_id) on delete cascade
);
create index attendance_corrections_student_idx on public.attendance_corrections (student_id);
create index attendance_corrections_batch_idx on public.attendance_corrections (batch_id);

-- ---------------------------------------------------------------------
-- HOMEWORK
-- ---------------------------------------------------------------------

create table public.assignments (
  id               uuid primary key default gen_random_uuid(),
  institute_id     uuid not null references public.institutes (id) on delete cascade,
  batch_id         uuid not null,
  subject_id       uuid,
  teacher_id       uuid,
  title            text not null,
  instructions     text,
  assigned_on      date not null default current_date,
  due_at           timestamptz,
  max_marks        numeric(6, 2) check (max_marks >= 0),
  submission_type  text not null default 'written' check (submission_type in ('written', 'upload', 'online', 'none')),
  status           text not null default 'draft' check (status in ('draft', 'published', 'closed')),
  created_by       uuid references public.users (id) on delete set null,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, id, batch_id),
  foreign key (institute_id, batch_id) references public.batches (institute_id, id) on delete cascade,
  foreign key (institute_id, subject_id) references public.subjects (institute_id, id) on delete set null (subject_id),
  foreign key (institute_id, teacher_id) references public.teacher_profiles (institute_id, id) on delete set null (teacher_id)
);
create index assignments_batch_idx on public.assignments (batch_id, due_at);

-- The student's side of an assignment. Marks live in feedback, which
-- students cannot write.
create table public.submissions (
  id             uuid primary key default gen_random_uuid(),
  institute_id   uuid not null references public.institutes (id) on delete cascade,
  assignment_id  uuid not null,
  batch_id       uuid not null,
  student_id     uuid not null,
  content        text,
  submitted_at   timestamptz,
  status         text not null default 'submitted' check (status in ('pending', 'submitted', 'late', 'returned')),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, id, batch_id, student_id),
  unique (assignment_id, student_id),
  foreign key (institute_id, assignment_id, batch_id)
    references public.assignments (institute_id, id, batch_id) on delete cascade,
  foreign key (institute_id, batch_id, student_id)
    references public.batch_students (institute_id, batch_id, student_id) on delete cascade
);
create index submissions_student_idx on public.submissions (student_id);
create index submissions_batch_idx on public.submissions (batch_id);

-- Files attached to any record (entity_type + entity_id). batch_id /
-- student_id scope who may see the file.
create table public.attachments (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  entity_type   text not null
                check (entity_type in ('assignment', 'submission', 'feedback', 'material', 'exam', 'notice',
                                       'doubt', 'conversation', 'leave_request', 'lead', 'receipt')),
  entity_id     uuid not null,
  batch_id      uuid,
  student_id    uuid,
  file_name     text not null,
  storage_path  text not null,
  mime_type     text,
  size_bytes    bigint check (size_bytes >= 0),
  uploaded_by   uuid references public.users (id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, batch_id) references public.batches (institute_id, id) on delete cascade,
  foreign key (institute_id, student_id) references public.student_profiles (institute_id, id) on delete cascade,
  foreign key (institute_id, batch_id, student_id)
    references public.batch_students (institute_id, batch_id, student_id) on delete cascade
);
create index attachments_entity_idx on public.attachments (entity_type, entity_id);

-- Teacher's marks and comments on a submission
create table public.feedback (
  id             uuid primary key default gen_random_uuid(),
  institute_id   uuid not null references public.institutes (id) on delete cascade,
  submission_id  uuid not null,
  batch_id       uuid not null,
  student_id     uuid not null,
  teacher_id     uuid,
  marks_awarded  numeric(6, 2) check (marks_awarded >= 0),
  grade          text,
  comment        text,
  given_by       uuid references public.users (id) on delete set null,
  given_at       timestamptz not null default now(),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, submission_id, batch_id, student_id)
    references public.submissions (institute_id, id, batch_id, student_id) on delete cascade,
  foreign key (institute_id, teacher_id) references public.teacher_profiles (institute_id, id) on delete set null (teacher_id)
);
create index feedback_student_idx on public.feedback (student_id);
create index feedback_batch_idx on public.feedback (batch_id);

-- ---------------------------------------------------------------------
-- EXAMS
-- ---------------------------------------------------------------------

-- One exam covers several subjects; per-subject scores are in marks.
create table public.exams (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  batch_id      uuid not null,
  name          text not null,
  exam_type     text not null default 'unit_test'
                check (exam_type in ('unit_test', 'weekly_test', 'mid_term', 'final', 'mock', 'other')),
  starts_on     date,
  ends_on       date,
  total_marks   numeric(7, 2) check (total_marks >= 0),
  pass_percent  numeric(5, 2) not null default 33 check (pass_percent between 0 and 100),
  status        text not null default 'draft'
                check (status in ('draft', 'scheduled', 'ongoing', 'completed', 'published')),
  published_at  timestamptz,
  created_by    uuid references public.users (id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, id, batch_id),
  check (ends_on is null or starts_on is null or ends_on >= starts_on),
  foreign key (institute_id, batch_id) references public.batches (institute_id, id) on delete cascade
);
create index exams_batch_idx on public.exams (batch_id);

create table public.exam_questions (
  id             uuid primary key default gen_random_uuid(),
  institute_id   uuid not null references public.institutes (id) on delete cascade,
  exam_id        uuid not null,
  batch_id       uuid not null,
  subject_id     uuid,
  question_no    integer not null check (question_no > 0),
  question_text  text not null,
  question_type  text not null default 'short' check (question_type in ('mcq', 'short', 'long', 'numerical')),
  options        jsonb,
  answer_key     text,
  max_marks      numeric(6, 2) not null default 1 check (max_marks >= 0),
  topic          text,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, exam_id, batch_id) references public.exams (institute_id, id, batch_id) on delete cascade,
  foreign key (institute_id, subject_id) references public.subjects (institute_id, id) on delete set null (subject_id)
);
create unique index exam_questions_unique_idx
  on public.exam_questions (exam_id, coalesce(subject_id, '00000000-0000-0000-0000-000000000000'), question_no);

create table public.marks (
  id              uuid primary key default gen_random_uuid(),
  institute_id    uuid not null references public.institutes (id) on delete cascade,
  exam_id         uuid not null,
  batch_id        uuid not null,
  student_id      uuid not null,
  subject_id      uuid not null,
  marks_obtained  numeric(6, 2),
  max_marks       numeric(6, 2) not null check (max_marks > 0),
  is_absent       boolean not null default false,
  grade           text,
  remark          text,
  entered_by      uuid references public.users (id) on delete set null,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (institute_id, id),
  unique (exam_id, student_id, subject_id),
  check (marks_obtained is null or marks_obtained between 0 and max_marks),
  check (not is_absent or marks_obtained is null),
  foreign key (institute_id, exam_id, batch_id) references public.exams (institute_id, id, batch_id) on delete cascade,
  foreign key (institute_id, batch_id, student_id)
    references public.batch_students (institute_id, batch_id, student_id) on delete cascade,
  foreign key (institute_id, subject_id) references public.subjects (institute_id, id) on delete cascade
);
create index marks_student_idx on public.marks (student_id);
create index marks_batch_idx on public.marks (batch_id);

create table public.results (
  id              uuid primary key default gen_random_uuid(),
  institute_id    uuid not null references public.institutes (id) on delete cascade,
  exam_id         uuid not null,
  batch_id        uuid not null,
  student_id      uuid not null,
  total_obtained  numeric(7, 2) not null default 0 check (total_obtained >= 0),
  total_max       numeric(7, 2) not null check (total_max > 0),
  percentage      numeric(5, 2) not null check (percentage between 0 and 100),
  grade           text,
  rank            integer check (rank > 0),
  result_status   text not null default 'pass' check (result_status in ('pass', 'fail', 'absent', 'withheld')),
  remarks         text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (institute_id, id),
  unique (exam_id, student_id),
  foreign key (institute_id, exam_id, batch_id) references public.exams (institute_id, id, batch_id) on delete cascade,
  foreign key (institute_id, batch_id, student_id)
    references public.batch_students (institute_id, batch_id, student_id) on delete cascade
);
create index results_student_idx on public.results (student_id);
create index results_batch_idx on public.results (batch_id);

-- ---------------------------------------------------------------------
-- LEARNING
-- ---------------------------------------------------------------------

-- batch_id null = shared with the whole institute
create table public.materials (
  id             uuid primary key default gen_random_uuid(),
  institute_id   uuid not null references public.institutes (id) on delete cascade,
  batch_id       uuid,
  subject_id     uuid,
  teacher_id     uuid,
  title          text not null,
  description    text,
  material_type  text not null default 'notes'
                 check (material_type in ('notes', 'pdf', 'video', 'link', 'worksheet', 'book')),
  url            text,
  storage_path   text,
  topic          text,
  is_published   boolean not null default true,
  uploaded_by    uuid references public.users (id) on delete set null,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, batch_id) references public.batches (institute_id, id) on delete cascade,
  foreign key (institute_id, subject_id) references public.subjects (institute_id, id) on delete set null (subject_id),
  foreign key (institute_id, teacher_id) references public.teacher_profiles (institute_id, id) on delete set null (teacher_id)
);
create index materials_batch_idx on public.materials (batch_id);

-- Per-student open / progress tracking for a material
create table public.material_access (
  id                uuid primary key default gen_random_uuid(),
  institute_id      uuid not null references public.institutes (id) on delete cascade,
  material_id       uuid not null,
  student_id        uuid not null,
  first_opened_at   timestamptz not null default now(),
  last_opened_at    timestamptz not null default now(),
  open_count        integer not null default 1 check (open_count >= 0),
  progress_percent  numeric(5, 2) not null default 0 check (progress_percent between 0 and 100),
  completed_at      timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (institute_id, id),
  unique (material_id, student_id),
  foreign key (institute_id, material_id) references public.materials (institute_id, id) on delete cascade,
  foreign key (institute_id, student_id) references public.student_profiles (institute_id, id) on delete cascade
);
create index material_access_student_idx on public.material_access (student_id);

create table public.bookmarks (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  user_id       uuid not null references public.users (id) on delete cascade,
  target_type   text not null
                check (target_type in ('material', 'practice_question', 'assignment', 'notice', 'doubt')),
  target_id     uuid not null,
  note          text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  unique (user_id, target_type, target_id)
);

create table public.practice_questions (
  id              uuid primary key default gen_random_uuid(),
  institute_id    uuid not null references public.institutes (id) on delete cascade,
  batch_id        uuid,
  subject_id      uuid,
  topic           text,
  difficulty      text not null default 'medium' check (difficulty in ('easy', 'medium', 'hard')),
  question_type   text not null default 'mcq' check (question_type in ('mcq', 'true_false', 'short')),
  question_text   text not null,
  options         jsonb,
  correct_answer  text,
  explanation     text,
  marks           numeric(6, 2) not null default 1 check (marks >= 0),
  is_published    boolean not null default true,
  created_by      uuid references public.users (id) on delete set null,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, batch_id) references public.batches (institute_id, id) on delete cascade,
  foreign key (institute_id, subject_id) references public.subjects (institute_id, id) on delete set null (subject_id)
);
create index practice_questions_subject_idx on public.practice_questions (subject_id);

create table public.quizzes (
  id                uuid primary key default gen_random_uuid(),
  institute_id      uuid not null references public.institutes (id) on delete cascade,
  batch_id          uuid not null,
  subject_id        uuid,
  teacher_id        uuid,
  title             text not null,
  description       text,
  question_ids      uuid[] not null default '{}',      -- practice_questions.id, in order
  duration_minutes  integer check (duration_minutes > 0),
  total_marks       numeric(6, 2) check (total_marks >= 0),
  opens_at          timestamptz,
  closes_at         timestamptz,
  status            text not null default 'draft' check (status in ('draft', 'published', 'closed')),
  created_by        uuid references public.users (id) on delete set null,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, id, batch_id),
  foreign key (institute_id, batch_id) references public.batches (institute_id, id) on delete cascade,
  foreign key (institute_id, subject_id) references public.subjects (institute_id, id) on delete set null (subject_id),
  foreign key (institute_id, teacher_id) references public.teacher_profiles (institute_id, id) on delete set null (teacher_id)
);
create index quizzes_batch_idx on public.quizzes (batch_id);

create table public.quiz_attempts (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  quiz_id       uuid not null,
  batch_id      uuid not null,
  student_id    uuid not null,
  attempt_no    smallint not null default 1 check (attempt_no > 0),
  started_at    timestamptz not null default now(),
  submitted_at  timestamptz,
  answers       jsonb not null default '{}',
  score         numeric(6, 2) check (score >= 0),
  max_score     numeric(6, 2) check (max_score >= 0),
  status        text not null default 'in_progress' check (status in ('in_progress', 'submitted', 'graded')),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  unique (quiz_id, student_id, attempt_no),
  foreign key (institute_id, quiz_id, batch_id) references public.quizzes (institute_id, id, batch_id) on delete cascade,
  foreign key (institute_id, batch_id, student_id)
    references public.batch_students (institute_id, batch_id, student_id) on delete cascade
);
create index quiz_attempts_student_idx on public.quiz_attempts (student_id);
create index quiz_attempts_batch_idx on public.quiz_attempts (batch_id);

create table public.study_tasks (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  student_id    uuid not null,
  subject_id    uuid,
  title         text not null,
  notes         text,
  due_on        date,
  priority      text not null default 'medium' check (priority in ('low', 'medium', 'high')),
  status        text not null default 'todo' check (status in ('todo', 'in_progress', 'done')),
  completed_at  timestamptz,
  source        text not null default 'self' check (source in ('self', 'teacher', 'system')),
  assigned_by   uuid references public.users (id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, student_id) references public.student_profiles (institute_id, id) on delete cascade,
  foreign key (institute_id, subject_id) references public.subjects (institute_id, id) on delete set null (subject_id)
);
create index study_tasks_student_idx on public.study_tasks (student_id, status);

create table public.student_goals (
  id             uuid primary key default gen_random_uuid(),
  institute_id   uuid not null references public.institutes (id) on delete cascade,
  student_id     uuid not null,
  subject_id     uuid,
  title          text not null,
  description    text,
  metric         text not null default 'custom'
                 check (metric in ('attendance_percent', 'exam_percent', 'study_hours', 'custom')),
  target_value   numeric(8, 2),
  current_value  numeric(8, 2),
  starts_on      date not null default current_date,
  target_date    date,
  status         text not null default 'active' check (status in ('active', 'achieved', 'missed', 'abandoned')),
  created_by     uuid references public.users (id) on delete set null,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, student_id) references public.student_profiles (institute_id, id) on delete cascade,
  foreign key (institute_id, subject_id) references public.subjects (institute_id, id) on delete set null (subject_id)
);
create index student_goals_student_idx on public.student_goals (student_id, status);

-- ---------------------------------------------------------------------
-- updated_at triggers
-- ---------------------------------------------------------------------
do $$
declare
  t text;
begin
  foreach t in array array[
    'student_profiles', 'guardians', 'student_memberships', 'parent_links', 'student_history',
    'teacher_profiles', 'staff_records', 'teacher_assignments', 'workloads', 'leave_requests',
    'batches', 'subjects', 'batch_students', 'batch_teachers', 'timetables', 'classrooms',
    'attendance_sessions', 'attendance_records', 'attendance_corrections',
    'assignments', 'submissions', 'attachments', 'feedback',
    'exams', 'exam_questions', 'marks', 'results',
    'materials', 'material_access', 'bookmarks', 'practice_questions',
    'quizzes', 'quiz_attempts', 'study_tasks', 'student_goals'
  ] loop
    execute format(
      'create trigger trg_%1$s_updated_at before update on public.%1$I
         for each row execute function public.set_updated_at()', t);
  end loop;
end $$;
