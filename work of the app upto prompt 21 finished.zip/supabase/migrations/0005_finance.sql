-- =====================================================================
-- 0005_finance.sql · GuruFlow data model, part 3 of 6
--   FINANCE : fee_structures, student_fees, installments, payments,
--             receipts, refunds
--
-- Amounts are numeric(12,2) in the institute's currency (INR by default).
-- Every row below student_fees carries student_id, and composite foreign
-- keys keep it equal to the student on the parent row – that column is
-- what student/parent RLS filters on.
-- =====================================================================

create table public.fee_structures (
  id                 uuid primary key default gen_random_uuid(),
  institute_id       uuid not null references public.institutes (id) on delete cascade,
  batch_id           uuid,
  name               text not null,
  academic_year      text not null,
  total_amount       numeric(12, 2) not null check (total_amount >= 0),
  installment_count  smallint not null default 1 check (installment_count > 0),
  frequency          text not null default 'term'
                     check (frequency in ('one_time', 'monthly', 'quarterly', 'term', 'yearly')),
  components         jsonb not null default '[]',          -- [{ "label": "Tuition", "amount": 30000 }, …]
  late_fee_per_day   numeric(12, 2) not null default 0 check (late_fee_per_day >= 0),
  is_active          boolean not null default true,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, batch_id) references public.batches (institute_id, id) on delete set null (batch_id)
);

create table public.student_fees (
  id                uuid primary key default gen_random_uuid(),
  institute_id      uuid not null references public.institutes (id) on delete cascade,
  student_id        uuid not null,
  fee_structure_id  uuid not null,
  academic_year     text not null,
  gross_amount      numeric(12, 2) not null check (gross_amount >= 0),
  discount_amount   numeric(12, 2) not null default 0 check (discount_amount >= 0),
  discount_reason   text,
  net_amount        numeric(12, 2) generated always as (gross_amount - discount_amount) stored,
  status            text not null default 'active' check (status in ('active', 'settled', 'cancelled')),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, id, student_id),
  unique (student_id, fee_structure_id),
  check (discount_amount <= gross_amount),
  foreign key (institute_id, student_id) references public.student_profiles (institute_id, id) on delete cascade,
  foreign key (institute_id, fee_structure_id) references public.fee_structures (institute_id, id)
);

-- One row per fee term
create table public.installments (
  id              uuid primary key default gen_random_uuid(),
  institute_id    uuid not null references public.institutes (id) on delete cascade,
  student_fee_id  uuid not null,
  student_id      uuid not null,
  term_no         smallint not null check (term_no > 0),
  label           text not null,
  amount          numeric(12, 2) not null check (amount >= 0),
  due_date        date not null,
  paid_amount     numeric(12, 2) not null default 0 check (paid_amount >= 0),
  paid_on         date,
  status          text not null default 'upcoming'
                  check (status in ('upcoming', 'due', 'partial', 'paid', 'overdue', 'waived')),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, id, student_id),
  unique (student_fee_id, term_no),
  check (paid_amount <= amount),
  foreign key (institute_id, student_fee_id, student_id)
    references public.student_fees (institute_id, id, student_id) on delete cascade
);
create index installments_student_idx on public.installments (student_id, due_date);

create table public.payments (
  id              uuid primary key default gen_random_uuid(),
  institute_id    uuid not null references public.institutes (id) on delete cascade,
  student_id      uuid not null,
  student_fee_id  uuid not null,
  installment_id  uuid,
  amount          numeric(12, 2) not null check (amount > 0),
  method          text not null check (method in ('cash', 'upi', 'card', 'bank_transfer', 'cheque', 'online')),
  reference_no    text,
  paid_at         timestamptz not null default now(),
  status          text not null default 'completed' check (status in ('pending', 'completed', 'failed', 'refunded')),
  received_by     uuid references public.users (id) on delete set null,
  notes           text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, id, student_id),
  foreign key (institute_id, student_fee_id, student_id)
    references public.student_fees (institute_id, id, student_id),
  foreign key (institute_id, installment_id, student_id)
    references public.installments (institute_id, id, student_id)
);
create index payments_student_idx on public.payments (student_id, paid_at);
create index payments_installment_idx on public.payments (installment_id);

create table public.receipts (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  payment_id    uuid not null unique,
  student_id    uuid not null,
  receipt_no    text not null,
  amount        numeric(12, 2) not null check (amount > 0),
  issued_at     timestamptz not null default now(),
  issued_by     uuid references public.users (id) on delete set null,
  pdf_path      text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, receipt_no),
  foreign key (institute_id, payment_id, student_id)
    references public.payments (institute_id, id, student_id)
);
create index receipts_student_idx on public.receipts (student_id);

create table public.refunds (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  payment_id    uuid not null,
  student_id    uuid not null,
  amount        numeric(12, 2) not null check (amount > 0),
  reason        text,
  method        text check (method in ('cash', 'upi', 'card', 'bank_transfer', 'cheque', 'online')),
  reference_no  text,
  status        text not null default 'requested' check (status in ('requested', 'approved', 'processed', 'rejected')),
  requested_by  uuid references public.users (id) on delete set null,
  approved_by   uuid references public.users (id) on delete set null,
  processed_at  timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, payment_id, student_id)
    references public.payments (institute_id, id, student_id)
);
create index refunds_student_idx on public.refunds (student_id);

do $$
declare
  t text;
begin
  foreach t in array array[
    'fee_structures', 'student_fees', 'installments', 'payments', 'receipts', 'refunds'
  ] loop
    execute format(
      'create trigger trg_%1$s_updated_at before update on public.%1$I
         for each row execute function public.set_updated_at()', t);
  end loop;
end $$;
