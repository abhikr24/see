-- =====================================================================
-- 0006_communication.sql · GuruFlow data model, part 4 of 6
--   COMMUNICATION : notices, notifications, conversations, doubts,
--                   teacher_feedback, meeting_requests
-- =====================================================================

-- batch_id null = whole institute. audience = roles that may read it.
-- published_at null = draft.
create table public.notices (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  batch_id      uuid,
  title         text not null,
  body          text not null default '',
  category      text not null default 'general'
                check (category in ('general', 'academic', 'exam', 'fee', 'holiday', 'event', 'urgent')),
  audience      text[] not null default '{owner,admin,teacher,student,parent}'
                check (audience <@ array['owner', 'admin', 'teacher', 'student', 'parent']
                       and cardinality(audience) > 0),
  is_pinned     boolean not null default false,
  published_at  timestamptz,
  expires_at    timestamptz,
  created_by    uuid references public.users (id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, batch_id) references public.batches (institute_id, id) on delete cascade
);
create index notices_published_idx on public.notices (institute_id, published_at desc);

-- One row per recipient
create table public.notifications (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  user_id       uuid not null references public.users (id) on delete cascade,
  type          text not null default 'general',
  title         text not null,
  body          text,
  data          jsonb not null default '{}',
  channel       text not null default 'in_app' check (channel in ('in_app', 'push', 'sms', 'email', 'whatsapp')),
  sent_at       timestamptz,
  read_at       timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id)
);
create index notifications_user_idx on public.notifications (user_id, read_at, created_at desc);

-- A thread and its messages. The model has no separate messages table, so
-- messages is an ordered json array of
--   { "id", "sender_id", "body", "sent_at" }
create table public.conversations (
  id                    uuid primary key default gen_random_uuid(),
  institute_id          uuid not null references public.institutes (id) on delete cascade,
  kind                  text not null default 'direct' check (kind in ('direct', 'parent_teacher', 'group', 'support')),
  title                 text,
  student_id            uuid,                               -- the student the thread is about, if any
  participant_ids       uuid[] not null check (cardinality(participant_ids) > 0),   -- users.id
  messages              jsonb not null default '[]' check (jsonb_typeof(messages) = 'array'),
  last_message_preview  text,
  last_message_at       timestamptz,
  is_archived           boolean not null default false,
  created_by            uuid references public.users (id) on delete set null,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, student_id) references public.student_profiles (institute_id, id) on delete cascade
);
create index conversations_participants_idx on public.conversations using gin (participant_ids);

create table public.doubts (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  batch_id      uuid not null,
  student_id    uuid not null,
  subject_id    uuid,
  teacher_id    uuid,                                       -- who it is addressed to
  asked_by      uuid references public.users (id) on delete set null,
  topic         text,
  question      text not null,
  answer        text,
  answered_by   uuid references public.users (id) on delete set null,
  answered_at   timestamptz,
  status        text not null default 'open' check (status in ('open', 'answered', 'resolved', 'closed')),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, batch_id, student_id)
    references public.batch_students (institute_id, batch_id, student_id) on delete cascade,
  foreign key (institute_id, subject_id) references public.subjects (institute_id, id) on delete set null (subject_id),
  foreign key (institute_id, teacher_id) references public.teacher_profiles (institute_id, id) on delete set null (teacher_id)
);
create index doubts_student_idx on public.doubts (student_id);
create index doubts_batch_idx on public.doubts (batch_id, status);

-- A teacher's remark about a student, optionally shared with the family
create table public.teacher_feedback (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  batch_id      uuid not null,
  student_id    uuid not null,
  teacher_id    uuid,
  subject_id    uuid,
  category      text not null default 'general'
                check (category in ('academic', 'behaviour', 'attendance', 'homework', 'general')),
  sentiment     text not null default 'neutral' check (sentiment in ('positive', 'neutral', 'needs_attention')),
  comment       text not null,
  is_shared     boolean not null default true,              -- visible to the student and parents
  created_by    uuid references public.users (id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, batch_id, student_id)
    references public.batch_students (institute_id, batch_id, student_id) on delete cascade,
  foreign key (institute_id, teacher_id) references public.teacher_profiles (institute_id, id) on delete set null (teacher_id),
  foreign key (institute_id, subject_id) references public.subjects (institute_id, id) on delete set null (subject_id)
);
create index teacher_feedback_student_idx on public.teacher_feedback (student_id);
create index teacher_feedback_batch_idx on public.teacher_feedback (batch_id);

-- Parent–teacher meeting
create table public.meeting_requests (
  id                uuid primary key default gen_random_uuid(),
  institute_id      uuid not null references public.institutes (id) on delete cascade,
  student_id        uuid not null,
  teacher_id        uuid not null,
  guardian_id       uuid,
  requested_by      uuid references public.users (id) on delete set null,
  reason            text,
  preferred_at      timestamptz,
  scheduled_at      timestamptz,
  duration_minutes  integer check (duration_minutes > 0),
  mode              text not null default 'in_person' check (mode in ('in_person', 'phone', 'video')),
  status            text not null default 'pending'
                    check (status in ('pending', 'accepted', 'declined', 'completed', 'cancelled')),
  response_note     text,
  responded_at      timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, student_id) references public.student_profiles (institute_id, id) on delete cascade,
  foreign key (institute_id, teacher_id) references public.teacher_profiles (institute_id, id) on delete cascade,
  foreign key (institute_id, guardian_id) references public.guardians (institute_id, id) on delete set null (guardian_id)
);
create index meeting_requests_student_idx on public.meeting_requests (student_id);
create index meeting_requests_teacher_idx on public.meeting_requests (teacher_id, status);

do $$
declare
  t text;
begin
  foreach t in array array[
    'notices', 'notifications', 'conversations', 'doubts', 'teacher_feedback', 'meeting_requests'
  ] loop
    execute format(
      'create trigger trg_%1$s_updated_at before update on public.%1$I
         for each row execute function public.set_updated_at()', t);
  end loop;
end $$;
