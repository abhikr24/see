-- =====================================================================
-- 0007_business.sql · GuruFlow data model, part 5 of 6
--   BUSINESS : admission_leads, lead_followups, plans, subscriptions,
--              usage_records, audit_logs
--
-- plans is tenant-scoped like everything else outside the GLOBAL group:
-- each institute holds its own copy of the plan it is on (limits and
-- price can be negotiated per institute), so no table is readable across
-- institutes. plans / subscriptions / usage_records are written by the
-- service role only.
-- =====================================================================

create table public.admission_leads (
  id                    uuid primary key default gen_random_uuid(),
  institute_id          uuid not null references public.institutes (id) on delete cascade,
  branch_id             uuid,
  student_name          text not null,
  guardian_name         text,
  phone                 text,
  email                 text,
  class_interested      text,
  school_name           text,
  source                text not null default 'walk_in'
                        check (source in ('walk_in', 'referral', 'website', 'social', 'phone', 'campaign', 'other')),
  stage                 text not null default 'new'
                        check (stage in ('new', 'contacted', 'interested', 'demo_scheduled', 'demo_attended',
                                         'negotiation', 'enrolled', 'lost')),
  assigned_to           uuid references public.users (id) on delete set null,
  expected_fee          numeric(12, 2) check (expected_fee >= 0),
  next_followup_at      timestamptz,
  lost_reason           text,
  converted_student_id  uuid,
  notes                 text,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, branch_id) references public.branches (institute_id, id) on delete set null (branch_id),
  foreign key (institute_id, converted_student_id)
    references public.student_profiles (institute_id, id) on delete set null (converted_student_id)
);
create index admission_leads_stage_idx on public.admission_leads (institute_id, stage);

create table public.lead_followups (
  id                uuid primary key default gen_random_uuid(),
  institute_id      uuid not null references public.institutes (id) on delete cascade,
  lead_id           uuid not null,
  channel           text not null default 'call' check (channel in ('call', 'whatsapp', 'sms', 'email', 'visit')),
  summary           text,
  outcome           text check (outcome in ('no_answer', 'interested', 'callback', 'demo_booked',
                                            'not_interested', 'enrolled')),
  followup_at       timestamptz not null default now(),
  next_followup_at  timestamptz,
  done_by           uuid references public.users (id) on delete set null,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, lead_id) references public.admission_leads (institute_id, id) on delete cascade
);
create index lead_followups_lead_idx on public.lead_followups (lead_id, followup_at);

create table public.plans (
  id             uuid primary key default gen_random_uuid(),
  institute_id   uuid not null references public.institutes (id) on delete cascade,
  code           text not null,
  name           text not null,
  price_monthly  numeric(12, 2) not null default 0 check (price_monthly >= 0),
  price_yearly   numeric(12, 2) not null default 0 check (price_yearly >= 0),
  currency       text not null default 'INR',
  max_students   integer check (max_students >= 0),          -- null = unlimited
  max_teachers   integer check (max_teachers >= 0),
  max_branches   integer check (max_branches >= 0),
  storage_mb     integer check (storage_mb >= 0),
  features       jsonb not null default '{}',
  is_active      boolean not null default true,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, code)
);

create table public.subscriptions (
  id                        uuid primary key default gen_random_uuid(),
  institute_id              uuid not null references public.institutes (id) on delete cascade,
  plan_id                   uuid not null,
  status                    text not null default 'trialing'
                            check (status in ('trialing', 'active', 'past_due', 'cancelled', 'expired')),
  billing_cycle             text not null default 'monthly' check (billing_cycle in ('monthly', 'yearly')),
  current_period_start      timestamptz not null default now(),
  current_period_end        timestamptz,
  trial_ends_at             timestamptz,
  cancel_at                 timestamptz,
  cancelled_at              timestamptz,
  provider                  text,
  provider_subscription_id  text,
  created_at                timestamptz not null default now(),
  updated_at                timestamptz not null default now(),
  unique (institute_id, id),
  foreign key (institute_id, plan_id) references public.plans (institute_id, id)
);
-- at most one live subscription per institute
create unique index subscriptions_live_idx
  on public.subscriptions (institute_id) where status in ('trialing', 'active', 'past_due');

create table public.usage_records (
  id               uuid primary key default gen_random_uuid(),
  institute_id     uuid not null references public.institutes (id) on delete cascade,
  subscription_id  uuid,
  metric           text not null
                   check (metric in ('students', 'teachers', 'branches', 'storage_mb', 'sms', 'notifications')),
  quantity         numeric(14, 2) not null default 0 check (quantity >= 0),
  period_start     date not null,
  period_end       date not null,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  unique (institute_id, id),
  unique (institute_id, metric, period_start),
  check (period_end >= period_start),
  foreign key (institute_id, subscription_id)
    references public.subscriptions (institute_id, id) on delete set null (subscription_id)
);

-- Append-only for clients: RLS grants insert + select, never update/delete.
create table public.audit_logs (
  id            uuid primary key default gen_random_uuid(),
  institute_id  uuid not null references public.institutes (id) on delete cascade,
  actor_id      uuid references public.users (id) on delete set null,
  actor_role    text,
  action        text not null,
  entity_type   text,
  entity_id     uuid,
  old_data      jsonb,
  new_data      jsonb,
  ip_address    inet,
  user_agent    text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (institute_id, id)
);
create index audit_logs_recent_idx on public.audit_logs (institute_id, created_at desc);
create index audit_logs_entity_idx on public.audit_logs (entity_type, entity_id);

do $$
declare
  t text;
begin
  foreach t in array array[
    'admission_leads', 'lead_followups', 'plans', 'subscriptions', 'usage_records', 'audit_logs'
  ] loop
    execute format(
      'create trigger trg_%1$s_updated_at before update on public.%1$I
         for each row execute function public.set_updated_at()', t);
  end loop;
end $$;
