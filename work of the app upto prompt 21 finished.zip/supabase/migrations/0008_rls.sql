-- =====================================================================
-- 0008_rls.sql · GuruFlow data model, part 6 of 6
--   Helper functions, guard triggers, row level security for all 62
--   tables, and grants.
--
-- Rules
--   · A row is visible only if institute_id = any(auth_institute_ids())
--     AND the caller's role permits it.
--   · auth_institute_ids() counts ACTIVE memberships only, so a pending,
--     suspended or rejected member sees nothing. The one exception is
--     their own memberships row, so the app can show "awaiting approval".
--   · student / parent : additionally limited to my_student_ids().
--   · teacher          : attendance, marks, assignments, materials,
--                        doubts … for the batches in batch_teachers.
--   · owner            : everything. admin: everything academic; fees,
--                        institute, members, staff, leads, billing and
--                        audit only with the matching entry in
--                        memberships.permissions.
--   · anon             : nothing. Service role bypasses RLS.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Helper functions
--    security definer so they can read membership tables without
--    recursing into RLS; they only ever report on the calling user.
-- ---------------------------------------------------------------------
drop function if exists public.auth_institute_ids() cascade;
drop function if exists public.has_role(uuid, text[]) cascade;
drop function if exists public.has_permission(uuid, text) cascade;
drop function if exists public.my_student_ids() cascade;
drop function if exists public.my_teacher_ids() cascade;
drop function if exists public.my_batch_ids() cascade;
drop function if exists public.my_student_batch_ids() cascade;
drop function if exists public.my_taught_student_ids() cascade;
drop function if exists public.is_staff_over(uuid) cascade;
drop function if exists public.can_view_profile(uuid) cascade;

-- Institutes where the caller has an active membership
create function public.auth_institute_ids()
returns uuid[]
language sql stable security definer
set search_path = ''
as $$
  select coalesce(array_agg(m.institute_id), '{}'::uuid[])
  from public.memberships m
  where m.user_id = (select auth.uid())
    and m.status = 'active';
$$;

-- Does the caller hold one of these roles (actively) in the institute?
create function public.has_role(inst uuid, roles text[])
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.memberships m
    where m.institute_id = inst
      and m.user_id = (select auth.uid())
      and m.status = 'active'
      and m.role = any (roles)
  );
$$;

-- Owner, or admin who has been granted this permission
create function public.has_permission(inst uuid, perm text)
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.memberships m
    where m.institute_id = inst
      and m.user_id = (select auth.uid())
      and m.status = 'active'
      and (m.role = 'owner' or (m.role = 'admin' and perm = any (m.permissions)))
  );
$$;

-- Student records the caller may see as a student (their own) or as a
-- parent (their children)
create function public.my_student_ids()
returns uuid[]
language sql stable security definer
set search_path = ''
as $$
  select coalesce(array_agg(s.student_id), '{}'::uuid[])
  from (
    select sm.student_id
    from public.student_memberships sm
    join public.memberships m on m.id = sm.membership_id
    where m.user_id = (select auth.uid())
      and m.status = 'active'
    union
    select pl.student_id
    from public.parent_links pl
    join public.guardians g on g.id = pl.guardian_id
    join public.memberships m on m.id = g.membership_id
    where m.user_id = (select auth.uid())
      and m.status = 'active'
  ) s;
$$;

-- The caller's teacher profile(s)
create function public.my_teacher_ids()
returns uuid[]
language sql stable security definer
set search_path = ''
as $$
  select coalesce(array_agg(t.id), '{}'::uuid[])
  from public.teacher_profiles t
  join public.memberships m
    on m.institute_id = t.institute_id and m.user_id = t.user_id
  where t.user_id = (select auth.uid())
    and t.status = 'active'
    and m.status = 'active'
    and m.role in ('owner', 'admin', 'teacher');
$$;

-- Batches the caller teaches ("own batches")
create function public.my_batch_ids()
returns uuid[]
language sql stable security definer
set search_path = ''
as $$
  select coalesce(array_agg(distinct bt.batch_id), '{}'::uuid[])
  from public.batch_teachers bt
  where bt.teacher_id = any (public.my_teacher_ids());
$$;

-- Batches the caller's students are currently enrolled in
create function public.my_student_batch_ids()
returns uuid[]
language sql stable security definer
set search_path = ''
as $$
  select coalesce(array_agg(distinct bs.batch_id), '{}'::uuid[])
  from public.batch_students bs
  where bs.student_id = any (public.my_student_ids())
    and bs.status = 'active';
$$;

-- Students enrolled in the batches the caller teaches
create function public.my_taught_student_ids()
returns uuid[]
language sql stable security definer
set search_path = ''
as $$
  select coalesce(array_agg(distinct bs.student_id), '{}'::uuid[])
  from public.batch_students bs
  where bs.batch_id = any (public.my_batch_ids());
$$;

-- Is the caller an active owner/admin of an institute this user belongs
-- to (in any status – staff must be able to see who is asking to join)?
create function public.is_staff_over(target uuid)
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.memberships me
    join public.memberships them on them.institute_id = me.institute_id
    where me.user_id = (select auth.uid())
      and me.status = 'active'
      and me.role in ('owner', 'admin')
      and them.user_id = target
  );
$$;

-- Own profile; staff see every member's; everyone else sees the profiles
-- of active owners, admins and teachers of their institute.
create function public.can_view_profile(target uuid)
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select target = (select auth.uid())
      or exists (
        select 1
        from public.memberships me
        join public.memberships them on them.institute_id = me.institute_id
        where me.user_id = (select auth.uid())
          and me.status = 'active'
          and them.user_id = target
          and (me.role in ('owner', 'admin')
               or (them.status = 'active' and them.role in ('owner', 'admin', 'teacher')))
      );
$$;

-- ---------------------------------------------------------------------
-- 2. Guards
-- ---------------------------------------------------------------------

-- memberships: only an owner can change a role (or hand out admin
-- powers). Runs for every caller; requests without a user (service role,
-- SQL editor, migrations, seed) skip the actor checks.
create or replace function public.membership_guard()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor           uuid := (select auth.uid());
  inst            uuid;
  actor_is_owner  boolean;
begin
  if tg_op = 'DELETE' then
    inst := old.institute_id;
    -- institute itself is being deleted: let the cascade through
    if not exists (select 1 from public.institutes i where i.id = inst) then
      return old;
    end if;
  else
    inst := new.institute_id;
  end if;

  -- ---- invariants that hold for every caller ------------------------
  if tg_op = 'UPDATE' and (new.institute_id <> old.institute_id or new.user_id <> old.user_id) then
    raise exception 'a membership cannot be moved to another institute or user'
      using errcode = 'check_violation';
  end if;

  if tg_op <> 'DELETE' and new.role = 'student' and exists (
    select 1 from public.teacher_profiles t
    where t.institute_id = new.institute_id and t.user_id = new.user_id
  ) then
    raise exception 'a teacher cannot be a student in the same institute'
      using errcode = 'check_violation';
  end if;

  if tg_op <> 'INSERT' and old.role = 'owner' and old.status = 'active' then
    if (tg_op = 'DELETE' or new.role <> 'owner' or new.status <> 'active')
       and not exists (
         select 1 from public.memberships m
         where m.institute_id = inst and m.id <> old.id
           and m.role = 'owner' and m.status = 'active')
    then
      raise exception 'an institute must keep at least one active owner'
        using errcode = 'check_violation';
    end if;
  end if;

  -- ---- trusted callers ---------------------------------------------
  if actor is null then
    if tg_op = 'DELETE' then return old; end if;
    return new;
  end if;

  actor_is_owner := exists (
    select 1 from public.memberships m
    where m.institute_id = inst and m.user_id = actor
      and m.role = 'owner' and m.status = 'active'
  );

  if actor_is_owner then
    if tg_op = 'DELETE' then return old; end if;
    return new;
  end if;

  -- ---- everyone who is not an owner of this institute ---------------
  if tg_op = 'INSERT' then
    if new.role = 'owner' then
      -- the single exception: the creator of a brand-new institute
      if new.user_id = actor
         and exists (select 1 from public.institutes i where i.id = inst and i.owner_id = actor)
         and not exists (select 1 from public.memberships m where m.institute_id = inst and m.role = 'owner')
      then
        return new;
      end if;
      raise exception 'only an owner can grant the owner role'
        using errcode = 'insufficient_privilege';
    end if;
    if new.role = 'admin' or cardinality(new.permissions) > 0 then
      raise exception 'only an owner can grant the admin role or permissions'
        using errcode = 'insufficient_privilege';
    end if;
    if new.user_id = actor and new.status <> 'pending' then
      raise exception 'a join request must start as pending'
        using errcode = 'insufficient_privilege';
    end if;
    return new;
  end if;

  if tg_op = 'UPDATE' then
    if new.role is distinct from old.role then
      raise exception 'only an owner can change a role'
        using errcode = 'insufficient_privilege';
    end if;
    if new.permissions is distinct from old.permissions then
      raise exception 'only an owner can change permissions'
        using errcode = 'insufficient_privilege';
    end if;
    if old.role in ('owner', 'admin') then
      raise exception 'only an owner can modify an owner or admin membership'
        using errcode = 'insufficient_privilege';
    end if;
    return new;
  end if;

  -- DELETE
  if old.role in ('owner', 'admin') then
    raise exception 'only an owner can remove an owner or admin'
      using errcode = 'insufficient_privilege';
  end if;
  return old;
end $$;

create trigger membership_guard
  before insert or update or delete on public.memberships
  for each row execute function public.membership_guard();

-- institutes.owner_id decides who may bootstrap an owner membership, so
-- only an existing owner may change it.
create or replace function public.institute_guard()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor uuid := (select auth.uid());
begin
  if actor is not null
     and new.owner_id is distinct from old.owner_id
     and not exists (
       select 1 from public.memberships m
       where m.institute_id = old.id and m.user_id = actor
         and m.role = 'owner' and m.status = 'active')
  then
    raise exception 'only an owner can transfer an institute'
      using errcode = 'insufficient_privilege';
  end if;
  return new;
end $$;

create trigger institute_guard
  before update on public.institutes
  for each row execute function public.institute_guard();

-- ---------------------------------------------------------------------
-- 3. Enable RLS + table grants on every table
-- ---------------------------------------------------------------------
do $$
declare
  r record;
begin
  for r in
    select c.relname
    from pg_class c
    join pg_namespace n on n.oid = c.relnamespace
    where n.nspname = 'public'
      and c.relkind in ('r', 'p')
      and not exists (
        select 1 from pg_depend d
        where d.classid = 'pg_class'::regclass and d.objid = c.oid and d.deptype = 'e')
  loop
    execute format('alter table public.%I enable row level security', r.relname);
    execute format('revoke all on public.%I from public, anon', r.relname);
    execute format('grant select, insert, update, delete on public.%I to authenticated', r.relname);
    execute format('grant all on public.%I to service_role', r.relname);
  end loop;
end $$;

-- ---------------------------------------------------------------------
-- 4. Policies · global tables
-- ---------------------------------------------------------------------

-- users: read-only mirror of auth.users (written by handle_auth_user)
create policy users_select on public.users for select to authenticated
  using (id = (select auth.uid()) or public.is_staff_over(id));

create policy profiles_select on public.profiles for select to authenticated
  using (public.can_view_profile(user_id));
create policy profiles_insert on public.profiles for insert to authenticated
  with check (user_id = (select auth.uid()));
create policy profiles_update on public.profiles for update to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

create policy user_preferences_all on public.user_preferences for all to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

create policy sessions_all on public.sessions for all to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

-- ---------------------------------------------------------------------
-- 5. Policies · institutes and memberships
-- ---------------------------------------------------------------------

create policy institutes_select on public.institutes for select to authenticated
  using (id = any ((select public.auth_institute_ids())::uuid[]) or owner_id = (select auth.uid()));
-- anyone signed in may start an institute; handle_new_institute makes them its owner
create policy institutes_insert on public.institutes for insert to authenticated
  with check (owner_id = (select auth.uid()));
create policy institutes_update on public.institutes for update to authenticated
  using (id = any ((select public.auth_institute_ids())::uuid[]) and public.has_permission(id, 'institute'))
  with check (id = any ((select public.auth_institute_ids())::uuid[]) and public.has_permission(id, 'institute'));
create policy institutes_delete on public.institutes for delete to authenticated
  using (id = any ((select public.auth_institute_ids())::uuid[]) and public.has_role(id, array['owner']));

-- Own row in any status (the pending screen needs it); staff see all rows.
create policy memberships_select on public.memberships for select to authenticated
  using (
    user_id = (select auth.uid())
    or (institute_id = any ((select public.auth_institute_ids())::uuid[])
        and public.has_role(institute_id, array['owner', 'admin']))
  );
-- A join request (always pending, never owner/admin), or staff adding a member.
-- membership_guard decides which roles a non-owner may hand out.
create policy memberships_insert on public.memberships for insert to authenticated
  with check (
    (user_id = (select auth.uid()) and status = 'pending' and role in ('teacher', 'student', 'parent')
       and cardinality(permissions) = 0)
    or (institute_id = any ((select public.auth_institute_ids())::uuid[])
        and public.has_permission(institute_id, 'members'))
  );
create policy memberships_update on public.memberships for update to authenticated
  using (institute_id = any ((select public.auth_institute_ids())::uuid[])
         and public.has_permission(institute_id, 'members'))
  with check (institute_id = any ((select public.auth_institute_ids())::uuid[])
              and public.has_permission(institute_id, 'members'));
-- Staff remove members; a user may withdraw their own pending request.
create policy memberships_delete on public.memberships for delete to authenticated
  using (
    (user_id = (select auth.uid()) and status = 'pending')
    or (institute_id = any ((select public.auth_institute_ids())::uuid[])
        and public.has_permission(institute_id, 'members'))
  );

-- ---------------------------------------------------------------------
-- 6. Policies · every other tenant table
--
-- One row per table: (table, select, insert, update, delete).
--   null  → no policy for that command (denied)
--   '='   → same expression as insert
-- Every expression is wrapped as
--   institute_id = any(auth_institute_ids()) and ( <expression> )
-- Shorthand, expanded below:
--   {UID}      (select auth.uid())
--   {ADM}      has_role(institute_id, ['owner','admin'])
--   {TCH}      has_role(institute_id, ['teacher'])
--   {STU}      has_role(institute_id, ['student'])
--   {P:x}      has_permission(institute_id, 'x')     owner, or admin granted x
--   {MYS:col}  col = any(my_student_ids())           me as student / my children
--   {TB:col}   col = any(my_batch_ids())             batches I teach
--   {SB:col}   col = any(my_student_batch_ids())     batches my students are in
--   {TS:col}   col = any(my_taught_student_ids())    students in batches I teach
--   {MYT:col}  col = any(my_teacher_ids())           my teacher profile
-- ---------------------------------------------------------------------
do $$
declare
  p      record;
  cmds   text[] := array['select', 'insert', 'update', 'delete'];
  exprs  text[];
  e      text;
  i      int;
  member constant text := 'institute_id = any ((select public.auth_institute_ids())::uuid[])';
begin
  for p in
    select * from (values
      -- TENANT ---------------------------------------------------------
      ('invitations',        '{P:members}', '{P:members}', '=', '='),
      ('branches',           'true', '{P:institute}', '=', '='),
      ('institute_settings', 'true', '{P:institute}', '=', '='),

      -- ACADEMICS ------------------------------------------------------
      ('student_profiles',
         '{ADM} or {MYS:id} or {TS:id}',
         '{ADM}', '=', '='),
      ('guardians',
         '{ADM} or exists (select 1 from public.parent_links pl where pl.guardian_id = guardians.id
                           and ({MYS:pl.student_id} or {TS:pl.student_id}))',
         '{ADM}', '=', '='),
      ('student_memberships',
         '{ADM} or {MYS:student_id} or {TS:student_id}',
         '{ADM}', '=', '='),
      ('parent_links',
         '{ADM} or {MYS:student_id} or {TS:student_id}',
         '{ADM}', '=', '='),
      ('student_history',
         '{ADM} or {MYS:student_id} or {TS:student_id}',
         '{ADM}', '=', '='),
      ('teacher_profiles',   'true', '{P:staff}', '=', '='),
      ('staff_records',
         '{P:staff} or user_id = {UID}',
         '{P:staff}', '=', '='),
      ('teacher_assignments',
         '{ADM} or {TCH} or {SB:batch_id}',
         '{P:staff}', '=', '='),
      ('workloads',
         '{P:staff} or {MYT:teacher_id}',
         '{P:staff}', '=', '='),
      ('leave_requests',
         '{P:staff} or user_id = {UID}',
         '{P:staff} or (user_id = {UID} and status = ''pending''
                        and public.has_role(institute_id, array[''admin'', ''teacher'']))',
         '{P:staff} or (user_id = {UID} and status in (''pending'', ''cancelled''))',
         '{P:staff}'),

      -- BATCHES --------------------------------------------------------
      ('classrooms',         'true', '{ADM}', '=', '='),
      ('subjects',           'true', '{ADM}', '=', '='),
      ('batches',
         '{ADM} or {TB:id} or {SB:id}',
         '{ADM}', '=', '='),
      ('batch_students',
         '{ADM} or {TB:batch_id} or {MYS:student_id}',
         '{ADM}', '=', '='),
      ('batch_teachers',
         '{ADM} or {TB:batch_id} or {SB:batch_id}',
         '{P:staff}', '=', '='),
      ('timetables',
         '{ADM} or {TB:batch_id} or {SB:batch_id}',
         '{ADM}', '=', '='),

      -- ATTENDANCE -----------------------------------------------------
      ('attendance_sessions',
         '{ADM} or {TB:batch_id} or {SB:batch_id}',
         '{ADM} or {TB:batch_id}', '=', '='),
      ('attendance_records',
         '{ADM} or {TB:batch_id} or {MYS:student_id}',
         '{ADM} or {TB:batch_id}', '=', '='),
      ('attendance_corrections',
         '{ADM} or {TB:batch_id} or {MYS:student_id}',
         '{ADM} or {TB:batch_id} or ({MYS:student_id} and requested_by = {UID} and status = ''pending'')',
         '{ADM} or {TB:batch_id}',
         '{ADM}'),

      -- HOMEWORK -------------------------------------------------------
      ('assignments',
         '{ADM} or {TB:batch_id} or ({SB:batch_id} and status <> ''draft'')',
         '{ADM} or {TB:batch_id}', '=', '='),
      ('submissions',
         '{ADM} or {TB:batch_id} or {MYS:student_id}',
         '{ADM} or {TB:batch_id} or ({STU} and {MYS:student_id})',
         '=',
         '{ADM} or {TB:batch_id}'),
      ('attachments',
         '{ADM} or uploaded_by = {UID} or {TB:batch_id} or {MYS:student_id}
            or (student_id is null and {SB:batch_id})',
         'uploaded_by = {UID} and ({ADM} or {TB:batch_id} or {MYS:student_id})',
         null,
         '{ADM} or uploaded_by = {UID}'),
      ('feedback',
         '{ADM} or {TB:batch_id} or {MYS:student_id}',
         '{ADM} or {TB:batch_id}', '=', '='),

      -- EXAMS ----------------------------------------------------------
      ('exams',
         '{ADM} or {TB:batch_id} or ({SB:batch_id} and status <> ''draft'')',
         '{ADM} or {TB:batch_id}', '=', '='),
      ('exam_questions',
         '{ADM} or {TB:batch_id} or ({SB:batch_id} and exists (
              select 1 from public.exams e
              where e.id = exam_questions.exam_id and e.status in (''completed'', ''published'')))',
         '{ADM} or {TB:batch_id}', '=', '='),
      ('marks',
         '{ADM} or {TB:batch_id} or {MYS:student_id}',
         '{ADM} or {TB:batch_id}', '=', '='),
      ('results',
         '{ADM} or {TB:batch_id} or {MYS:student_id}',
         '{ADM} or {TB:batch_id}', '=', '='),

      -- LEARNING -------------------------------------------------------
      ('materials',
         '{ADM} or {TCH} or (is_published and (batch_id is null or {SB:batch_id}))',
         '{ADM} or {TB:batch_id}', '=', '='),
      ('material_access',
         '{ADM} or {TS:student_id} or {MYS:student_id}',
         '{ADM} or ({STU} and {MYS:student_id})',
         '=',
         '{ADM}'),
      ('bookmarks',
         'user_id = {UID}', 'user_id = {UID}', '=', '='),
      ('practice_questions',
         '{ADM} or {TCH} or (is_published and (batch_id is null or {SB:batch_id}))',
         '{ADM} or {TB:batch_id} or ({TCH} and batch_id is null and created_by = {UID})', '=', '='),
      ('quizzes',
         '{ADM} or {TB:batch_id} or ({SB:batch_id} and status <> ''draft'')',
         '{ADM} or {TB:batch_id}', '=', '='),
      ('quiz_attempts',
         '{ADM} or {TB:batch_id} or {MYS:student_id}',
         '{ADM} or {TB:batch_id} or ({STU} and {MYS:student_id})',
         '=',
         '{ADM} or {TB:batch_id}'),
      ('study_tasks',
         '{ADM} or {TS:student_id} or {MYS:student_id}',
         '{ADM} or {TS:student_id} or ({STU} and {MYS:student_id})', '=', '='),
      ('student_goals',
         '{ADM} or {TS:student_id} or {MYS:student_id}',
         '{ADM} or {TS:student_id} or ({STU} and {MYS:student_id})', '=', '='),

      -- FINANCE --------------------------------------------------------
      ('fee_structures',
         '{P:fees} or exists (select 1 from public.student_fees sf
                              where sf.fee_structure_id = fee_structures.id and {MYS:sf.student_id})',
         '{P:fees}', '=', '='),
      ('student_fees',  '{P:fees} or {MYS:student_id}', '{P:fees}', '=', '='),
      ('installments',  '{P:fees} or {MYS:student_id}', '{P:fees}', '=', '='),
      ('payments',      '{P:fees} or {MYS:student_id}', '{P:fees}', '=', '='),
      ('receipts',      '{P:fees} or {MYS:student_id}', '{P:fees}', '=', '='),
      ('refunds',       '{P:fees} or {MYS:student_id}', '{P:fees}', '=', '='),

      -- COMMUNICATION --------------------------------------------------
      ('notices',
         '{ADM} or created_by = {UID} or (
              published_at <= now() and (expires_at is null or expires_at > now())
              and public.has_role(institute_id, audience)
              and (batch_id is null or {TB:batch_id} or {SB:batch_id}))',
         '{ADM} or ({TB:batch_id} and created_by = {UID})', '=', '='),
      ('notifications',
         'user_id = {UID}',
         '{ADM}',
         'user_id = {UID}',
         'user_id = {UID} or {ADM}'),
      ('conversations',
         '{UID} = any (participant_ids) and (student_id is null or {ADM} or {TCH} or {MYS:student_id})',
         'created_by = {UID} and {UID} = any (participant_ids)
            and (student_id is null or {ADM} or {TCH} or {MYS:student_id})',
         '{UID} = any (participant_ids) and (student_id is null or {ADM} or {TCH} or {MYS:student_id})',
         null),
      ('doubts',
         '{ADM} or {TB:batch_id} or {MYS:student_id}',
         '{ADM} or {TB:batch_id} or ({STU} and {MYS:student_id} and asked_by = {UID})',
         '{ADM} or {TB:batch_id}',
         '{ADM} or {TB:batch_id} or (asked_by = {UID} and status = ''open'')'),
      ('teacher_feedback',
         '{ADM} or {TB:batch_id} or (is_shared and {MYS:student_id})',
         '{ADM} or {TB:batch_id}', '=', '='),
      ('meeting_requests',
         '{ADM} or {MYT:teacher_id} or {MYS:student_id}',
         '{ADM} or {MYT:teacher_id} or ({MYS:student_id} and requested_by = {UID} and status = ''pending'')',
         '{ADM} or {MYT:teacher_id}
            or ({MYS:student_id} and requested_by = {UID} and status in (''pending'', ''cancelled''))',
         '{ADM}'),

      -- BUSINESS -------------------------------------------------------
      ('admission_leads', '{P:leads}', '{P:leads}', '=', '='),
      ('lead_followups',  '{P:leads}', '{P:leads}', '=', '='),
      -- billing is written by the service role only
      ('plans',           '{P:billing}', null, null, null),
      ('subscriptions',   '{P:billing}', null, null, null),
      ('usage_records',   '{P:billing}', null, null, null),
      -- append-only
      ('audit_logs',      '{P:audit}', 'actor_id = {UID}', null, null)
    ) as t (tbl, sel, ins, upd, del)
  loop
    exprs := array[p.sel, p.ins, p.upd, p.del];
    for i in 1 .. 4 loop
      e := exprs[i];
      if e = '=' then
        e := p.ins;
      end if;
      continue when e is null;

      e := replace(e, '{UID}', '(select auth.uid())');
      e := replace(e, '{ADM}', 'public.has_role(institute_id, array[''owner'', ''admin''])');
      e := replace(e, '{TCH}', 'public.has_role(institute_id, array[''teacher''])');
      e := replace(e, '{STU}', 'public.has_role(institute_id, array[''student''])');
      e := regexp_replace(e, '\{P:(\w+)\}',      'public.has_permission(institute_id, ''\1'')', 'g');
      e := regexp_replace(e, '\{MYS:([\w.]+)\}', '\1 = any ((select public.my_student_ids())::uuid[])', 'g');
      e := regexp_replace(e, '\{TB:([\w.]+)\}',  '\1 = any ((select public.my_batch_ids())::uuid[])', 'g');
      e := regexp_replace(e, '\{SB:([\w.]+)\}',  '\1 = any ((select public.my_student_batch_ids())::uuid[])', 'g');
      e := regexp_replace(e, '\{TS:([\w.]+)\}',  '\1 = any ((select public.my_taught_student_ids())::uuid[])', 'g');
      e := regexp_replace(e, '\{MYT:([\w.]+)\}', '\1 = any ((select public.my_teacher_ids())::uuid[])', 'g');
      if e ~ '[{}]' then
        raise exception 'unexpanded shorthand in % % policy: %', p.tbl, cmds[i], e;
      end if;
      e := format('%s and (%s)', member, e);

      execute case cmds[i]
        when 'select' then format('create policy %I on public.%I for select to authenticated using (%s)',
                                  p.tbl || '_select', p.tbl, e)
        when 'insert' then format('create policy %I on public.%I for insert to authenticated with check (%s)',
                                  p.tbl || '_insert', p.tbl, e)
        when 'update' then format('create policy %I on public.%I for update to authenticated using (%s) with check (%s)',
                                  p.tbl || '_update', p.tbl, e, e)
        when 'delete' then format('create policy %I on public.%I for delete to authenticated using (%s)',
                                  p.tbl || '_delete', p.tbl, e)
      end;
    end loop;
  end loop;
end $$;

-- ---------------------------------------------------------------------
-- 7. Function privileges
--    Helpers are callable by signed-in users (policies run as the
--    caller). Trigger functions are not callable through the API.
-- ---------------------------------------------------------------------
revoke all on function
  public.auth_institute_ids(),
  public.has_role(uuid, text[]),
  public.has_permission(uuid, text),
  public.my_student_ids(),
  public.my_teacher_ids(),
  public.my_batch_ids(),
  public.my_student_batch_ids(),
  public.my_taught_student_ids(),
  public.is_staff_over(uuid),
  public.can_view_profile(uuid)
from public, anon;

grant execute on function
  public.auth_institute_ids(),
  public.has_role(uuid, text[]),
  public.has_permission(uuid, text),
  public.my_student_ids(),
  public.my_teacher_ids(),
  public.my_batch_ids(),
  public.my_student_batch_ids(),
  public.my_taught_student_ids(),
  public.is_staff_over(uuid),
  public.can_view_profile(uuid)
to authenticated, service_role;

revoke all on function
  public.set_updated_at(),
  public.handle_auth_user(),
  public.handle_new_institute(),
  public.teacher_not_student(),
  public.membership_guard(),
  public.institute_guard()
from public, anon, authenticated;
