-- Batch cards are a single scoped read, never a per-student client fetch.
begin;
alter table public.batches
  add column subject_id uuid,
  add column teacher_id uuid,
  add column days integer[] not null default '{}',
  add column starts_at time,
  add column ends_at time,
  add column fee_plan text not null default 'monthly' check (fee_plan in ('monthly','quarterly','term')),
  add column fee_amount numeric(12,2) not null default 0 check (fee_amount >= 0),
  add constraint batch_subject_fk foreign key (institute_id, subject_id) references public.subjects(institute_id,id),
  add constraint batch_teacher_fk foreign key (institute_id, teacher_id) references public.teacher_profiles(institute_id,id),
  add constraint batch_time_check check ((starts_at is null and ends_at is null) or (starts_at is not null and ends_at is not null and ends_at > starts_at)),
  add constraint batch_days_check check (days <@ array[0,1,2,3,4,5,6] and (starts_at is null or cardinality(days) > 0));

-- Bring existing batches forward using their first scheduled period.
update public.batches b set subject_id = p.subject_id, teacher_id = p.teacher_id,
  starts_at = p.starts_at, ends_at = p.ends_at, days = p.days
from (select distinct on (institute_id,batch_id) institute_id,batch_id,subject_id,teacher_id,starts_at,ends_at,
  array(select distinct t.day_of_week::integer from public.timetables t where t.institute_id = tt.institute_id and t.batch_id = tt.batch_id order by 1) as days
  from public.timetables tt order by institute_id,batch_id,day_of_week,starts_at) p
where b.institute_id = p.institute_id and b.id = p.batch_id;

create view public.batch_roster with (security_invoker = true) as
select e.institute_id,e.batch_id,e.student_id,e.roll_number,s.full_name,s.photo_url,
  coalesce(a.total,0) as attendance_total,
  coalesce(round(100.0 * a.present / nullif(a.total,0),1),0) as attendance_pct
from public.batch_students e
join public.students s on s.institute_id=e.institute_id and s.id=e.student_id
left join (select institute_id,batch_id,student_id,count(*) as total,
  count(*) filter (where status in ('present','late')) as present
  from public.attendance_records group by institute_id,batch_id,student_id) a
on a.institute_id=e.institute_id and a.batch_id=e.batch_id and a.student_id=e.student_id
where e.status='active';

create view public.batch_summaries with (security_invoker = true) as
select b.*,s.name as subject_name,t.full_name as teacher_name,t.photo_url as teacher_photo,
  coalesce(e.student_count,0) as student_count,
  coalesce(a.total,0) as attendance_total,
  coalesce(round(100.0 * a.present / nullif(a.total,0),1),0) as attendance_pct,
  coalesce(e.pending_fees,0) as pending_fees
from public.batches b
left join public.subjects s on s.institute_id=b.institute_id and s.id=b.subject_id
left join public.teacher_profiles t on t.institute_id=b.institute_id and t.id=b.teacher_id
left join (select bs.institute_id,bs.batch_id,count(*) as student_count,
  count(*) filter (where exists (select 1 from public.installments i
    where i.institute_id=bs.institute_id and i.student_id=bs.student_id
      and i.status <> 'waived' and i.paid_amount < i.amount and i.due_date <= current_date)) as pending_fees
  from public.batch_students bs where bs.status='active' group by bs.institute_id,bs.batch_id) e
on e.institute_id=b.institute_id and e.batch_id=b.id
left join (select institute_id,batch_id,count(*) as total,
  count(*) filter (where status in ('present','late')) as present
  from public.attendance_records group by institute_id,batch_id) a
on a.institute_id=b.institute_id and a.batch_id=b.id;

grant select on public.batch_summaries, public.batch_roster to authenticated;

-- Same transaction as the batch insert, so a partial timetable cannot escape.
create function public.schedule_new_batch() returns trigger language plpgsql set search_path = public as $$
begin
  if new.starts_at is not null then
    insert into public.timetables(institute_id,batch_id,subject_id,teacher_id,day_of_week,starts_at,ends_at)
    select new.institute_id,new.id,new.subject_id,new.teacher_id,d,new.starts_at,new.ends_at
    from (select distinct unnest(new.days) as d) days;
  end if;
  return new;
end $$;
create trigger batch_schedule after insert on public.batches for each row execute function public.schedule_new_batch();

-- Defence in depth: even older clients cannot destroy a batch's history.
create function public.archive_batch_on_delete() returns trigger language plpgsql set search_path = public as $$
begin
  update public.batches set status='archived',updated_at=now() where institute_id=old.institute_id and id=old.id;
  return null;
end $$;
create trigger batch_archive before delete on public.batches for each row execute function public.archive_batch_on_delete();
commit;
