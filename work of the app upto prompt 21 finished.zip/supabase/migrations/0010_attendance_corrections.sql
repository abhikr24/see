-- =====================================================================
-- 0010_attendance_corrections.sql
--   Audited attendance corrections for the monthly register.
--
--   · attendance_corrections is append-only for people: its facts (record,
--     old status, new status, who, why) can no longer be edited or deleted
--     by a statement. Cascades from a parent delete are still allowed.
--   · correct_attendance() is the one write path: it checks the caller's
--     role, applies the 7-day owner rule, changes the records, writes one
--     corrections row and one audit_logs row per record, all-or-nothing.
--
-- Apply after 0004 (tables) and 0008 (helper functions).
-- =====================================================================
begin;

-- A direct correction always carries a reason; student/parent requests may
-- still arrive without one, so the check only guards approved rows.
alter table public.attendance_corrections
  add constraint attendance_corrections_reason_chk
  check (status <> 'approved' or char_length(btrim(coalesce(reason, ''))) >= 3);

create function public.guard_attendance_corrections() returns trigger
language plpgsql set search_path = ''
as $$
begin
  if tg_op = 'DELETE' then
    -- pg_trigger_depth() = 1 is a direct statement; deeper is an FK cascade.
    if pg_trigger_depth() = 1 then
      raise exception 'Attendance corrections are an audit trail and cannot be deleted'
        using errcode = '42501';
    end if;
    return old;
  end if;
  if new.record_id is distinct from old.record_id
     or new.student_id is distinct from old.student_id
     or new.batch_id is distinct from old.batch_id
     or new.requested_by is distinct from old.requested_by
     or new.current_status is distinct from old.current_status
     or new.requested_status is distinct from old.requested_status
     or (old.status = 'approved' and new.reason is distinct from old.reason) then
    raise exception 'Attendance corrections cannot be rewritten' using errcode = '42501';
  end if;
  return new;
end $$;

create trigger trg_attendance_corrections_guard
  before update or delete on public.attendance_corrections
  for each row execute function public.guard_attendance_corrections();

create function public.correct_attendance(
  p_institute_id uuid,
  p_batch_id     uuid,
  p_date         date,
  p_changes      jsonb,
  p_reason       text
) returns setof public.attendance_corrections
language plpgsql security definer set search_path = ''
as $$
declare
  v_uid     uuid := (select auth.uid());
  v_role    text;
  v_reason  text := btrim(regexp_replace(coalesce(p_reason, ''), '\s+', ' ', 'g'));
  v_item    jsonb;
  v_status  text;
  v_record  public.attendance_records;
  v_session public.attendance_sessions;
  v_row     public.attendance_corrections;
  v_changed integer := 0;
begin
  select m.role into v_role
  from public.memberships m
  where m.institute_id = p_institute_id and m.user_id = v_uid and m.status = 'active'
  limit 1;

  if v_role is null or v_role not in ('owner', 'admin', 'teacher') then
    raise exception 'You do not have permission to correct attendance' using errcode = '42501';
  end if;
  if v_role = 'teacher' and not (p_batch_id = any (public.my_batch_ids())) then
    raise exception 'You do not teach this batch' using errcode = '42501';
  end if;
  if p_date > current_date then
    raise exception 'Attendance for a future date cannot be corrected' using errcode = '23514';
  end if;
  if current_date - p_date > 7 and v_role <> 'owner' then
    raise exception 'Corrections older than 7 days need the owner' using errcode = '42501';
  end if;
  if char_length(v_reason) < 3 or char_length(v_reason) > 300 then
    raise exception 'A note of 3 to 300 characters is required' using errcode = '23514';
  end if;

  for v_item in select * from jsonb_array_elements(p_changes) loop
    v_status := v_item ->> 'status';
    if v_status is null or v_status not in ('present', 'absent', 'late', 'leave') then
      raise exception 'Unknown attendance status' using errcode = '23514';
    end if;

    select * into v_record from public.attendance_records r
    where r.institute_id = p_institute_id and r.batch_id = p_batch_id
      and r.id = (v_item ->> 'recordId')::uuid
    for update;
    if not found then
      raise exception 'Attendance record not found' using errcode = 'P0002';
    end if;

    select * into v_session from public.attendance_sessions s where s.id = v_record.session_id;
    if v_session.session_date <> p_date then
      raise exception 'That record is not on this day' using errcode = '23514';
    end if;
    if v_session.status = 'locked' and v_role <> 'owner' then
      raise exception 'This roll call is locked. Ask the owner.' using errcode = '42501';
    end if;
    if v_record.status = v_status then
      continue;
    end if;

    insert into public.attendance_corrections (
      institute_id, record_id, batch_id, student_id, requested_by,
      current_status, requested_status, reason, status, reviewed_by, reviewed_at
    ) values (
      p_institute_id, v_record.id, p_batch_id, v_record.student_id, v_uid,
      v_record.status, v_status, v_reason, 'approved', v_uid, now()
    ) returning * into v_row;

    update public.attendance_records set status = v_status, updated_at = now() where id = v_record.id;

    insert into public.audit_logs (institute_id, actor_id, actor_role, action, entity_type, entity_id, old_data, new_data)
    values (
      p_institute_id, v_uid, v_role, 'attendance.corrected', 'attendance_record', v_record.id,
      jsonb_build_object('status', v_record.status),
      jsonb_build_object('status', v_status, 'reason', v_reason, 'correctionId', v_row.id,
                         'studentId', v_record.student_id, 'batchId', p_batch_id, 'date', p_date)
    );

    v_changed := v_changed + 1;
    return next v_row;
  end loop;

  if v_changed = 0 then
    raise exception 'Nothing was changed' using errcode = '23514';
  end if;
end $$;

revoke all on function public.correct_attendance(uuid, uuid, date, jsonb, text) from public, anon;
grant execute on function public.correct_attendance(uuid, uuid, date, jsonb, text) to authenticated;

commit;
