-- =====================================================================
-- 0011_exams.sql · Exam subject link, hidden marks until publish,
--                  and atomic publish + batch notification RPC
-- =====================================================================

alter table public.exams
  add column if not exists subject_id uuid;

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'exams_subject_fk'
  ) then
    alter table public.exams
      add constraint exams_subject_fk
      foreign key (institute_id, subject_id)
      references public.subjects (institute_id, id) on delete set null;
  end if;
end $$;

-- Marks and results stay hidden from students/parents until the exam is published.
drop policy if exists marks_select on public.marks;
create policy marks_select on public.marks for select to authenticated
using (
  public.is_admin(institute_id)
  or public.teaches_batch(institute_id, batch_id)
  or (
    public.is_my_student(institute_id, student_id)
    and exists (
      select 1 from public.exams e
      where e.id = marks.exam_id and e.status = 'published'
    )
  )
);

drop policy if exists results_select on public.results;
create policy results_select on public.results for select to authenticated
using (
  public.is_admin(institute_id)
  or public.teaches_batch(institute_id, batch_id)
  or (
    public.is_my_student(institute_id, student_id)
    and exists (
      select 1 from public.exams e
      where e.id = results.exam_id and e.status = 'published'
    )
  )
);

create or replace function public.publish_exam_results(
  p_institute_id uuid,
  p_exam_id uuid
) returns public.exams
language plpgsql
security definer
set search_path = public
as $$
declare
  v_exam public.exams;
  v_batch_name text;
  v_uid uuid;
begin
  select * into v_exam from public.exams
  where id = p_exam_id and institute_id = p_institute_id;

  if not found then
    raise exception 'Exam not found' using errcode = 'P0002';
  end if;

  if not (public.is_admin(p_institute_id) or public.teaches_batch(p_institute_id, v_exam.batch_id)) then
    raise exception 'Permission denied' using errcode = '42501';
  end if;

  update public.exams
  set status = 'published',
      published_at = coalesce(published_at, now())
  where id = p_exam_id and institute_id = p_institute_id
  returning * into v_exam;

  select name into v_batch_name from public.batches
  where id = v_exam.batch_id and institute_id = p_institute_id;

  for v_uid in (
    select distinct m.user_id
    from public.batch_students bs
    join public.student_memberships sm
      on sm.institute_id = bs.institute_id and sm.student_id = bs.student_id
    join public.memberships m
      on m.id = sm.membership_id and m.institute_id = bs.institute_id and m.status = 'active'
    where bs.institute_id = p_institute_id and bs.batch_id = v_exam.batch_id and bs.status = 'active'
    union
    select distinct m.user_id
    from public.batch_students bs
    join public.parent_links pl
      on pl.institute_id = bs.institute_id and pl.student_id = bs.student_id
    join public.guardians g
      on g.institute_id = bs.institute_id and g.id = pl.guardian_id
    join public.memberships m
      on m.id = g.membership_id and m.institute_id = bs.institute_id and m.status = 'active'
    where bs.institute_id = p_institute_id and bs.batch_id = v_exam.batch_id and bs.status = 'active'
  ) loop
    if not exists (
      select 1 from public.notifications n
      where n.institute_id = p_institute_id
        and n.user_id = v_uid
        and n.type = 'exam_published'
        and n.data->>'examId' = p_exam_id::text
    ) then
      insert into public.notifications (institute_id, user_id, type, title, body, data, channel, sent_at)
      values (
        p_institute_id,
        v_uid,
        'exam_published',
        v_exam.name || ' results published',
        'Results for ' || v_exam.name || ' (' || coalesce(v_batch_name, 'Batch') || ') are now available.',
        jsonb_build_object('screen', 'results', 'examId', p_exam_id, 'batchId', v_exam.batch_id),
        'in_app',
        now()
      );
    end if;
  end loop;

  return v_exam;
end;
$$;
