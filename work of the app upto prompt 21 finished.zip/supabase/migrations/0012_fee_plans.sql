-- =====================================================================
-- 0012_fee_plans.sql
--   Batch fee plans: instalment schedule, discount / scholarship rows,
--   versions, and the guards that keep receipts true.
--
--   · fee_structures gains version / superseded_by / batch_ids / schedule /
--     discounts. A plan with money on it is never edited: save_fee_plan()
--     inserts version n+1 and links the old row to it with superseded_by.
--   · student_fees.discount_ids is the individual override (scholarship).
--     It lowers one student's net; fee_structures.total_amount never moves.
--   · Three triggers refuse any statement that would rewrite a fee that
--     already has a payment, so the guarantee does not depend on the client.
--   · save_fee_plan() and apply_student_discounts() are the write paths,
--     all-or-nothing.
--
-- Apply after 0005 (finance) and 0008 (helper functions).
-- =====================================================================
begin;

alter table public.fee_structures
  add column version       integer not null default 1 check (version > 0),
  add column superseded_by uuid references public.fee_structures (id) on delete set null,
  add column batch_ids     uuid[] not null default '{}',
  add column schedule      jsonb not null default '[]',
  add column discounts     jsonb not null default '[]';

alter table public.student_fees
  add column discount_ids text[] not null default '{}';

-- ---------------------------------------------------------------------
-- Helpers
-- ---------------------------------------------------------------------
-- Splits a total over weights to the paisa; the last share absorbs rounding.
create function public.fee_allocate(p_total numeric, p_weights numeric[]) returns numeric[]
language plpgsql immutable set search_path = ''
as $$
declare
  v_n     integer := coalesce(array_length(p_weights, 1), 0);
  v_total bigint  := greatest(0, round(p_total * 100))::bigint;
  v_sum   numeric := 0;
  v_used  bigint  := 0;
  v_part  bigint;
  v_out   numeric[] := '{}';
  i       integer;
begin
  if v_n = 0 then return v_out; end if;
  select coalesce(sum(w), 0) into v_sum from unnest(p_weights) as w;
  for i in 1..v_n loop
    if i = v_n then v_part := v_total - v_used;
    elsif v_sum > 0 then v_part := floor(v_total * p_weights[i] / v_sum)::bigint;
    else v_part := floor(v_total::numeric / v_n)::bigint;
    end if;
    v_used := v_used + v_part;
    v_out := v_out || (v_part / 100.0);
  end loop;
  return v_out;
end $$;

-- True once a student fee has a payment or a paid instalment.
create function public.fee_has_money(p_student_fee uuid) returns boolean
language sql stable set search_path = ''
as $$
  select exists (select 1 from public.payments p where p.student_fee_id = p_student_fee and p.status <> 'failed')
      or exists (select 1 from public.installments i where i.student_fee_id = p_student_fee and i.paid_amount > 0);
$$;

-- What a set of discount rows takes off a gross fee (never more than the fee).
create function public.fee_discount_for(p_discounts jsonb, p_ids text[], p_gross numeric) returns numeric
language sql immutable set search_path = ''
as $$
  select least(p_gross, coalesce(sum(
    case d ->> 'type'
      when 'percent' then round(p_gross * (d ->> 'amount')::numeric / 100, 2)
      else round((d ->> 'amount')::numeric, 2)
    end), 0))
  from jsonb_array_elements(p_discounts) as d
  where (d ->> 'id') = any (p_ids);
$$;

create function public.fee_discount_reason(p_discounts jsonb, p_ids text[]) returns text
language sql immutable set search_path = ''
as $$
  select nullif(string_agg(
    case when btrim(coalesce(d ->> 'note', '')) = '' then d ->> 'label'
         else (d ->> 'label') || ' (' || btrim(d ->> 'note') || ')' end, '; '), '')
  from jsonb_array_elements(p_discounts) as d
  where (d ->> 'id') = any (p_ids);
$$;

-- ---------------------------------------------------------------------
-- Guards: money on a fee freezes it
-- ---------------------------------------------------------------------
create function public.guard_paid_installments() returns trigger
language plpgsql set search_path = ''
as $$
begin
  if old.paid_amount > 0 or exists (select 1 from public.payments p where p.installment_id = old.id) then
    if tg_op = 'DELETE' then
      -- pg_trigger_depth() = 1 is a direct statement; deeper is an FK cascade.
      if pg_trigger_depth() = 1 then
        raise exception 'An instalment with a payment cannot be deleted' using errcode = '42501';
      end if;
      return old;
    end if;
    if new.amount is distinct from old.amount or new.due_date is distinct from old.due_date
       or new.term_no is distinct from old.term_no or new.student_fee_id is distinct from old.student_fee_id then
      raise exception 'An instalment with a payment cannot be changed' using errcode = '42501';
    end if;
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end $$;

create trigger trg_installments_guard
  before update or delete on public.installments
  for each row execute function public.guard_paid_installments();

create function public.guard_paid_student_fees() returns trigger
language plpgsql set search_path = ''
as $$
begin
  if public.fee_has_money(old.id)
     and (new.fee_structure_id is distinct from old.fee_structure_id
          or new.gross_amount is distinct from old.gross_amount
          or new.student_id is distinct from old.student_id) then
    raise exception 'A fee with a payment cannot be moved to another plan' using errcode = '42501';
  end if;
  return new;
end $$;

create trigger trg_student_fees_guard
  before update on public.student_fees
  for each row execute function public.guard_paid_student_fees();

create function public.guard_paid_fee_structures() returns trigger
language plpgsql set search_path = ''
as $$
begin
  if (new.total_amount is distinct from old.total_amount
      or new.schedule is distinct from old.schedule
      or new.installment_count is distinct from old.installment_count)
     and exists (
       select 1 from public.student_fees f
       where f.fee_structure_id = old.id and f.status <> 'cancelled' and public.fee_has_money(f.id)) then
    raise exception 'This plan has payments. Save a new version instead of editing it.' using errcode = '42501';
  end if;
  return new;
end $$;

create trigger trg_fee_structures_guard
  before update on public.fee_structures
  for each row execute function public.guard_paid_fee_structures();

-- ---------------------------------------------------------------------
-- save_fee_plan(institute, input) -> { structureId, version, versioned, previousId,
--                                      studentsUpdated, studentsKept }
-- ---------------------------------------------------------------------
create function public.save_fee_plan(p_institute_id uuid, p_input jsonb) returns jsonb
language plpgsql security definer set search_path = ''
as $$
declare
  v_uid       uuid := (select auth.uid());
  v_batch     uuid := (p_input ->> 'batchId')::uuid;
  v_batches   uuid[] := array(select jsonb_array_elements_text(p_input -> 'batchIds')::uuid);
  v_total     numeric := round((p_input ->> 'totalAmount')::numeric, 2);
  v_schedule  jsonb := p_input -> 'schedule';
  v_discounts jsonb := coalesce(p_input -> 'discounts', '[]');
  v_sum       numeric;
  v_existing  public.fee_structures;
  v_new       public.fee_structures;
  v_year      text;
  v_name      text;
  v_money     boolean := false;
  v_student   uuid;
  v_fee       public.student_fees;
  v_own       public.student_fees;
  v_carry     text[];
  v_applied   numeric;
  v_amounts   numeric[];
  v_updated   integer := 0;
  v_kept      integer := 0;
  v_other     public.fee_structures;
  i           integer;
begin
  if not public.has_permission(p_institute_id, 'fees') then
    raise exception 'Only the owner can change fee plans' using errcode = '42501';
  end if;
  if not (v_batch = any (v_batches)) then
    raise exception 'The plan must apply to the batch it was opened for' using errcode = '23514';
  end if;
  if jsonb_array_length(v_schedule) < 1 then
    raise exception 'Add at least one instalment' using errcode = '23514';
  end if;
  select coalesce(sum((x ->> 'amount')::numeric), 0) into v_sum from jsonb_array_elements(v_schedule) as x;
  if v_total <= 0 or round(v_sum * 100) <> round(v_total * 100) then
    raise exception 'The instalments must add up to the plan total' using errcode = '23514';
  end if;

  if p_input ->> 'id' is not null then
    select * into v_existing from public.fee_structures
    where institute_id = p_institute_id and id = (p_input ->> 'id')::uuid for update;
  else
    select * into v_existing from public.fee_structures
    where institute_id = p_institute_id and is_active
      and (batch_id = v_batch or v_batch = any (batch_ids))
    order by version desc limit 1 for update;
  end if;
  if found and not v_existing.is_active then
    raise exception 'This plan was replaced by a newer version. Reopen it to edit the latest one.' using errcode = '40001';
  end if;

  for v_other in
    select * from public.fee_structures s
    where s.institute_id = p_institute_id and s.is_active and s.id is distinct from v_existing.id
      and (s.batch_id = any (v_batches) or s.batch_ids && v_batches)
  loop
    raise exception 'A chosen batch already uses "%". Open that plan instead.', v_other.name using errcode = '23505';
  end loop;

  if v_existing.id is not null then
    select exists (
      select 1 from public.student_fees f
      where f.fee_structure_id = v_existing.id and f.status <> 'cancelled' and public.fee_has_money(f.id)
    ) into v_money;
  end if;

  select coalesce(academic_year, '2026-27') into v_year from public.institute_settings where institute_id = p_institute_id;
  v_year := coalesce(v_existing.academic_year, v_year, '2026-27');
  v_name := coalesce(nullif(btrim(p_input ->> 'name'), ''), v_existing.name,
                     (select b.name from public.batches b where b.id = v_batch) || ' fees');

  if v_existing.id is not null and not v_money then
    update public.fee_structures set
      batch_id = v_batch, name = v_name, total_amount = v_total, installment_count = jsonb_array_length(v_schedule),
      frequency = p_input ->> 'frequency', batch_ids = v_batches, schedule = v_schedule, discounts = v_discounts,
      is_active = true, updated_at = now()
    where id = v_existing.id returning * into v_new;
  else
    insert into public.fee_structures (institute_id, batch_id, name, academic_year, total_amount, installment_count,
      frequency, batch_ids, schedule, discounts, version)
    values (p_institute_id, v_batch, v_name, v_year, v_total, jsonb_array_length(v_schedule),
      p_input ->> 'frequency', v_batches, v_schedule, v_discounts, coalesce(v_existing.version, 0) + 1)
    returning * into v_new;
    if v_existing.id is not null then
      update public.fee_structures set is_active = false, superseded_by = v_new.id, updated_at = now()
      where id = v_existing.id;
    end if;
  end if;

  for v_student in
    select distinct bs.student_id from public.batch_students bs
    where bs.institute_id = p_institute_id and bs.status = 'active' and bs.batch_id = any (v_batches)
  loop
    if exists (
      select 1 from public.student_fees f
      where f.institute_id = p_institute_id and f.student_id = v_student and f.academic_year = v_new.academic_year
        and f.status <> 'cancelled' and public.fee_has_money(f.id)
    ) then
      v_kept := v_kept + 1;
      continue;
    end if;

    v_carry := '{}';
    v_fee := null;
    for v_own in
      select * from public.student_fees f
      where f.institute_id = p_institute_id and f.student_id = v_student
        and f.academic_year = v_new.academic_year and f.status <> 'cancelled'
      order by f.created_at desc
    loop
      if v_carry = '{}' then v_carry := v_own.discount_ids; end if;
      delete from public.installments where student_fee_id = v_own.id;
      if v_own.fee_structure_id = v_new.id then v_fee := v_own;
      else update public.student_fees set status = 'cancelled', updated_at = now() where id = v_own.id;
      end if;
    end loop;

    v_carry := array(select x from unnest(v_carry) as x where exists (
      select 1 from jsonb_array_elements(v_discounts) d where d ->> 'id' = x));
    v_applied := public.fee_discount_for(v_discounts, v_carry, v_total);
    if v_fee.id is null then
      insert into public.student_fees (institute_id, student_id, fee_structure_id, academic_year, gross_amount,
        discount_amount, discount_reason, discount_ids, status)
      values (p_institute_id, v_student, v_new.id, v_new.academic_year, v_total, v_applied,
        public.fee_discount_reason(v_discounts, v_carry), v_carry, 'active')
      returning * into v_fee;
    else
      update public.student_fees set gross_amount = v_total, discount_amount = v_applied,
        discount_reason = public.fee_discount_reason(v_discounts, v_carry), discount_ids = v_carry,
        status = 'active', updated_at = now()
      where id = v_fee.id returning * into v_fee;
    end if;

    v_amounts := public.fee_allocate(v_total - v_applied,
      array(select (x ->> 'amount')::numeric from jsonb_array_elements(v_schedule) as x));
    for i in 1..jsonb_array_length(v_schedule) loop
      insert into public.installments (institute_id, student_fee_id, student_id, term_no, label, amount, due_date)
      values (p_institute_id, v_fee.id, v_student, i, v_schedule -> (i - 1) ->> 'label', v_amounts[i],
        (v_schedule -> (i - 1) ->> 'dueDate')::date);
    end loop;
    v_updated := v_updated + 1;
  end loop;

  insert into public.audit_logs (institute_id, actor_id, actor_role, action, entity_type, entity_id, old_data, new_data)
  values (p_institute_id, v_uid,
    (select m.role from public.memberships m where m.institute_id = p_institute_id and m.user_id = v_uid and m.status = 'active' limit 1),
    'fee_plan.saved', 'fee_structure', v_new.id,
    case when v_existing.id is null then null
         else jsonb_build_object('version', v_existing.version, 'totalAmount', v_existing.total_amount) end,
    jsonb_build_object('version', v_new.version, 'totalAmount', v_new.total_amount, 'versioned', v_money));

  return jsonb_build_object('structureId', v_new.id, 'version', v_new.version, 'versioned', v_money,
    'previousId', case when v_money then v_existing.id else null end,
    'studentsUpdated', v_updated, 'studentsKept', v_kept);
end $$;

-- ---------------------------------------------------------------------
-- apply_student_discounts(institute, student, ids): one student's scholarship.
-- Lowers that student's unpaid instalments only. The plan is not touched.
-- ---------------------------------------------------------------------
create function public.apply_student_discounts(p_institute_id uuid, p_student_id uuid, p_ids text[])
returns public.student_fees
language plpgsql security definer set search_path = ''
as $$
declare
  v_fee      public.student_fees;
  v_plan     public.fee_structures;
  v_applied  numeric;
  v_net      numeric;
  v_locked   numeric;
  v_free     uuid[];
  v_amounts  numeric[];
  i          integer;
begin
  if not public.has_permission(p_institute_id, 'fees') then
    raise exception 'Only the owner can change fee plans' using errcode = '42501';
  end if;
  select * into v_fee from public.student_fees f
  where f.institute_id = p_institute_id and f.student_id = p_student_id and f.status <> 'cancelled'
  order by f.created_at desc limit 1 for update;
  if not found then
    raise exception 'This student has no fee yet. Save the plan first.' using errcode = 'P0002';
  end if;
  select * into v_plan from public.fee_structures where id = v_fee.fee_structure_id;
  while v_plan.superseded_by is not null loop
    select * into v_plan from public.fee_structures where id = v_plan.superseded_by;
  end loop;
  if exists (select 1 from unnest(p_ids) as x where not exists (
      select 1 from jsonb_array_elements(v_plan.discounts) d where d ->> 'id' = x)) then
    raise exception 'That discount is not part of the saved plan' using errcode = '23514';
  end if;

  v_applied := public.fee_discount_for(v_plan.discounts, p_ids, v_fee.gross_amount);
  v_net := v_fee.gross_amount - v_applied;
  select coalesce(sum(amount), 0) into v_locked from public.installments where student_fee_id = v_fee.id and paid_amount > 0;
  v_free := array(select id from public.installments where student_fee_id = v_fee.id and paid_amount <= 0 order by term_no);
  if v_net - v_locked < 0 then
    raise exception 'That is more than what is still unpaid on this student' using errcode = '23514';
  end if;
  if coalesce(array_length(v_free, 1), 0) = 0 and v_net - v_locked <> 0 then
    raise exception 'Every instalment already has a payment on it, so there is nothing to reduce' using errcode = '23514';
  end if;
  v_amounts := public.fee_allocate(v_net - v_locked,
    array(select amount from public.installments where student_fee_id = v_fee.id and paid_amount <= 0 order by term_no));
  for i in 1..coalesce(array_length(v_free, 1), 0) loop
    update public.installments set amount = v_amounts[i], updated_at = now() where id = v_free[i];
  end loop;

  update public.student_fees set discount_amount = v_applied, discount_ids = p_ids,
    discount_reason = public.fee_discount_reason(v_plan.discounts, p_ids), updated_at = now()
  where id = v_fee.id returning * into v_fee;

  insert into public.audit_logs (institute_id, actor_id, action, entity_type, entity_id, new_data)
  values (p_institute_id, (select auth.uid()), 'student_fee.discount_set', 'student_fee', v_fee.id,
    jsonb_build_object('studentId', p_student_id, 'discountAmount', v_applied, 'netAmount', v_fee.net_amount));
  return v_fee;
end $$;

revoke all on function public.save_fee_plan(uuid, jsonb) from public, anon;
revoke all on function public.apply_student_discounts(uuid, uuid, text[]) from public, anon;
grant execute on function public.save_fee_plan(uuid, jsonb) to authenticated;
grant execute on function public.apply_student_discounts(uuid, uuid, text[]) to authenticated;

commit;
