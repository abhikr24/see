-- Desk collection is atomic, institute-scoped, and receipt numbering is serialized per institute.
create or replace function public.record_fee_payment(p_institute uuid, p_student uuid, p_fee uuid, p_installment uuid, p_amount numeric, p_method text, p_reference text, p_paid_at timestamptz)
returns public.payments language plpgsql security definer set search_path = '' as $$
declare v_inst public.installments; v_payment public.payments; v_prefix text; v_year text; v_serial integer;
begin
  if not exists (select 1 from public.memberships where institute_id = p_institute and user_id = auth.uid() and status = 'active' and (role = 'owner' or 'fees' = any(permissions))) then
    raise exception 'Not allowed to collect fees' using errcode = '42501';
  end if;
  if p_amount <= 0 or p_amount <> round(p_amount, 2) or (p_method = 'upi' and nullif(btrim(p_reference), '') is null) or p_paid_at::date > current_date then
    raise exception 'Invalid payment details' using errcode = '23514';
  end if;
  select * into v_inst from public.installments where institute_id = p_institute and id = p_installment and student_id = p_student and student_fee_id = p_fee for update;
  if not found or v_inst.status = 'waived' or p_amount > v_inst.amount - v_inst.paid_amount then raise exception 'Amount exceeds due' using errcode = '23514'; end if;
  select case when i.code = 'SUNRISE-PAT' then 'SCB' else coalesce(nullif(s.receipt_prefix, ''), 'SCB') end, s.academic_year into v_prefix, v_year from public.institutes i left join public.institute_settings s on s.institute_id = i.id where i.id = p_institute for update of i;
  insert into public.payments (institute_id, student_id, student_fee_id, installment_id, amount, method, reference_no, paid_at, status, received_by)
  values (p_institute, p_student, p_fee, p_installment, p_amount, p_method, nullif(p_reference, ''), p_paid_at, 'completed', auth.uid()) returning * into v_payment;
  update public.installments set paid_amount = paid_amount + p_amount, paid_on = case when paid_amount + p_amount = amount then p_paid_at::date else null end,
    status = case when paid_amount + p_amount = amount then 'paid' else 'partial' end where id = p_installment;
  update public.student_fees set status = case when not exists (select 1 from public.installments where student_fee_id = p_fee and status <> 'waived' and paid_amount < amount) then 'settled' else 'active' end where id = p_fee;
  select coalesce(max((substring(receipt_no from '/([0-9]+)$'))::integer), 0) + 1 into v_serial from public.receipts where institute_id = p_institute;
  insert into public.receipts(institute_id, payment_id, student_id, receipt_no, amount, issued_by)
  values(p_institute, v_payment.id, p_student, v_prefix || '/' || right(coalesce(v_year, '2026-27'), 5) || '/' || lpad(v_serial::text, 4, '0'), p_amount, auth.uid());
  return v_payment;
end $$;

create or replace function public.reject_fee_payment(p_institute uuid, p_payment uuid)
returns public.payments language plpgsql security definer set search_path = '' as $$
declare v_payment public.payments; v_inst public.installments;
begin
  if not exists (select 1 from public.memberships where institute_id = p_institute and user_id = auth.uid() and status = 'active' and (role = 'owner' or 'fees' = any(permissions))) then
    raise exception 'Not allowed to reject fees' using errcode = '42501';
  end if;
  select * into v_payment from public.payments where institute_id = p_institute and id = p_payment for update;
  if not found or v_payment.status <> 'completed' then raise exception 'Only completed payments can be rejected' using errcode = '23514'; end if;
  select * into v_inst from public.installments where institute_id = p_institute and id = v_payment.installment_id for update;
  -- Preserve the issued number in history; a rejected payment never gets reused.
  update public.payments set status = 'failed' where id = p_payment returning * into v_payment;
  if v_inst.id is not null then
    update public.installments set paid_amount = paid_amount - v_payment.amount, paid_on = null,
      status = case when paid_amount - v_payment.amount > 0 then 'partial' when due_date < current_date then 'overdue' else 'upcoming' end where id = v_inst.id;
    update public.student_fees set status = 'active' where id = v_payment.student_fee_id;
  end if;
  return v_payment;
end $$;
revoke all on function public.record_fee_payment(uuid,uuid,uuid,uuid,numeric,text,text,timestamptz) from public;
revoke all on function public.reject_fee_payment(uuid,uuid) from public;
grant execute on function public.record_fee_payment(uuid,uuid,uuid,uuid,numeric,text,text,timestamptz) to authenticated;
grant execute on function public.reject_fee_payment(uuid,uuid) to authenticated;
