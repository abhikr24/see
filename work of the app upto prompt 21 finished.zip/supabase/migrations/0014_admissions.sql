-- Admissions pipeline: subject interest, next follow-up note, expanded sources,
-- no-delete rule, audited stage transitions, and atomic lead conversion RPC.

alter table public.admission_leads
  add column if not exists subject_interest text,
  add column if not exists next_followup_note text;

alter table public.admission_leads
  drop constraint if exists admission_leads_source_check;

alter table public.admission_leads
  add constraint admission_leads_source_check
  check (source in ('walk_in', 'referral', 'instagram', 'google', 'website', 'social', 'phone', 'campaign', 'other'));

create or replace function public.prevent_lead_delete()
returns trigger language plpgsql as $$
begin
  raise exception 'Leads cannot be deleted; mark as lost with a reason' using errcode = '23514';
end $$;

drop trigger if exists trg_admission_leads_no_delete on public.admission_leads;
create trigger trg_admission_leads_no_delete
  before delete on public.admission_leads
  for each row execute function public.prevent_lead_delete();

create or replace function public.move_admission_lead_stage(
  p_institute uuid,
  p_lead uuid,
  p_stage text,
  p_lost_reason text default null
)
returns public.admission_leads language plpgsql security definer set search_path = '' as $$
declare
  v_lead public.admission_leads;
  v_role text;
  v_reason text;
  v_prev_stage text;
begin
  select role into v_role from public.memberships
  where institute_id = p_institute and user_id = auth.uid() and status = 'active'
    and (role in ('owner', 'teacher') or 'leads' = any(permissions));
  if v_role is null then
    raise exception 'Not allowed to manage admissions' using errcode = '42501';
  end if;

  select * into v_lead from public.admission_leads
  where institute_id = p_institute and id = p_lead for update;
  if not found then raise exception 'Lead not found' using errcode = 'P0002'; end if;
  if v_lead.stage = 'enrolled' then raise exception 'A converted lead cannot be moved' using errcode = '23514'; end if;
  if p_stage = 'enrolled' then raise exception 'Use convert to admit this lead' using errcode = '23514'; end if;
  v_prev_stage := v_lead.stage;

  v_reason := nullif(btrim(coalesce(p_lost_reason, '')), '');
  if p_stage = 'lost' and v_reason is null then
    raise exception 'Please enter why this lead was lost' using errcode = '23514';
  end if;

  update public.admission_leads
  set stage = p_stage,
      lost_reason = case when p_stage = 'lost' then v_reason else null end,
      next_followup_at = case when p_stage = 'lost' then null else next_followup_at end
  where id = p_lead
  returning * into v_lead;

  insert into public.audit_logs (institute_id, actor_id, actor_role, action, entity_type, entity_id, old_data, new_data)
  values (
    p_institute, auth.uid(), v_role, 'lead.stage_changed', 'admission_lead', p_lead,
    jsonb_build_object('stage', v_prev_stage),
    jsonb_build_object('stage', p_stage, 'lostReason', v_reason)
  );
  return v_lead;
end $$;

create or replace function public.add_admission_followup(
  p_institute uuid,
  p_lead uuid,
  p_channel text,
  p_summary text,
  p_outcome text,
  p_followup_at timestamptz,
  p_next_followup_at timestamptz,
  p_next_followup_note text
)
returns public.lead_followups language plpgsql security definer set search_path = '' as $$
declare
  v_lead public.admission_leads;
  v_followup public.lead_followups;
  v_role text;
  v_next_stage text;
begin
  select role into v_role from public.memberships
  where institute_id = p_institute and user_id = auth.uid() and status = 'active'
    and (role in ('owner', 'teacher') or 'leads' = any(permissions));
  if v_role is null then
    raise exception 'Not allowed to log follow-ups' using errcode = '42501';
  end if;

  select * into v_lead from public.admission_leads
  where institute_id = p_institute and id = p_lead for update;
  if not found then raise exception 'Lead not found' using errcode = 'P0002'; end if;

  insert into public.lead_followups (
    institute_id, lead_id, channel, summary, outcome, followup_at, next_followup_at, done_by
  ) values (
    p_institute, p_lead, coalesce(p_channel, 'call'), p_summary, p_outcome,
    coalesce(p_followup_at, now()), p_next_followup_at, auth.uid()
  ) returning * into v_followup;

  v_next_stage := v_lead.stage;
  if v_lead.stage = 'new' then v_next_stage := 'contacted';
  elsif p_outcome = 'demo_booked' and v_lead.stage not in ('enrolled', 'lost') then v_next_stage := 'demo_scheduled';
  end if;

  update public.admission_leads
  set stage = v_next_stage,
      next_followup_at = coalesce(p_next_followup_at, next_followup_at),
      next_followup_note = coalesce(p_next_followup_note, next_followup_note)
  where id = p_lead;

  if v_next_stage <> v_lead.stage then
    insert into public.audit_logs (institute_id, actor_id, actor_role, action, entity_type, entity_id, old_data, new_data)
    values (
      p_institute, auth.uid(), v_role, 'lead.stage_changed', 'admission_lead', p_lead,
      jsonb_build_object('stage', v_lead.stage), jsonb_build_object('stage', v_next_stage)
    );
  end if;

  return v_followup;
end $$;

create or replace function public.convert_admission_lead(
  p_institute uuid,
  p_lead uuid,
  p_student_name text,
  p_phone text,
  p_guardian_name text,
  p_guardian_phone text,
  p_guardian_relation text,
  p_batch uuid,
  p_roll_number integer,
  p_monthly_fee numeric,
  p_fee_structure uuid,
  p_discount_ids text[],
  p_first_due_date date
)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_role text;
  v_lead public.admission_leads;
  v_batch public.batches;
  v_student public.student_profiles;
  v_guardian public.guardians;
  v_enrollment public.batch_students;
  v_structure public.fee_structures;
  v_fee public.student_fees;
  v_roll integer;
  v_gross numeric := 0;
  v_prev_stage text;
begin
  select role into v_role from public.memberships
  where institute_id = p_institute and user_id = auth.uid() and status = 'active'
    and (role in ('owner', 'teacher') or 'leads' = any(permissions));
  if v_role is null then
    raise exception 'Not allowed to convert leads' using errcode = '42501';
  end if;

  select * into v_lead from public.admission_leads where institute_id = p_institute and id = p_lead for update;
  if not found then raise exception 'Lead not found' using errcode = 'P0002'; end if;
  if v_lead.stage = 'enrolled' or v_lead.converted_student_id is not null then
    raise exception 'This lead is already converted' using errcode = '23514';
  end if;
  if v_lead.stage = 'lost' then
    raise exception 'Reopen a lost lead before converting' using errcode = '23514';
  end if;
  v_prev_stage := v_lead.stage;

  select * into v_batch from public.batches where institute_id = p_institute and id = p_batch and status <> 'archived';
  if not found then raise exception 'Batch not found' using errcode = 'P0002'; end if;

  v_roll := coalesce(
    p_roll_number,
    (select coalesce(max(roll_number), 0) + 1 from public.batch_students where institute_id = p_institute and batch_id = p_batch and status = 'active')
  );

  insert into public.student_profiles (
    institute_id, branch_id, full_name, phone, email, school_name, class_grade, status, admitted_on
  ) values (
    p_institute, v_lead.branch_id, btrim(p_student_name), p_phone, v_lead.email,
    v_lead.school_name, coalesce(v_batch.grade, v_lead.class_interested), 'active', coalesce(p_first_due_date, current_date)
  ) returning * into v_student;

  insert into public.guardians (institute_id, full_name, relation, phone)
  values (p_institute, coalesce(nullif(btrim(p_guardian_name), ''), v_lead.guardian_name, 'Parent'), coalesce(p_guardian_relation, 'guardian'), coalesce(nullif(p_guardian_phone, ''), p_phone))
  returning * into v_guardian;

  insert into public.parent_links (institute_id, student_id, guardian_id, is_primary)
  values (p_institute, v_student.id, v_guardian.id, true);

  insert into public.batch_students (institute_id, batch_id, student_id, roll_number, joined_on, status)
  values (p_institute, p_batch, v_student.id, v_roll, current_date, 'active')
  returning * into v_enrollment;

  if p_fee_structure is not null then
    select * into v_structure from public.fee_structures where institute_id = p_institute and id = p_fee_structure and is_active = true;
  else
    select * into v_structure from public.fee_structures
    where institute_id = p_institute and is_active = true and jsonb_array_length(schedule) > 0
      and (batch_id = p_batch or p_batch = any(batch_ids))
    order by version desc limit 1;
  end if;

  if v_structure.id is null and coalesce(p_monthly_fee, 0) > 0 then
    insert into public.fee_structures (
      institute_id, batch_id, batch_ids, name, academic_year, total_amount, installment_count, frequency, schedule, is_active
    ) values (
      p_institute, p_batch, array[p_batch], v_batch.name || ' monthly', v_batch.academic_year,
      p_monthly_fee, 1, 'monthly',
      jsonb_build_array(jsonb_build_object('id', 'i1', 'label', 'Monthly fee', 'amount', p_monthly_fee, 'dueDate', coalesce(p_first_due_date, current_date))),
      true
    ) returning * into v_structure;
  end if;

  if v_structure.id is not null then
    v_gross := v_structure.total_amount;
    insert into public.student_fees (
      institute_id, student_id, fee_structure_id, academic_year, gross_amount, discount_amount, discount_ids, net_amount, status
    ) values (
      p_institute, v_student.id, v_structure.id, v_structure.academic_year, v_gross, 0, coalesce(p_discount_ids, '{}'), v_gross, 'active'
    ) returning * into v_fee;

    insert into public.installments (institute_id, student_fee_id, student_id, term_no, label, amount, due_date, paid_amount, status)
    select p_institute, v_fee.id, v_student.id, ord, coalesce(item->>'label', 'Instalment ' || ord),
      (item->>'amount')::numeric, (item->>'dueDate')::date, 0, 'upcoming'
    from jsonb_array_elements(v_structure.schedule) with ordinality as t(item, ord);
  end if;

  update public.admission_leads
  set stage = 'enrolled',
      converted_student_id = v_student.id,
      next_followup_at = null,
      next_followup_note = null,
      expected_fee = coalesce(v_fee.net_amount, expected_fee)
  where id = p_lead
  returning * into v_lead;

  insert into public.audit_logs (institute_id, actor_id, actor_role, action, entity_type, entity_id, old_data, new_data)
  values (
    p_institute, auth.uid(), v_role, 'lead.converted', 'admission_lead', p_lead,
    jsonb_build_object('stage', v_prev_stage),
    jsonb_build_object('stage', 'enrolled', 'convertedStudentId', v_student.id, 'batchId', p_batch)
  );

  return jsonb_build_object(
    'lead', to_jsonb(v_lead),
    'student', to_jsonb(v_student),
    'guardian', to_jsonb(v_guardian),
    'enrollment', to_jsonb(v_enrollment),
    'studentFee', case when v_fee.id is not null then to_jsonb(v_fee) else null end
  );
end $$;

revoke all on function public.move_admission_lead_stage(uuid,uuid,text,text) from public;
revoke all on function public.add_admission_followup(uuid,uuid,text,text,text,timestamptz,timestamptz,text) from public;
revoke all on function public.convert_admission_lead(uuid,uuid,text,text,text,text,text,uuid,integer,numeric,uuid,text[],date) from public;
grant execute on function public.move_admission_lead_stage(uuid,uuid,text,text) to authenticated;
grant execute on function public.add_admission_followup(uuid,uuid,text,text,text,timestamptz,timestamptz,text) to authenticated;
grant execute on function public.convert_admission_lead(uuid,uuid,text,text,text,text,text,uuid,integer,numeric,uuid,text[],date) to authenticated;
