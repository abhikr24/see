-- =====================================================================
-- seed.sql · demo data for local development (supabase db reset)
--
--   Sunrise Coaching Classes, Patna · code SUNRISE-PAT
--   1 owner · 5 teachers · 12 students (Class 10-A, roll 14–25)
--   30 attendance days · Unit Test 3 · 3 fee terms · 6 notices
--   8 admission leads · 6 pending join requests
--
-- IDs are fixed:  00000000-0000-4000-8000-0000000000NN
--   01 institute        02 owner            03–07 teachers
--   08 branch           09 batch            14–25 students (NN = roll no.)
--   38–43 pending users 44–48 subjects      50 exam
--   51 fee structure    61–66 notices       71–78 leads
-- A person keeps their NN in every table that has one row per person
-- (users, profiles, memberships, student_profiles, teacher_profiles …).
-- Tables with one row per student per day / subject / term use
--   00000000-0000-4000-8000-0000XX0000NN
-- where XX = day (01–30), subject (44–48) or term (01–03), NN = roll no.
--
-- Dates are relative to current_date so the data always looks current.
-- Every account can sign in with the password below. LOCAL USE ONLY –
-- never run this file against a production project.
--   password: guruflow-dev
-- =====================================================================

set search_path = public, extensions;

-- ---------------------------------------------------------------------
-- People → auth.users (handle_auth_user fills users / profiles /
-- user_preferences with the same id)
-- ---------------------------------------------------------------------
create temporary table seed_people (nn int primary key, full_name text, email text, kind text);

insert into seed_people (nn, full_name, email, kind) values
  ( 2, 'Rahul Sharma',    'rahul.sharma@sunrise.test',    'owner'),
  ( 3, 'Rohit Verma',     'rohit.verma@sunrise.test',     'teacher'),
  ( 4, 'Priya Nair',      'priya.nair@sunrise.test',      'teacher'),
  ( 5, 'Meera Iyer',      'meera.iyer@sunrise.test',      'teacher'),
  ( 6, 'Sneha Iyer',      'sneha.iyer@sunrise.test',      'teacher'),
  ( 7, 'Arun Kumar',      'arun.kumar@sunrise.test',      'teacher'),
  (14, 'Aarav Sharma',    'aarav.sharma@sunrise.test',    'student'),
  (15, 'Aditya Pandey',   'aditya.pandey@sunrise.test',   'student'),
  (16, 'Ananya Singh',    'ananya.singh@sunrise.test',    'student'),
  (17, 'Diya Gupta',      'diya.gupta@sunrise.test',      'student'),
  (18, 'Faizan Khan',     'faizan.khan@sunrise.test',     'student'),
  (19, 'Ishaan Mishra',   'ishaan.mishra@sunrise.test',   'student'),
  (20, 'Kavya Sinha',     'kavya.sinha@sunrise.test',     'student'),
  (21, 'Neha Kumari',     'neha.kumari@sunrise.test',     'student'),
  (22, 'Rohan Yadav',     'rohan.yadav@sunrise.test',     'student'),
  (23, 'Saanvi Jha',      'saanvi.jha@sunrise.test',      'student'),
  (24, 'Tanvi Prasad',    'tanvi.prasad@sunrise.test',    'student'),
  (25, 'Vivaan Raj',      'vivaan.raj@sunrise.test',      'student'),
  (38, 'Kunal Sinha',     'kunal.sinha@sunrise.test',     'pending'),
  (39, 'Riya Chaudhary',  'riya.chaudhary@sunrise.test',  'pending'),
  (40, 'Harsh Tiwari',    'harsh.tiwari@sunrise.test',    'pending'),
  (41, 'Anita Tiwari',    'anita.tiwari@sunrise.test',    'pending'),
  (42, 'Sanjay Chaudhary','sanjay.chaudhary@sunrise.test','pending'),
  (43, 'Nikhil Anand',    'nikhil.anand@sunrise.test',    'pending');

insert into auth.users (
  id, instance_id, aud, role, email, encrypted_password, email_confirmed_at,
  raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
  confirmation_token, recovery_token, email_change, email_change_token_new
)
select
  ('00000000-0000-4000-8000-' || lpad(p.nn::text, 12, '0'))::uuid,
  '00000000-0000-0000-0000-000000000000',
  'authenticated', 'authenticated',
  p.email,
  pw.hash,
  now(),
  '{"provider":"email","providers":["email"]}'::jsonb,
  jsonb_build_object('full_name', p.full_name),
  now(), now(),
  '', '', '', ''
from seed_people p
cross join (select crypt('guruflow-dev', gen_salt('bf', 10)) as hash) pw
order by p.nn;

insert into auth.identities (id, provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
select
  u.id, u.id::text, u.id,
  jsonb_build_object('sub', u.id::text, 'email', u.email, 'email_verified', true, 'phone_verified', false),
  'email', now(), now(), now()
from auth.users u
join seed_people p on p.email = u.email;

update public.profiles pr
   set full_name = p.full_name, city = 'Patna', state = 'Bihar'
  from seed_people p
 where pr.user_id = ('00000000-0000-4000-8000-' || lpad(p.nn::text, 12, '0'))::uuid;

-- ---------------------------------------------------------------------
-- Institute
-- ---------------------------------------------------------------------
insert into public.institutes (id, name, code, owner_id, tagline, phone, email, address, city, state, pincode)
values (
  '00000000-0000-4000-8000-000000000001',
  'Sunrise Coaching Classes', 'SUNRISE-PAT',
  '00000000-0000-4000-8000-000000000002',
  'Strong basics. Bright results.',
  '+91 90000 00001', 'office@sunrise.test',
  'Boring Road', 'Patna', 'Bihar', '800001'
);

insert into public.branches (id, institute_id, name, code, address, city, state, pincode, is_main)
values (
  '00000000-0000-4000-8000-000000000008', '00000000-0000-4000-8000-000000000001',
  'Boring Road (Main)', 'MAIN', 'Boring Road', 'Patna', 'Bihar', '800001', true
);

insert into public.institute_settings (id, institute_id, academic_year, receipt_prefix)
values (
  '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000001',
  -- Indian academic year, April to March
  case when extract(month from current_date) >= 4
       then extract(year from current_date)::int || '-' || lpad(((extract(year from current_date)::int + 1) % 100)::text, 2, '0')
       else (extract(year from current_date)::int - 1) || '-' || lpad((extract(year from current_date)::int % 100)::text, 2, '0')
  end,
  'SCC'
);

-- Memberships: owner, teachers and students are active; 38–43 are the six
-- pending join requests. (The owner row already exists – creating the
-- institute made it – so it is only given its fixed id here.)
insert into public.memberships (id, institute_id, user_id, branch_id, role, status, request_note, requested_at, decided_by, decided_at)
select
  ('00000000-0000-4000-8000-' || lpad(p.nn::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000001',
  ('00000000-0000-4000-8000-' || lpad(p.nn::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000008',
  case p.nn when 38 then 'student' when 39 then 'student' when 40 then 'student'
            when 41 then 'parent'  when 42 then 'parent'  when 43 then 'teacher'
            else p.kind end,
  case p.kind when 'pending' then 'pending' else 'active' end,
  case p.nn when 38 then 'I want to join Class 10-A.'
            when 39 then 'New admission for Class 10, joining from next week.'
            when 40 then 'Referred by Rohan Yadav. Looking for the Class 9 batch.'
            when 41 then 'Mother of Harsh Tiwari.'
            when 42 then 'Father of Riya Chaudhary.'
            when 43 then 'Applying to teach Social Science, 4 years of experience.'
  end,
  case p.kind when 'pending' then now() - make_interval(days => p.nn - 37) else now() - interval '200 days' end,
  case p.kind when 'pending' then null else '00000000-0000-4000-8000-000000000002'::uuid end,
  case p.kind when 'pending' then null else now() - interval '200 days' end
from seed_people p
order by p.nn
on conflict (institute_id, user_id) do update
  set id = excluded.id, branch_id = excluded.branch_id,
      requested_at = excluded.requested_at, decided_at = excluded.decided_at;

-- ---------------------------------------------------------------------
-- Subjects, batch, teachers
-- ---------------------------------------------------------------------
insert into public.subjects (id, institute_id, name, code, color) values
  ('00000000-0000-4000-8000-000000000044', '00000000-0000-4000-8000-000000000001', 'Mathematics', 'MATH', '#2563EB'),
  ('00000000-0000-4000-8000-000000000045', '00000000-0000-4000-8000-000000000001', 'Physics',     'PHY',  '#7C3AED'),
  ('00000000-0000-4000-8000-000000000046', '00000000-0000-4000-8000-000000000001', 'Chemistry',   'CHEM', '#DB2777'),
  ('00000000-0000-4000-8000-000000000047', '00000000-0000-4000-8000-000000000001', 'English',     'ENG',  '#D97706'),
  ('00000000-0000-4000-8000-000000000048', '00000000-0000-4000-8000-000000000001', 'Biology',     'BIO',  '#059669');

insert into public.batches (id, institute_id, branch_id, name, grade, section, academic_year, capacity, starts_on, status)
select
  '00000000-0000-4000-8000-000000000009', s.institute_id, '00000000-0000-4000-8000-000000000008',
  'Class 10-A', '10', 'A', s.academic_year, 40, current_date - 200, 'active'
from public.institute_settings s
where s.institute_id = '00000000-0000-4000-8000-000000000001';

-- Teachers. None of these accounts has, or can have, a student record.
create temporary table seed_teachers (nn int primary key, subject_nn int, qualification text, experience_years int);
insert into seed_teachers values
  (3, 44, 'M.Sc. Mathematics, B.Ed.', 9),
  (4, 45, 'M.Sc. Physics',            7),
  (5, 46, 'M.Sc. Chemistry, B.Ed.',   8),
  (6, 47, 'M.A. English, B.Ed.',      5),
  (7, 48, 'M.Sc. Zoology',            6);

insert into public.teacher_profiles (id, institute_id, user_id, branch_id, full_name, specialization, qualification, experience_years)
select
  ('00000000-0000-4000-8000-' || lpad(t.nn::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000001',
  ('00000000-0000-4000-8000-' || lpad(t.nn::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000008',
  p.full_name, s.name, t.qualification, t.experience_years
from seed_teachers t
join seed_people p on p.nn = t.nn
join public.subjects s on s.id = ('00000000-0000-4000-8000-' || lpad(t.subject_nn::text, 12, '0'))::uuid
order by t.nn;

-- Rohit Verma is the class teacher of 10-A
insert into public.batch_teachers (id, institute_id, batch_id, teacher_id, subject_id, is_class_teacher, assigned_on)
select
  ('00000000-0000-4000-8000-' || lpad(t.nn::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000001',
  '00000000-0000-4000-8000-000000000009',
  ('00000000-0000-4000-8000-' || lpad(t.nn::text, 12, '0'))::uuid,
  ('00000000-0000-4000-8000-' || lpad(t.subject_nn::text, 12, '0'))::uuid,
  t.nn = 3,
  current_date - 200
from seed_teachers t
order by t.nn;

insert into public.teacher_assignments (id, institute_id, teacher_id, subject_id, batch_id, assignment_role, periods_per_week, starts_on)
select
  ('00000000-0000-4000-8000-' || lpad(t.nn::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000001',
  ('00000000-0000-4000-8000-' || lpad(t.nn::text, 12, '0'))::uuid,
  ('00000000-0000-4000-8000-' || lpad(t.subject_nn::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000009',
  case when t.nn = 3 then 'class_teacher' else 'subject_teacher' end,
  6,
  current_date - 200
from seed_teachers t
order by t.nn;

-- ---------------------------------------------------------------------
-- Students · Class 10-A, roll 14–25
-- ---------------------------------------------------------------------
create temporary table seed_students (nn int primary key, gender text, date_of_birth date);
insert into seed_students values
  (14, 'male',   '2011-03-12'), (15, 'male',   '2011-07-25'), (16, 'female', '2011-01-30'),
  (17, 'female', '2011-09-08'), (18, 'male',   '2010-12-19'), (19, 'male',   '2011-05-03'),
  (20, 'female', '2011-11-21'), (21, 'female', '2011-02-14'), (22, 'male',   '2010-10-06'),
  (23, 'female', '2011-06-17'), (24, 'female', '2011-08-29'), (25, 'male',   '2011-04-09');

insert into public.student_profiles (id, institute_id, branch_id, admission_no, full_name, date_of_birth, gender, email, city, class_grade, admitted_on)
select
  ('00000000-0000-4000-8000-' || lpad(s.nn::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000001',
  '00000000-0000-4000-8000-000000000008',
  'SCC-' || lpad(s.nn::text, 4, '0'),
  p.full_name, s.date_of_birth, s.gender, p.email, 'Patna', '10', current_date - 200
from seed_students s
join seed_people p on p.nn = s.nn
order by s.nn;

insert into public.student_memberships (id, institute_id, student_id, membership_id, linked_by)
select
  ('00000000-0000-4000-8000-' || lpad(s.nn::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000001',
  ('00000000-0000-4000-8000-' || lpad(s.nn::text, 12, '0'))::uuid,
  ('00000000-0000-4000-8000-' || lpad(s.nn::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000002'
from seed_students s
order by s.nn;

insert into public.batch_students (id, institute_id, batch_id, student_id, roll_number, joined_on)
select
  ('00000000-0000-4000-8000-' || lpad(s.nn::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000001',
  '00000000-0000-4000-8000-000000000009',
  ('00000000-0000-4000-8000-' || lpad(s.nn::text, 12, '0'))::uuid,
  s.nn,
  current_date - 200
from seed_students s
order by s.nn;

-- ---------------------------------------------------------------------
-- Attendance · the last 30 working days (Mon–Sat) up to yesterday
--   12 students × 30 days = 360 records
--   323 present + 8 late = 331 attended → 91.94 %, shown as 92 %
--   25 absent + 4 leave  =  29 missed
--   (360 records cannot give exactly 92.00 %; 331 is the closest.)
-- Day 01 is the oldest session, day 30 is yesterday (or Saturday).
-- ---------------------------------------------------------------------
create temporary table seed_days as
select d::date as session_date, row_number() over (order by d)::int as day_no
from generate_series(current_date - 35, current_date - 1, interval '1 day') d
where extract(dow from d) <> 0;

insert into public.attendance_sessions (id, institute_id, batch_id, teacher_id, session_date, period, status, marked_by, marked_at)
select
  ('00000000-0000-4000-8000-' || lpad(d.day_no::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000001',
  '00000000-0000-4000-8000-000000000009',
  '00000000-0000-4000-8000-000000000003',
  d.session_date, 1, 'locked',
  '00000000-0000-4000-8000-000000000003',
  d.session_date + time '16:10'
from seed_days d
order by d.day_no;

-- everyone is present except on the days listed here
create temporary table seed_attendance_exceptions (roll int, day_no int, status text, remark text, primary key (roll, day_no));
insert into seed_attendance_exceptions values
  (14,  7, 'absent', null), (14, 19, 'absent', null),                        (14,  3, 'late', null),
  (15,  4, 'absent', null), (15, 22, 'leave',  'Family function'),           (15, 11, 'late', null),
  (16,  2, 'absent', null), (16, 15, 'absent', null), (16, 27, 'absent', null),
  (17,  9, 'absent', null), (17, 24, 'absent', null),                        (17, 16, 'late', null),
  (18,  5, 'absent', 'Fever'), (18,  6, 'absent', 'Fever'), (18, 20, 'leave', 'Medical appointment'),
  (19, 12, 'absent', null), (19, 28, 'absent', null),                        (19,  1, 'late', null),
  (20,  8, 'absent', null), (20, 17, 'absent', null), (20, 25, 'leave', 'Out of station'),
  (21, 10, 'absent', null), (21, 21, 'absent', null),                        (21, 14, 'late', null),
  (22,  3, 'absent', null), (22, 13, 'absent', null), (22, 26, 'absent', null), (22, 18, 'late', null),
  (23, 14, 'absent', null), (23, 29, 'leave',  'School event'),              (23,  6, 'late', null),
  (24,  1, 'absent', null), (24, 11, 'absent', null), (24, 23, 'absent', null), (24, 30, 'late', null),
  (25, 16, 'absent', null), (25, 30, 'absent', null);

insert into public.attendance_records (id, institute_id, session_id, batch_id, student_id, status, remark, marked_by)
select
  ('00000000-0000-4000-8000-' || lpad((d.day_no * 1000000 + s.nn)::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000001',
  ('00000000-0000-4000-8000-' || lpad(d.day_no::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000009',
  ('00000000-0000-4000-8000-' || lpad(s.nn::text, 12, '0'))::uuid,
  coalesce(x.status, 'present'),
  x.remark,
  '00000000-0000-4000-8000-000000000003'
from seed_days d
cross join seed_students s
left join seed_attendance_exceptions x on x.roll = s.nn and x.day_no = d.day_no
order by d.day_no, s.nn;

-- ---------------------------------------------------------------------
-- Unit Test 3 · 5 subjects × 25 marks
-- ---------------------------------------------------------------------
insert into public.exams (id, institute_id, batch_id, name, exam_type, starts_on, ends_on, total_marks, pass_percent, status, published_at, created_by)
values (
  '00000000-0000-4000-8000-000000000050', '00000000-0000-4000-8000-000000000001',
  '00000000-0000-4000-8000-000000000009',
  'Unit Test 3', 'unit_test', current_date - 12, current_date - 10, 125, 33, 'published',
  now() - interval '5 days', '00000000-0000-4000-8000-000000000003'
);

create temporary table seed_marks (roll int primary key, math numeric, phy numeric, chem numeric, eng numeric, bio numeric);
insert into seed_marks values
  (14, 23, 21, 22, 24, 22),
  (15, 18, 17, 19, 20, 18),
  (16, 24, 23, 24, 22, 25),
  (17, 20, 19, 21, 23, 22),
  (18, 16, 18, 15, 19, 17),
  (19, 21, 22, 20, 18, 19),
  (20, 22, 20, 23, 24, 21),
  (21, 15, 14, 16, 20, 18),
  (22, 12, 13, 11, 16, 14),
  (23, 25, 24, 23, 23, 24),
  (24, 19, 18, 20, 22, 20),
  (25,  9, 11, 10, 15, 12);

insert into public.marks (id, institute_id, exam_id, batch_id, student_id, subject_id, marks_obtained, max_marks, grade, entered_by)
select
  ('00000000-0000-4000-8000-' || lpad((v.subject_nn * 1000000 + m.roll)::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000001',
  '00000000-0000-4000-8000-000000000050',
  '00000000-0000-4000-8000-000000000009',
  ('00000000-0000-4000-8000-' || lpad(m.roll::text, 12, '0'))::uuid,
  ('00000000-0000-4000-8000-' || lpad(v.subject_nn::text, 12, '0'))::uuid,
  v.score, 25,
  case when v.score >= 22.5 then 'A+' when v.score >= 20 then 'A' when v.score >= 17.5 then 'B'
       when v.score >= 15 then 'C' when v.score >= 8.25 then 'D' else 'E' end,
  -- entered by the teacher of that subject (teacher NN = subject NN − 41)
  ('00000000-0000-4000-8000-' || lpad((v.subject_nn - 41)::text, 12, '0'))::uuid
from seed_marks m
cross join lateral (values (44, m.math), (45, m.phy), (46, m.chem), (47, m.eng), (48, m.bio)) as v (subject_nn, score)
order by v.subject_nn, m.roll;

insert into public.results (id, institute_id, exam_id, batch_id, student_id, total_obtained, total_max, percentage, grade, rank, result_status)
select
  t.student_id, '00000000-0000-4000-8000-000000000001',
  '00000000-0000-4000-8000-000000000050', '00000000-0000-4000-8000-000000000009',
  t.student_id, t.total, t.total_max, t.pct,
  case when t.pct >= 90 then 'A+' when t.pct >= 80 then 'A' when t.pct >= 70 then 'B'
       when t.pct >= 60 then 'C' when t.pct >= 33 then 'D' else 'E' end,
  rank() over (order by t.total desc),
  case when t.pct >= 33 then 'pass' else 'fail' end
from (
  select mk.student_id,
         sum(mk.marks_obtained) as total,
         sum(mk.max_marks) as total_max,
         round(sum(mk.marks_obtained) * 100 / sum(mk.max_marks), 2) as pct
  from public.marks mk
  where mk.exam_id = '00000000-0000-4000-8000-000000000050'
  group by mk.student_id
) t
order by t.student_id;

-- ---------------------------------------------------------------------
-- Fees · ₹36,000 a year in 3 terms of ₹12,000
--   Term 1 (due 150 days ago) : paid by all 12
--   Term 2 (due 30 days ago)  : 8 paid (roll 14–21), 2 partial (22, 23),
--                               2 overdue (24, 25)
--   Term 3 (due in 90 days)   : upcoming
-- ---------------------------------------------------------------------
insert into public.fee_structures (id, institute_id, batch_id, name, academic_year, total_amount, installment_count, frequency, components)
select
  '00000000-0000-4000-8000-000000000051', b.institute_id, b.id,
  'Class 10 · Annual fee', b.academic_year, 36000, 3, 'term',
  '[{"label":"Tuition","amount":33000},{"label":"Study material & tests","amount":3000}]'::jsonb
from public.batches b
where b.id = '00000000-0000-4000-8000-000000000009';

insert into public.student_fees (id, institute_id, student_id, fee_structure_id, academic_year, gross_amount)
select
  ('00000000-0000-4000-8000-' || lpad(s.nn::text, 12, '0'))::uuid,
  f.institute_id,
  ('00000000-0000-4000-8000-' || lpad(s.nn::text, 12, '0'))::uuid,
  f.id, f.academic_year, f.total_amount
from seed_students s
cross join public.fee_structures f
where f.id = '00000000-0000-4000-8000-000000000051'
order by s.nn;

create temporary table seed_terms as
select
  s.nn as roll,
  t.term_no,
  t.due_date,
  12000::numeric as amount,
  case
    when t.term_no = 1 then 12000
    when t.term_no = 2 and s.nn <= 21 then 12000
    when t.term_no = 2 and s.nn in (22, 23) then 6000
    else 0
  end::numeric as paid,
  -- paid a few days before the due date; partial payments came in late
  case
    when t.term_no = 1 then t.due_date - (s.nn % 5)
    when t.term_no = 2 and s.nn <= 21 then t.due_date - (s.nn % 4)
    when t.term_no = 2 and s.nn in (22, 23) then t.due_date + 6
  end as paid_on
from seed_students s
cross join (values (1, current_date - 150), (2, current_date - 30), (3, current_date + 90)) as t (term_no, due_date);

insert into public.installments (id, institute_id, student_fee_id, student_id, term_no, label, amount, due_date, paid_amount, paid_on, status)
select
  ('00000000-0000-4000-8000-' || lpad((t.term_no * 1000000 + t.roll)::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000001',
  ('00000000-0000-4000-8000-' || lpad(t.roll::text, 12, '0'))::uuid,
  ('00000000-0000-4000-8000-' || lpad(t.roll::text, 12, '0'))::uuid,
  t.term_no, 'Term ' || t.term_no, t.amount, t.due_date, t.paid,
  case when t.paid = t.amount then t.paid_on end,
  case
    when t.paid = t.amount then 'paid'
    when t.paid > 0 then 'partial'
    when t.due_date < current_date then 'overdue'
    else 'upcoming'
  end
from seed_terms t
order by t.term_no, t.roll;

insert into public.payments (id, institute_id, student_id, student_fee_id, installment_id, amount, method, reference_no, paid_at, status, received_by)
select
  ('00000000-0000-4000-8000-' || lpad((t.term_no * 1000000 + t.roll)::text, 12, '0'))::uuid,
  '00000000-0000-4000-8000-000000000001',
  ('00000000-0000-4000-8000-' || lpad(t.roll::text, 12, '0'))::uuid,
  ('00000000-0000-4000-8000-' || lpad(t.roll::text, 12, '0'))::uuid,
  ('00000000-0000-4000-8000-' || lpad((t.term_no * 1000000 + t.roll)::text, 12, '0'))::uuid,
  t.paid,
  (array['upi', 'cash', 'bank_transfer', 'card'])[1 + (t.roll + t.term_no) % 4],
  case (t.roll + t.term_no) % 4 when 1 then null else 'TXN' || t.term_no || lpad(t.roll::text, 4, '0') end,
  t.paid_on + time '17:30',
  'completed',
  '00000000-0000-4000-8000-000000000002'
from seed_terms t
where t.paid > 0
order by t.term_no, t.roll;

insert into public.receipts (id, institute_id, payment_id, student_id, receipt_no, amount, issued_at, issued_by)
select
  p.id, p.institute_id, p.id, p.student_id,
  'SCC-R-' || lpad((row_number() over (order by p.paid_at, p.id))::text, 4, '0'),
  p.amount, p.paid_at, p.received_by
from public.payments p
where p.institute_id = '00000000-0000-4000-8000-000000000001'
order by p.paid_at, p.id;

-- ---------------------------------------------------------------------
-- Notices
-- ---------------------------------------------------------------------
insert into public.notices (id, institute_id, batch_id, title, body, category, audience, is_pinned, published_at, created_by) values
  ('00000000-0000-4000-8000-000000000061', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000009',
   'Unit Test 3 results are out',
   'Marks for all five subjects are now available in the app. Answer sheets will be returned in class this week.',
   'exam', '{teacher,student,parent}', true, now() - interval '5 days', '00000000-0000-4000-8000-000000000003'),
  ('00000000-0000-4000-8000-000000000062', '00000000-0000-4000-8000-000000000001', null,
   'Term 2 fees are due this week',
   'Please clear the Term 2 instalment by the due date. Fees can be paid by UPI, card or at the front desk.',
   'fee', '{student,parent}', false, now() - interval '33 days', '00000000-0000-4000-8000-000000000002'),
  ('00000000-0000-4000-8000-000000000063', '00000000-0000-4000-8000-000000000001', null,
   'Parent–teacher meeting this Saturday',
   'Parents of Class 10 students are invited to meet the subject teachers between 4 pm and 6 pm.',
   'event', '{teacher,student,parent}', false, now() - interval '2 days', '00000000-0000-4000-8000-000000000002'),
  ('00000000-0000-4000-8000-000000000064', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000009',
   'Revised evening timings for Class 10-A',
   'From Monday, classes will run from 4:00 pm to 7:30 pm. The Saturday test slot is unchanged.',
   'academic', '{owner,admin,teacher,student,parent}', false, now() - interval '9 days', '00000000-0000-4000-8000-000000000003'),
  ('00000000-0000-4000-8000-000000000065', '00000000-0000-4000-8000-000000000001', null,
   'Staff meeting on Monday at 3 pm',
   'Agenda: Unit Test 3 review, pre-board schedule and doubt-session roster.',
   'general', '{owner,admin,teacher}', false, now() - interval '1 day', '00000000-0000-4000-8000-000000000002'),
  ('00000000-0000-4000-8000-000000000066', '00000000-0000-4000-8000-000000000001', null,
   'Doubt-clearing camp for Maths and Physics',
   'Extra doubt sessions will be held every Sunday morning this month. Bring your Unit Test papers.',
   'academic', '{teacher,student,parent}', false, now() - interval '14 days', '00000000-0000-4000-8000-000000000002');

-- ---------------------------------------------------------------------
-- Admission leads · one at each stage of the pipeline
-- ---------------------------------------------------------------------
insert into public.admission_leads
  (id, institute_id, branch_id, student_name, guardian_name, phone, class_interested, source, stage,
   assigned_to, expected_fee, next_followup_at, lost_reason, notes, created_at)
values
  ('00000000-0000-4000-8000-000000000071', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000008',
   'Aryan Sinha', 'Pankaj Sinha', '+91 90000 00071', '10', 'website', 'new',
   '00000000-0000-4000-8000-000000000002', 36000, now() + interval '1 day', null,
   'Enquired through the website form.', now() - interval '1 day'),
  ('00000000-0000-4000-8000-000000000072', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000008',
   'Bhavya Kumari', 'Ramesh Prasad', '+91 90000 00072', '9', 'referral', 'contacted',
   '00000000-0000-4000-8000-000000000002', 30000, now() + interval '2 days', null,
   'Spoke to the father; asked to call back in the evening.', now() - interval '4 days'),
  ('00000000-0000-4000-8000-000000000073', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000008',
   'Chirag Anand', 'Seema Anand', '+91 90000 00073', '10', 'walk_in', 'interested',
   '00000000-0000-4000-8000-000000000002', 36000, now() + interval '3 days', null,
   'Wants the Science and Maths combination.', now() - interval '6 days'),
  ('00000000-0000-4000-8000-000000000074', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000008',
   'Divya Bharti', 'Alok Bharti', '+91 90000 00074', '10', 'social', 'demo_scheduled',
   '00000000-0000-4000-8000-000000000002', 36000, now() + interval '2 days', null,
   'Demo class booked for Maths.', now() - interval '8 days'),
  ('00000000-0000-4000-8000-000000000075', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000008',
   'Eshan Ali', 'Shabnam Ali', '+91 90000 00075', '9', 'phone', 'demo_attended',
   '00000000-0000-4000-8000-000000000002', 30000, now() + interval '1 day', null,
   'Attended the Physics demo and liked it.', now() - interval '11 days'),
  ('00000000-0000-4000-8000-000000000076', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000008',
   'Garima Singh', 'Vinod Singh', '+91 90000 00076', '10', 'referral', 'negotiation',
   '00000000-0000-4000-8000-000000000002', 33000, now() + interval '1 day', null,
   'Asked for a sibling discount.', now() - interval '15 days'),
  ('00000000-0000-4000-8000-000000000077', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000008',
   'Himanshu Ranjan', 'Nidhi Ranjan', '+91 90000 00077', '9', 'walk_in', 'enrolled',
   '00000000-0000-4000-8000-000000000002', 30000, null, null,
   'Admission form and Term 1 fee received. Joins the Class 9 batch.', now() - interval '21 days'),
  ('00000000-0000-4000-8000-000000000078', '00000000-0000-4000-8000-000000000001', '00000000-0000-4000-8000-000000000008',
   'Juhi Sahay', 'Mukesh Sahay', '+91 90000 00078', '10', 'campaign', 'lost',
   '00000000-0000-4000-8000-000000000002', 36000, null, 'Joined an institute closer to home.',
   null, now() - interval '30 days');

-- ---------------------------------------------------------------------
-- Clean up the scratch tables used above
-- ---------------------------------------------------------------------
drop table seed_people, seed_teachers, seed_students, seed_days,
           seed_attendance_exceptions, seed_marks, seed_terms;

reset search_path;
