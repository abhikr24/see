/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{ts,tsx}', './src/**/*.{ts,tsx}'],
  presets: [require('nativewind/preset')],
  theme: {
    extend: {
      colors: {
        canvas: 'rgb(245, 246, 250)',
        surface: 'rgb(255, 255, 255)',
        ink: 'rgb(11, 18, 32)',
        secondary: 'rgb(90, 102, 132)',
        muted: 'rgb(148, 160, 188)',
        hairline: 'rgb(231, 235, 245)',
        primary: 'rgb(16, 27, 76)',
        primary2: 'rgb(30, 58, 138)',
        accent: 'rgb(255, 122, 26)',
        accentSoft: 'rgb(255, 241, 230)',
        teal: 'rgb(13, 148, 136)',
        tealSoft: 'rgb(228, 247, 244)',
        success: 'rgb(22, 163, 74)',
        successSoft: 'rgb(220, 245, 229)',
        warning: 'rgb(245, 158, 11)',
        warningSoft: 'rgb(254, 241, 214)',
        danger: 'rgb(220, 38, 38)',
        dangerSoft: 'rgb(254, 236, 236)',
        track: 'rgb(239, 242, 248)',
        navySoft: 'rgb(232, 238, 255)',
      },
      borderRadius: {
        card: '20px',
        btn: '16px',
        field: '14px',
        sheet: '28px',
        chip: '999px',
      },
    },
  },
  plugins: [],
};
