import assert from 'node:assert/strict';
import { createDb } from '../src/backends/memory/db';
import { seed, SEED } from '../src/backends/memory/seed';
import { batchRepo } from '../src/backends/memory/academics';
import { leadRepo } from '../src/backends/memory/business';
import { feeRepo } from '../src/backends/memory/finance';
import { guardianRepo, studentRepo } from '../src/backends/memory/people';
import { capture, restore } from '../src/backends/memory/persist';
import { addDays, todayIso } from '../src/backends/memory/store';
import {
  computeAdmissionsSummary,
  formatAvgResponse,
  isNextActionOverdue,
  leadRowSubtitle,
} from '../src/core/contracts/admissions';

let passed = 0;
const check = (name: string, fn: () => void | Promise<void>) =>
  Promise.resolve(fn()).then(() => {
    passed += 1;
    console.log(`  ✓ ${name}`);
  });

async function main() {
  const db = createDb();
  seed(db);
  db.session.userId = SEED.ownerId;

  const i = SEED.instituteId;
  const leads = leadRepo(db);
  const students = studentRepo(db);
  const guardians = guardianRepo(db);
  const batches = batchRepo(db);
  const fees = feeRepo(db);
  const today = todayIso();

  console.log('Admissions acceptance');

  await check('seeded pipeline covers all five segments and matches underlying stages', async () => {
    const p = await leads.pipeline(i);
    assert.equal(p.items.length, 8);
    assert.equal(p.items.filter((x) => x.segment === 'new').length, 1);
    assert.equal(p.items.filter((x) => x.segment === 'following_up').length, 4);
    assert.equal(p.items.filter((x) => x.segment === 'demo_booked').length, 1);
    assert.equal(p.items.filter((x) => x.segment === 'converted').length, 1);
    assert.equal(p.items.filter((x) => x.segment === 'lost').length, 1);
    assert.equal(p.summary.totalLeads, 8);
    assert.equal(p.summary.convertedCount, 1);
    assert.equal(p.summary.conversionPercent, Math.round((1 / 8) * 100));
    assert.ok(p.summary.avgResponseMinutes !== null && p.summary.avgResponseMinutes > 0);
    assert.notEqual(formatAvgResponse(p.summary.avgResponseMinutes), '—');
  });

  let createdId = '';
  await check('adding an enquiry puts it in the New column and updates monthly count', async () => {
    const before = await leads.pipeline(i);
    const created = await leads.create(i, {
      studentName: 'Rohan Verma',
      phone: '+91 98765 43210',
      classInterested: '10',
      subjectInterest: 'Science',
      source: 'instagram',
      assignedTo: SEED.ownerId,
      nextFollowupAt: `${addDays(today, 1)}T12:00:00.000Z`,
      nextFollowupNote: 'Call parent about evening batch',
    });
    createdId = created.id;
    assert.equal(created.stage, 'new');
    assert.equal(created.phone, '9876543210');

    const after = await leads.pipeline(i);
    assert.equal(after.summary.thisMonthEnquiries, before.summary.thisMonthEnquiries + 1);
    const row = after.items.find((x) => x.lead.id === created.id);
    assert.ok(row);
    assert.equal(row.segment, 'new');
    assert.ok(leadRowSubtitle(row.lead, row.lastFollowupAt, row.lastFollowupChannel).includes('Class 10 · Science'));
  });

  await check('logging a follow-up today appears on the lead timeline and logs stage transition', async () => {
    await leads.addFollowup(i, {
      leadId: createdId,
      channel: 'call',
      outcome: 'interested',
      summary: 'Spoke with mother; wants Class 10 Science batch.',
      nextFollowupAt: `${today}T12:00:00.000Z`,
      nextFollowupNote: 'Schedule Maths demo',
    });

    const detail = await leads.detail(i, createdId);
    assert.equal(detail.lead.stage, 'contacted');
    assert.equal(detail.segment, 'following_up');
    assert.equal(detail.followups.length, 1);
    assert.equal(detail.followups[0].followup.channel, 'call');
    assert.equal(detail.followups[0].doneByName, 'Rahul Sharma');
    assert.ok(detail.followups[0].followup.followupAt.startsWith(today));

    // Stage changes are logged with who and when
    assert.ok(detail.stageChanges.some((c) => c.fromStage === 'new' && c.toStage === 'contacted' && c.actorName === 'Rahul Sharma'));
  });

  await check('every stage change is logged with who and when', async () => {
    await leads.moveStage(i, createdId, 'demo_scheduled');
    const detail = await leads.detail(i, createdId);
    assert.equal(detail.segment, 'demo_booked');
    const latest = detail.stageChanges[0];
    assert.equal(latest.fromStage, 'contacted');
    assert.equal(latest.toStage, 'demo_scheduled');
    assert.equal(latest.actorName, 'Rahul Sharma');
    assert.ok(latest.changedAt.length > 0);
  });

  await check('next action overdue state detects past dates in amber, not today or future', async () => {
    assert.equal(isNextActionOverdue(`${addDays(today, -1)}T12:00:00.000Z`, 'contacted', today), true);
    assert.equal(isNextActionOverdue(`${today}T12:00:00.000Z`, 'contacted', today), false);
    assert.equal(isNextActionOverdue(`${addDays(today, 1)}T12:00:00.000Z`, 'contacted', today), false);
    assert.equal(isNextActionOverdue(`${addDays(today, -2)}T12:00:00.000Z`, 'enrolled', today), false);
    assert.equal(isNextActionOverdue(`${addDays(today, -2)}T12:00:00.000Z`, 'lost', today), false);
  });

  await check('no lead can be deleted; lost leads require a reason and archive cleanly', async () => {
    await assert.rejects(() => leads.remove(i, createdId), /cannot be deleted/i);
    await assert.rejects(() => leads.moveStage(i, createdId, 'lost', '   '), /why this lead was lost/i);

    const archived = await leads.create(i, {
      studentName: 'Test Archive',
      phone: '9876500011',
      classInterested: '9',
      source: 'walk_in',
    });
    await leads.moveStage(i, archived.id, 'lost', 'Moved to another city');
    const detail = await leads.detail(i, archived.id);
    assert.equal(detail.segment, 'lost');
    assert.equal(detail.lead.lostReason, 'Moved to another city');
  });

  await check('single repo convert writes lead, student, guardian, batch membership and fee plan together', async () => {
    // Save a real fee plan for Class 10-A so conversion picks up the batch plan automatically
    await fees.savePlan(i, {
      batchId: SEED.batchId,
      batchIds: [SEED.batchId],
      name: 'Class 10-A Term Plan',
      frequency: 'term',
      totalAmount: 12000,
      schedule: [
        { id: 'i1', label: 'Term 1', amount: 4000, dueDate: addDays(today, 5) },
        { id: 'i2', label: 'Term 2', amount: 4000, dueDate: addDays(today, 125) },
        { id: 'i3', label: 'Term 3', amount: 4000, dueDate: addDays(today, 245) },
      ],
      discounts: [],
    });

    const result = await leads.convert(i, {
      leadId: createdId,
      studentName: 'Rohan Verma',
      phone: '9876543210',
      guardianName: 'Sunita Verma',
      guardianPhone: '9876543210',
      batchId: SEED.batchId,
      rollNumber: 30,
      firstDueDate: today,
    });

    assert.equal(result.lead.stage, 'enrolled');
    assert.equal(result.lead.convertedStudentId, result.student.id);
    assert.equal(result.enrollment.batchId, SEED.batchId);
    assert.equal(result.enrollment.rollNumber, 30);
    assert.ok(result.studentFee && result.studentFee.netAmount === 12000);

    // Appears in real students list, batch roster, guardians & fees
    const allStudents = await students.list(i, { limit: 200 });
    assert.ok(allStudents.items.some((s) => s.id === result.student.id && s.fullName === 'Rohan Verma'));

    const roster = await batches.listRoster(i, SEED.batchId);
    assert.ok(roster.some((r) => r.studentId === result.student.id && r.rollNumber === 30));

    const linkedGuardians = await guardians.listForStudent(i, result.student.id);
    assert.equal(linkedGuardians.length, 1);
    assert.equal(linkedGuardians[0].fullName, 'Sunita Verma');

    const statement = await fees.studentStatement(i, result.student.id);
    assert.ok(statement);
    assert.equal(statement.net, 12000);
    assert.equal(statement.installments.length, 3);

    // Cannot convert the same lead twice
    await assert.rejects(() => leads.convert(i, {
      leadId: createdId,
      studentName: 'Rohan Verma',
      phone: '9876543210',
      batchId: SEED.batchId,
    }), /already converted/i);
  });

  await check('conversion percentage on the list matches underlying stages after conversion', async () => {
    const p = await leads.pipeline(i);
    const rawLeads = db.leads.all(i);
    const enrolled = rawLeads.filter((l) => l.stage === 'enrolled').length;
    const expectedPct = Math.round((enrolled / rawLeads.length) * 100);
    assert.equal(p.summary.totalLeads, rawLeads.length);
    assert.equal(p.summary.convertedCount, enrolled);
    assert.equal(p.summary.conversionPercent, expectedPct);

    const recomputed = computeAdmissionsSummary(rawLeads, db.followups.all(i), today);
    assert.deepEqual(p.summary, recomputed);
  });

  await check('tenant isolation, role guard and snapshot round-trip', async () => {
    await assert.rejects(() => leads.detail('other-institute', createdId));
    await assert.rejects(() => leads.pipeline('other-institute'));

    // Student cannot create or convert leads
    db.session.userId = SEED.studentIds[0];
    await assert.rejects(() => leads.create(i, { studentName: 'Blocked', phone: '9876543211' }), /staff/i);
    db.session.userId = SEED.ownerId;

    const snap = capture(db);
    const db2 = createDb();
    assert.equal(restore(db2, snap), true);
    const p2 = await leadRepo(db2).pipeline(i);
    assert.equal(p2.items.length, 10);
  });

  console.log(`\n${passed} checks passed`);
}

main().catch((e: unknown) => {
  console.error(e);
  process.exitCode = 1;
});
