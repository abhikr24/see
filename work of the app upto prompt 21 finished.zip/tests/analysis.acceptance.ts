import assert from 'node:assert/strict';

import { createDb } from '../src/backends/memory/db';
import { seed, SEED } from '../src/backends/memory/seed';
import { resultRepo } from '../src/backends/memory/coursework';
import { buildAnalysisCsv } from '../src/features/exams/analysis-csv';
import { rankWithTies } from '../src/core/contracts/exam-analysis';

let passed = 0;
const check = (name: string, fn: () => void | Promise<void>) =>
  Promise.resolve(fn()).then(() => {
    passed += 1;
    console.log(`  ✓ ${name}`);
  });

const INSTITUTE = SEED.instituteId;
const EXAM_UNIT_TEST_3 = '00000000-0000-4000-8000-000000000050';
const EXAM_WEEKLY_4 = '00000000-0000-4000-8000-000000000054';
const EXAM_HALF_YEARLY = '00000000-0000-4000-8000-000000000056';
const OTHER_INSTITUTE = '00000000-0000-4000-8000-999999999999';

async function main() {
  const db = createDb();
  seed(db);
  const results = resultRepo(db);

  console.log('Exam analysis acceptance');

  await check('the analysis figures match the marks entered exactly', async () => {
    const analysis = await results.analysis(INSTITUTE, EXAM_UNIT_TEST_3);
    // Unit Test 3: marks 92, 85, 78, 88, 74, 81, 69, 93, 77, 84, 61, 54 out of 100.
    assert.equal(analysis.scoredCount, 12);
    assert.equal(analysis.totalStudents, 12);
    assert.equal(analysis.averagePct, 78);
    assert.equal(analysis.highestMarks, 93);
    assert.equal(analysis.lowestMarks, 54);
    assert.equal(analysis.passRatePct, 100);
    assert.equal(analysis.maxMarks, 100);
    assert.equal(analysis.students.length, 12);
    const top = analysis.topStudents[0];
    assert.equal(top.fullName, 'Diya Patel');
    assert.equal(top.marksObtained, 93);
    assert.equal(top.rank, 1);
  });

  await check('a student with the same marks as another shares the rank', async () => {
    const analysis = await results.analysis(INSTITUTE, EXAM_WEEKLY_4);
    const ritesh = analysis.students.find((s) => s.fullName === 'Ritesh Mehta');
    const zoya = analysis.students.find((s) => s.fullName === 'Zoya Ahmed');
    assert.equal(ritesh?.marksObtained, 27);
    assert.equal(zoya?.marksObtained, 27);
    assert.equal(ritesh?.rank, zoya?.rank, 'equal marks share a rank');
    const manav = analysis.students.find((s) => s.fullName === 'Manav Sethi');
    assert.equal(manav?.marksObtained, 25);
    assert.equal(manav?.rank, 8, 'the next rank skips (1, 2, 2, 4)');
    assert.deepEqual(rankWithTies([10, 10, 8]), [1, 1, 3]);
  });

  await check('the trend and the change against the previous exam are the class averages', async () => {
    const analysis = await results.analysis(INSTITUTE, EXAM_HALF_YEARLY);
    assert.equal(analysis.trend.length, 6, 'six bars');
    const current = analysis.trend[analysis.trend.length - 1];
    assert.equal(current.examId, EXAM_HALF_YEARLY);
    assert.equal(current.isCurrent, true);
    assert.equal(analysis.previousExamName, 'Weekly Test 5');
    assert.equal(analysis.previousAveragePct, 65.2);
    assert.equal(analysis.deltaPct, 14.3);
    const unitTest3 = await results.analysis(INSTITUTE, EXAM_UNIT_TEST_3);
    assert.equal(unitTest3.previousExamName, 'Unit Test 2');
    assert.equal(unitTest3.deltaPct, 9.3);
  });

  await check('the subject-wise average covers the four subjects of the batch', async () => {
    const analysis = await results.analysis(INSTITUTE, EXAM_HALF_YEARLY);
    assert.equal(analysis.subjectAverages.length, 4);
    const names = analysis.subjectAverages.map((s) => s.subjectName);
    assert.deepEqual(names, ['Mathematics', 'Physics', 'Chemistry', 'English']);
    const maths = analysis.subjectAverages[0];
    assert.equal(maths.students, 12);
    assert.equal(maths.maxMarks, 80);
    assert.ok(Math.abs(maths.averagePct - 82.5) < 0.11, `maths average was ${maths.averagePct}`);
    const unitTest3 = await results.analysis(INSTITUTE, EXAM_UNIT_TEST_3);
    assert.equal(unitTest3.subjectAverages.length, 4, 'every exam of the batch shows four subjects');
    assert.equal(unitTest3.subjectAverages[0].subjectName, 'Mathematics');
    assert.equal(unitTest3.subjectAverages[0].averagePct, 78);
  });

  await check('the distribution counts every scored student once', async () => {
    const analysis = await results.analysis(INSTITUTE, EXAM_UNIT_TEST_3);
    assert.equal(analysis.distribution.length, 5);
    assert.deepEqual(analysis.distribution.map((b) => b.label), ['0–35', '36–50', '51–70', '71–85', '86–100']);
    const total = analysis.distribution.reduce((sum, bucket) => sum + bucket.count, 0);
    assert.equal(total, 12);
    assert.equal(analysis.distribution[2].count + analysis.distribution[3].count + analysis.distribution[4].count, 12);
  });

  await check('the student and the owner read the same numbers from one repo method', async () => {
    const owner = await results.analysis(INSTITUTE, EXAM_HALF_YEARLY);
    // A student caller reads the same exam and gets the same figures.
    db.session.userId = SEED.studentIds[0];
    const student = await results.analysis(INSTITUTE, EXAM_HALF_YEARLY);
    assert.equal(student.averagePct, owner.averagePct);
    assert.equal(student.highestMarks, owner.highestMarks);
    assert.equal(student.lowestMarks, owner.lowestMarks);
    assert.equal(student.passRatePct, owner.passRatePct);
    assert.equal(student.deltaPct, owner.deltaPct);
    const aarav = student.students.find((s) => s.fullName === 'Aarav Sharma');
    assert.equal(aarav?.rank, 3);
    assert.equal(aarav?.marksObtained, 284);
  });

  await check('the CSV matches what the screen shows', async () => {
    const analysis = await results.analysis(INSTITUTE, EXAM_UNIT_TEST_3);
    const csv = buildAnalysisCsv(analysis);
    assert.ok(csv.startsWith('\uFEFF'), 'UTF-8 BOM');
    assert.ok(csv.includes('\r\n'), 'CRLF line endings');
    assert.ok(csv.includes(`Class average,${analysis.averagePct?.toFixed(1)}%`));
    assert.ok(csv.includes(`Highest,${analysis.highestMarks} of ${analysis.maxMarks}`));
    assert.ok(csv.includes(`Lowest,${analysis.lowestMarks} of ${analysis.maxMarks}`));
    assert.ok(csv.includes(`Pass rate,${analysis.passRatePct?.toFixed(1)}%`));
    assert.ok(csv.includes(`Change vs previous,${analysis.deltaPct?.toFixed(1)} pts`));
    for (const student of analysis.students) {
      assert.ok(csv.includes(`${student.rank},${student.rollNumber},${student.fullName},${student.marksObtained},${student.maxMarks}`));
    }
    for (const bucket of analysis.distribution) {
      assert.ok(csv.includes(`${bucket.label},${bucket.count}`));
    }
    for (const subject of analysis.subjectAverages) {
      assert.ok(csv.includes(`${subject.subjectName},${subject.averagePct.toFixed(1)},${subject.students},${subject.maxMarks}`));
    }
  });

  await check('another institute cannot read the analysis', async () => {
    await assert.rejects(() => results.analysis(OTHER_INSTITUTE, EXAM_UNIT_TEST_3));
  });

  console.log(`\n${passed} checks passed`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
