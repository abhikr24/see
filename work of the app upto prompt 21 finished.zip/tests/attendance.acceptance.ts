import assert from 'node:assert/strict';
import { createDb } from '../src/backends/memory/db';
import { seed, SEED } from '../src/backends/memory/seed';
import { ensureGuardians } from '../src/backends/memory/seed-guardians';
import { attendanceRepo } from '../src/backends/memory/academics';
import type { Backend } from '../src/core/contracts/ports';
import { commitSheet, savedMessage } from '../src/features/attendance/commit';
import {
  NEXT,
  addDaysIso,
  changedCount,
  countMarks,
  latestDateForWeekday,
  markAllAfter,
  marksFrom,
  sheetInput,
  todayIso,
  upsertDaySheet,
  expectedSheet,
} from '../src/features/attendance/model';

let passed = 0;
const check = (name: string, fn: () => void | Promise<void>) =>
  Promise.resolve(fn()).then(() => {
    passed += 1;
    console.log(`  ✓ ${name}`);
  });

async function main() {
  const db = createDb();
  seed(db);
  const attendance = attendanceRepo(db);
  const backend = { name: 'memory', attendance } as unknown as Backend;
  const i = SEED.instituteId;
  const batchId = SEED.batchId;
  const today = todayIso();
  const fresh = addDaysIso(today, -40); // before the 30 seeded days

  console.log('Take Attendance acceptance');

  await check('today opens the saved seed sheet in edit mode, 12 students in roll order', async () => {
    const roll = await attendance.openRoll(i, { batchId, date: today });
    assert.ok(roll.existing, 'seeded sheet for today exists');
    assert.equal(roll.students.length, 12);
    assert.deepEqual(roll.students.map((s) => s.rollNumber), [14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25]);
    assert.equal(roll.students[0].fullName, 'Aarav Sharma');
    assert.equal(roll.students[0].parentName, 'Anita Sharma');
    assert.ok(roll.subjectName, 'subject resolved from the timetable');
    assert.equal(roll.alertsEnabled, true);
  });

  await check('a date with no sheet opens fresh, everyone present', async () => {
    const roll = await attendance.openRoll(i, { batchId, date: fresh });
    assert.equal(roll.existing, null);
    const counts = countMarks(roll.students, marksFrom(roll.students, null));
    assert.deepEqual(counts, { present: 12, late: 0, absent: 0, total: 12 });
  });

  await check('tap cycles present → absent → late → present', () => {
    assert.equal(NEXT.present, 'absent');
    assert.equal(NEXT.absent, 'late');
    assert.equal(NEXT.late, 'present');
  });

  let sessionId = '';
  const absentIds: string[] = [];
  await check('one save stores the sheet and notifies each absent parent once', async () => {
    const roll = await attendance.openRoll(i, { batchId, date: fresh });
    const marks = marksFrom(roll.students, null);
    [1, 4, 9].forEach((n) => {
      marks[roll.students[n].studentId] = 'absent';
      absentIds.push(roll.students[n].studentId);
    });
    marks[roll.students[6].studentId] = 'late';
    const before = db.notifications.all(i, { type: 'attendance_absent' }).length;
    const result = await commitSheet(backend, i, sheetInput(roll, marks));
    sessionId = result.sheet.session.id;
    assert.equal(result.sheet.records.length, 12);
    assert.deepEqual(result.alerts, { sent: 3, alreadySent: 0, unreachable: 0, disabled: false });
    const rows = db.notifications.all(i, { type: 'attendance_absent' });
    assert.equal(rows.length - before, 3);
    for (const studentId of absentIds) {
      const row = rows.find((n) => n.data.studentId === studentId && n.data.sessionId === sessionId);
      assert.ok(row, 'a notification row for the absent student');
      const parentMembership = db.memberships.all(i, { userId: row!.userId, role: 'parent' });
      assert.equal(parentMembership.length, 1, 'addressed to the parent login');
    }
    assert.match(savedMessage(result, false), /3 parents notified/);
  });

  await check('reopening the same date shows the saved states, not a fresh sheet', async () => {
    const roll = await attendance.openRoll(i, { batchId, date: fresh });
    assert.ok(roll.existing);
    const counts = countMarks(roll.students, marksFrom(roll.students, roll.existing));
    assert.deepEqual(counts, { present: 8, late: 1, absent: 3, total: 12 });
  });

  await check('re-saving never double-notifies; a newly absent student is notified', async () => {
    const roll = await attendance.openRoll(i, { batchId, date: fresh });
    const marks = marksFrom(roll.students, roll.existing);
    const again = await commitSheet(backend, i, sheetInput(roll, marks));
    assert.equal(again.alerts?.sent, 0);
    assert.equal(again.alerts?.alreadySent, 3);
    marks[roll.students[11].studentId] = 'absent';
    assert.equal(changedCount(marks, marksFrom(roll.students, roll.existing)), 1);
    const update = await commitSheet(backend, i, sheetInput(roll, marks));
    assert.equal(update.alerts?.sent, 1);
    assert.equal(update.sheet.session.id, sessionId, 'same sheet updated, not duplicated');
  });

  await check('the alert setting gates notifications', async () => {
    const inst = db.institutes.get(i, i);
    db.institutes.put({ ...inst, settings: { ...inst.settings, features: { attendanceAlerts: false } } });
    const roll = await attendance.openRoll(i, { batchId, date: addDaysIso(today, -41) });
    assert.equal(roll.alertsEnabled, false);
    const marks = marksFrom(roll.students, null);
    marks[roll.students[0].studentId] = 'absent';
    const before = db.notifications.all(i, { type: 'attendance_absent' }).length;
    const result = await commitSheet(backend, i, sheetInput(roll, marks));
    assert.equal(result.alerts?.disabled, true);
    assert.equal(db.notifications.all(i, { type: 'attendance_absent' }).length, before);
    db.institutes.put(inst);
  });

  await check('the timetable tab source (listSheets) and the student profile source (summary) both see it', async () => {
    const sheets = await attendance.listSheets(i, { date: fresh });
    assert.equal(sheets.length, 1);
    assert.equal(sheets[0].records.filter((r) => r.status === 'absent').length, 4);
    const summary = await attendance.summary(i, { studentId: absentIds[0], from: fresh, to: fresh });
    assert.deepEqual([summary.total, summary.absent], [1, 1]);
  });

  await check('optimistic day-list replaces the same batch + period', async () => {
    const roll = await attendance.openRoll(i, { batchId, date: fresh });
    const list = await attendance.listSheets(i, { date: fresh });
    const next = upsertDaySheet(list, expectedSheet(roll, marksFrom(roll.students, null), i));
    assert.equal(next.length, 1);
    assert.equal(next[0].records.every((r) => r.status === 'present'), true);
  });

  await check('mark all after this carries a status down the roll', async () => {
    const roll = await attendance.openRoll(i, { batchId, date: fresh });
    const base = marksFrom(roll.students, null);
    const { marks, changed } = markAllAfter(roll.students, base, roll.students[8].studentId, 'absent');
    assert.equal(changed, 3);
    assert.equal(countMarks(roll.students, marks).absent, 3);
  });

  await check('timetable dates are never in the future', () => {
    for (let d = 0; d < 7; d += 1) assert.ok(latestDateForWeekday(d) <= today);
    assert.equal(latestDateForWeekday(new Date(`${today}T00:00:00Z`).getUTCDay()), today);
  });

  await check('future dates are rejected; other institutes are isolated', async () => {
    await assert.rejects(attendance.saveSheet(i, { batchId, date: addDaysIso(today, 1), records: [] }));
    await assert.rejects(attendance.openRoll('00000000-0000-4000-8000-999999999999', { batchId, date: today }));
  });

  await check('an older snapshot without parents is topped up', () => {
    const old = createDb();
    seed(old);
    for (const link of old.parentLinks.all(i)) old.parentLinks.remove(i, link.id);
    ensureGuardians(old);
    assert.equal(old.parentLinks.all(i).length, 12);
  });

  console.log(`\n${passed} checks passed`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
