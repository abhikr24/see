const { chromium } = require('@playwright/test');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

/**
 * Browser acceptance for Take Attendance. Build first:
 *   EXPO_PUBLIC_BACKEND=memory npx expo export --platform web
 *   node tests/attendance.browser.cjs
 * Walks: timetable row → Take Attendance (prefilled) → mark → save →
 * timetable Attendance tab shows it → offline save queues → reconnect syncs.
 */
const root = path.join(process.cwd(), 'dist');
const types = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.ttf': 'font/ttf', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  let file = path.join(root, decodeURIComponent(req.url.split('?')[0]));
  if (!file.startsWith(root)) { res.writeHead(403).end(); return; }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(root, 'index.html');
  res.setHeader('Content-Type', types[path.extname(file)] || 'application/octet-stream');
  fs.createReadStream(file).pipe(res);
}).listen(8124);

const BASE = 'http://localhost:8124';
const shots = process.env.SHOTS_DIR;
const shot = async (page, name) => { if (shots) await page.screenshot({ path: path.join(shots, `${name}.png`) }); };

async function signIn(page) {
  await page.goto(`${BASE}/`);
  const skip = page.getByText('Skip', { exact: true });
  await skip.waitFor({ state: 'visible', timeout: 30000 }).catch(() => {});
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.locator('input:not([type="password"])').first().fill('owner@sunrise.test');
  await page.locator('input[type="password"]').first().fill('demo1234');
  await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  await page.getByText('Enter code', { exact: true }).waitFor({ state: 'visible', timeout: 30000 });
  const box = page.locator('input:visible').first();
  await box.click();
  await page.keyboard.type('123456', { delay: 60 });
  await page.getByRole('button', { name: 'Verify', exact: true }).click();
  await page.locator('[role="tab"]').first().waitFor({ state: 'visible', timeout: 30000 });
}

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const context = await browser.newContext({ viewport: { width: 400, height: 860 } });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  try {
    await signIn(page);
    console.log('PASS: signed in as the seeded owner');

    await page.getByText('Timetable', { exact: true }).first().click();
    await page.getByText('Drag a period to reorder', { exact: false }).waitFor({ timeout: 20000 });
    const takeButton = page.getByRole('button', { name: /attendance for Class 10-A/ }).first();
    await takeButton.click();
    await page.getByText('Editing saved sheet').waitFor({ timeout: 20000 });
    const url = new URL(page.url());
    assert.ok(url.searchParams.get('date'), 'date is prefilled');
    assert.match(url.pathname, /attendance\//);
    console.log(`PASS: timetable row opens Take Attendance prefilled (${url.pathname}${url.search})`);
    await shot(page, '1-edit-mode');

    const save = page.getByRole('button', { name: /Update attendance/ });
    assert.equal(await save.isDisabled(), true, 'save disabled until something changes');
    const start = Date.now();
    for (const name of ['Ishita Bose', 'Kabir Singh', 'Ritesh Mehta']) {
      await page.getByRole('button', { name: new RegExp(`^${name}, roll`) }).click();
    }
    await page.getByRole('button', { name: /^Zoya Ahmed, roll/ }).click();
    await page.getByRole('button', { name: /^Zoya Ahmed, roll/ }).click();
    assert.equal(await save.isDisabled(), false);
    await shot(page, '2-marked');
    await save.click();
    await page.getByText(/Attendance updated/).waitFor({ timeout: 15000 });
    console.log(`PASS: marked and saved in ${Date.now() - start} ms (scripted)`);
    await shot(page, '3-saved');

    await page.getByRole('button', { name: 'Back' }).click();
    await page.getByText('Attendance', { exact: true }).first().click();
    await page.getByText(/absent/).first().waitFor({ timeout: 15000 });
    const card = await page.getByRole('button', { name: /Class 10-A .*present/ }).first().getAttribute('aria-label');
    assert.match(card, /of 12 present/);
    console.log(`PASS: timetable Attendance tab shows it immediately (${card})`);
    await shot(page, '4-timetable-tab');

    // Offline: queue, banner, then sync on reconnect.
    await page.getByRole('button', { name: /Class 10-A .*present/ }).first().click();
    await page.getByText('Editing saved sheet').waitFor({ timeout: 20000 });
    await context.setOffline(true);
    await page.getByText(/You are offline/).waitFor({ timeout: 10000 });
    await page.getByRole('button', { name: /^Sara Khan, roll/ }).click();
    await page.getByRole('button', { name: /Update attendance/ }).click();
    await page.getByText(/Saved on this phone · will sync/).waitFor({ timeout: 10000 });
    console.log('PASS: offline save queues with a calm banner');
    await shot(page, '5-offline');
    await context.setOffline(false);
    await page.getByText(/Queued attendance synced/).waitFor({ timeout: 40000 });
    console.log('PASS: queue flushed on reconnect');

    assert.deepEqual(errors, []);
    console.log('PASS: no runtime errors');
  } catch (error) {
    await shot(page, 'failure');
    console.error(error);
    process.exitCode = 1;
  } finally {
    await browser.close();
    server.close();
  }
})();
