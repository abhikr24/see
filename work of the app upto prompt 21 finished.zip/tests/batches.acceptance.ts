import assert from 'node:assert/strict';
import { createDb } from '../src/backends/memory/db';
import { seed, SEED } from '../src/backends/memory/seed';
import { batchRepo, attendanceRepo } from '../src/backends/memory/academics';
import { validateBatch } from '../src/core/contracts/batch-validation';

async function main() {
  const db = createDb(); seed(db);
  const batches = batchRepo(db), attendance = attendanceRepo(db);
  const i = SEED.instituteId;
  const summaries = await batches.listSummaries(i);
  assert.equal(summaries.length, 3);
  assert.equal(summaries.find((b) => b.id === SEED.batchId)?.studentCount, 12);
  for (const b of summaries) {
    assert.equal(b.attendancePct, (await attendance.summary(i, { batchId: b.id })).percent);
    for (const s of await batches.listRoster(i, b.id)) {
      assert.equal(s.attendancePct, (await attendance.summary(i, { batchId: b.id, studentId: s.studentId })).percent);
    }
  }
  console.log('PASS: Batch and roster percentages match attendance register (30 students).');
  const input = { name: 'Acceptance test batch', academicYear: '2026-27', days: [1,3,5], startsAt: '16:00', endsAt: '17:00', feeAmount: 0 };
  const created = await batches.create(i, input);
  assert.ok((await batches.list(i)).items.some((b) => b.id === created.id));
  assert.ok((await batches.listSummaries(i)).some((b) => b.id === created.id && b.studentCount === 0));
  assert.equal(db.timetables.all(i, { batchId: created.id }).length, 3);
  console.log('PASS: Creating a batch populates list and student-form source, with timetable.');
  for (const invalid of [{ ...input, days: [] }, { ...input, feeAmount: -1 }, { ...input, endsAt: '15:00' }, { ...input, startsAt: '25:00' }, { ...input, capacity: -1 }, { ...input, feeAmount: NaN }]) {
    assert.throws(() => validateBatch(invalid));
    await assert.rejects(() => batches.create(i, invalid));
  }
  console.log('PASS: Form and repository reject invalid days, times, fees and capacity.');
  const roster = await batches.listRoster(i, SEED.batchId);
  await attendance.saveSheet(i, { batchId: SEED.batchId, date: new Date().toISOString().slice(0,10),
    records: roster.map((s, n) => ({ studentId: s.studentId, status: n === 0 ? 'absent' : n === 1 ? 'late' : 'present' })) });
  for (const s of await batches.listRoster(i, SEED.batchId)) {
    assert.equal(s.attendancePct, (await attendance.summary(i, { batchId: SEED.batchId, studentId: s.studentId })).percent);
  }
  console.log('PASS: Attendance edits recalculate roster percentages; late counts as present.');
  const before = (await attendance.listRecords(i, { batchId: SEED.batchId })).length;
  await batches.remove(i, SEED.batchId);
  assert.equal((await batches.get(i, SEED.batchId)).status, 'archived');
  assert.equal((await attendance.listRecords(i, { batchId: SEED.batchId })).length, before);
  assert.equal((await batches.listRoster(i, SEED.batchId)).length, 12);
  assert.equal((await batches.listEnrollments(i, SEED.batchId)).length, 12);
  assert.ok(!(await batches.listSummaries(i)).filter((b) => b.status !== 'archived').some((b) => b.id === SEED.batchId));
  console.log('PASS: Archiving hides the active card and retains student, attendance and enrollment history.');
  assert.equal((await batches.listSummaries('other-tenant')).length, 0);
  await assert.rejects(() => batches.listRoster('other-tenant', SEED.batchId));
  console.log('PASS: Tenant isolation.');
}
main().catch((e: unknown) => { console.error(e); process.exitCode = 1; });
