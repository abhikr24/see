const { chromium, expect } = require('@playwright/test');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

/**
 * Browser acceptance for the batches flow.
 *
 * The app is served from the exported bundle in `dist/`, so build it against
 * the seeded reference backend first:
 *
 *   EXPO_PUBLIC_BACKEND=memory npx expo export --platform web
 *   node tests/batches.browser.cjs
 *
 * The script signs in as the seeded owner (any 6-digit code works with the
 * reference backend) and then walks the real owner routes — /batches,
 * /batches/new and /students/new — through the shared owner shell.
 */
const root = path.join(process.cwd(), 'dist');
const types = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.ttf': 'font/ttf', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  let file = path.join(root, decodeURIComponent(req.url.split('?')[0]));
  if (!file.startsWith(root)) { res.writeHead(403).end(); return; }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(root, 'index.html');
  res.setHeader('Content-Type', types[path.extname(file)] || 'application/octet-stream');
  fs.createReadStream(file).pipe(res);
}).listen(8123);

const tab = (page, index) => page.locator('[role="tab"]').nth(index);
const BATCHES_TAB = 2;
const STUDENTS_TAB = 1;

async function signIn(page) {
  await page.goto('http://localhost:8123/');
  const skip = page.getByText('Skip', { exact: true });
  await skip.waitFor({ state: 'visible', timeout: 30000 }).catch(() => {});
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.locator('input:not([type="password"])').first().fill('owner@sunrise.test');
  await page.locator('input[type="password"]').first().fill('demo1234');
  await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  await page.getByText('Enter code', { exact: true }).waitFor({ state: 'visible', timeout: 30000 });
  const box = page.locator('input:visible').first();
  await box.waitFor({ state: 'visible', timeout: 30000 });
  await box.click();
  await page.keyboard.type('123456', { delay: 60 });
  await page.getByRole('button', { name: 'Verify', exact: true }).click();
  await tab(page, 0).waitFor({ state: 'visible', timeout: 30000 });
}

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 1080 } });
    const errors = [];
    page.on('pageerror', (e) => errors.push(e.message));

    await signIn(page);
    console.log('PASS: Signed in as the seeded owner.');

    await tab(page, BATCHES_TAB).click();
    await expect(page.getByRole('button', { name: 'Open Class 10-A', exact: true })).toBeVisible({ timeout: 30000 });
    fs.mkdirSync('.agon-env', { recursive: true });
    await page.screenshot({ path: '.agon-env/batches-desktop.png', fullPage: true });

    // The batches screen must wear the same chrome as every other owner screen.
    await tab(page, STUDENTS_TAB).click();
    await page.screenshot({ path: '.agon-env/students-desktop.png', fullPage: true });
    await tab(page, BATCHES_TAB).click();
    await expect(page.getByRole('button', { name: 'Open Class 10-A', exact: true })).toBeVisible();
    console.log('PASS: Batches renders inside the shared owner shell.');

    await page.getByLabel('Search batches').fill('does not exist');
    await expect(page.getByText('No batches match your search.')).toBeVisible();
    await page.getByLabel('Clear search').click();
    await page.getByRole('button', { name: 'Create batch', exact: true }).click();
    await page.getByPlaceholder('e.g. Class 10-B').fill('Class 10-B');
    await page.getByText('Choose a subject', { exact: true }).click();
    await page.getByText('Mathematics', { exact: true }).click();
    await page.getByText('Assign a teacher', { exact: true }).click();
    await page.getByText('Rohit Verma', { exact: true }).click();
    await page.getByPlaceholder('0', { exact: true }).fill('1500');
    await page.getByPlaceholder('e.g. 30').fill('25');
    await page.getByRole('button', { name: 'Create batch', exact: true }).click();
    await expect(page.getByRole('button', { name: 'Open Class 10-B', exact: true })).toBeVisible();
    console.log('PASS: Create form -> active batch card.');

    // The new batch must show up in the student form's batch chips.
    await page.getByRole('button', { name: 'Open Class 10-B', exact: true }).click();
    await page.getByText('+ Add student', { exact: true }).click();
    await expect(page.getByText('Class 10-B', { exact: true })).toBeVisible();
    await page.goBack();
    console.log('PASS: Created batch appears in student form chips.');

    await page.getByText('All batches', { exact: true }).click();
    await page.getByRole('button', { name: 'Open Class 10-A', exact: true }).click();
    await expect(page.getByText('Student roster')).toBeVisible();
    await expect(page.getByText('Aarav Sharma', { exact: true })).toBeVisible();
    await page.getByRole('button', { name: 'Take attendance', exact: true }).last().click();
    await expect(page.getByRole('button', { name: 'Save attendance', exact: true })).toBeVisible();
    await page.getByLabel('Aarav Sharma: absent', { exact: true }).click();
    await page.getByRole('button', { name: 'Save attendance', exact: true }).click();
    await expect(page.getByText('Save attendance', { exact: true })).not.toBeVisible();
    console.log('PASS: Attendance marking saves without a runtime error.');
    await page.getByText('Assign homework', { exact: true }).click();
    await page.getByPlaceholder('e.g. Practice exercise 4.2').fill('Revision exercise');
    await page.getByPlaceholder('What should your students know?').fill('Complete questions 1–5.');
    await page.getByRole('button', { name: 'Assign homework', exact: true }).click();
    await page.getByText('Content', { exact: true }).click();
    await expect(page.getByText('Revision exercise', { exact: true })).toBeVisible();
    console.log('PASS: Homework publishes into batch content.');

    await page.getByText('All batches', { exact: true }).click();
    await page.getByRole('button', { name: 'Open Class 10-B', exact: true }).click();
    await page.getByText('Archive batch', { exact: true }).click();
    await page.getByRole('button', { name: 'Archive batch', exact: true }).click();
    await expect(page.getByRole('button', { name: 'Open Class 10-B', exact: true })).not.toBeVisible();
    await page.getByText('Archived batches', { exact: true }).click();
    await page.getByText('Class 10-B', { exact: true }).click();
    await expect(page.getByText('· Archived')).toBeVisible();
    console.log('PASS: Archive hides active card and preserves detail history.');

    await page.setViewportSize({ width: 390, height: 844 });
    await page.getByText('All batches', { exact: true }).click();
    await expect(page.getByRole('button', { name: 'Open Class 10-A', exact: true })).toBeVisible();
    await page.screenshot({ path: '.agon-env/batches-mobile.png', fullPage: true });
    assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth), false);
    assert.deepEqual(errors, []);
    console.log('PASS: Mobile layout has no horizontal overflow; no browser runtime errors.');
  } finally { await browser.close(); server.close(); }
})().catch((e) => { console.error(e); server.close(); process.exitCode = 1; });
