import assert from 'node:assert/strict';
import { createDb } from '../src/backends/memory/db';
import { seed, SEED } from '../src/backends/memory/seed';
import { batchRepo, subjectRepo } from '../src/backends/memory/academics';
import { examRepo, markRepo, resultRepo } from '../src/backends/memory/coursework';
import { notificationRepo } from '../src/backends/memory/communication';
import { progressPort } from '../src/backends/memory/progress';
import { addDays, todayIso } from '../src/backends/memory/store';
import { validateNewExam } from '../src/core/contracts/exam-validation';
import { computeExamStats, filterExams } from '../src/features/exams/model';
import { buildExamCsv, examCsvFilename } from '../src/features/exams/csv';

let passed = 0;
const check = (name: string, fn: () => void | Promise<void>) =>
  Promise.resolve(fn()).then(() => {
    passed += 1;
    console.log(`  ✓ ${name}`);
  });

async function main() {
  const db = createDb();
  seed(db);
  const i = SEED.instituteId;
  const exams = examRepo(db);
  const marks = markRepo(db);
  const results = resultRepo(db);
  const batches = batchRepo(db);
  const subjects = subjectRepo(db);
  const notifications = notificationRepo(db);
  const progress = progressPort(db);
  const today = todayIso();
  const mathId = (await subjects.list(i)).items.find((s) => s.name === 'Mathematics')!.id;

  console.log('Exams acceptance');

  await check('validation rejects bad name, max marks (<1 or >500), and dates > 30 days in past', async () => {
    const base = { name: 'Mid Term', batchId: SEED.batchId, subjectId: mathId, startsOn: today, totalMarks: 100 };
    for (const bad of [
      { ...base, name: 'A' },
      { ...base, name: '   ' },
      { ...base, totalMarks: 0 },
      { ...base, totalMarks: -10 },
      { ...base, totalMarks: 501 },
      { ...base, totalMarks: Number.NaN },
      { ...base, startsOn: addDays(today, -31) },
    ]) {
      assert.throws(() => validateNewExam(bad, today));
      await assert.rejects(() => exams.create(i, bad));
    }
    // Boundary values succeed
    validateNewExam({ ...base, name: 'UT', totalMarks: 1, startsOn: addDays(today, -30) }, today);
    validateNewExam({ ...base, name: 'Final', totalMarks: 500, startsOn: addDays(today, 14) }, today);
  });

  let created10AId = '';
  let partlyMarkId = '';
  await check('creating an exam appears in list with the correct batch student count and phase', async () => {
    db.session.userId = SEED.ownerId;
    const futureDate = addDays(today, 3);
    const created = await exams.create(i, {
      name: 'Algebra Quiz',
      batchId: SEED.batchId,
      subjectId: mathId,
      startsOn: futureDate,
      totalMarks: 50,
      status: 'scheduled',
    });
    created10AId = created.id;

    const list = await exams.list(i, { limit: 100 });
    assert.ok(list.items.some((e) => e.id === created.id));
    const summaries = await batches.listSummaries(i);
    const batch10A = summaries.find((b) => b.id === SEED.batchId)!;
    assert.equal(batch10A.studentCount, 12);

    const upcoming = filterExams(list.items, 'upcoming', today);
    const completed = filterExams(list.items, 'completed', today);
    assert.ok(upcoming.some((e) => e.id === created.id), 'future exam is upcoming');
    assert.ok(!completed.some((e) => e.id === created.id), 'future exam is not completed');
    assert.ok(completed.some((e) => e.name === 'Unit Test 3'), 'published Unit Test 3 is completed');
  });

  await check('entering marks computes stats and keeps exam unpublished (partly entered progress)', async () => {
    db.session.userId = SEED.ownerId;
    const roster = await batches.listRoster(i, SEED.batchId);
    const entries = roster.slice(0, 5).map((s, idx) => ({
      studentId: s.studentId,
      subjectId: mathId,
      marksObtained: 30 + idx * 5, // 30, 35, 40, 45, 50 out of 50 -> avg 80%, highest 50
      maxMarks: 50,
      isAbsent: false,
    }));
    const saved = await marks.saveMany(i, created10AId, entries);
    partlyMarkId = saved[0].id;
    await results.compute(i, created10AId);

    const exam = await exams.get(i, created10AId);
    assert.equal(exam.status, 'scheduled', 'entering marks does not publish');
    const examMarks = (await marks.list(i, { where: { examId: created10AId }, limit: 100 })).items;
    const stats = computeExamStats(exam, examMarks, 12);
    assert.equal(stats.entered, 5);
    assert.equal(stats.totalStudents, 12);
    assert.equal(stats.partlyEntered, true);
    assert.equal(stats.averagePct, 80);
    assert.equal(stats.highestMarks, 50);
    assert.equal(stats.marksState.tone, 'warning');
  });

  await check('marks stay hidden from students and parents until results are published', async () => {
    const aaravStudentId = SEED.studentIds[0]; // sid(14)
    const aaravUserId = SEED.studentIds[0]; // sid(14)
    const anitaParentUserId = '00000000-0000-4000-8000-000000000037';

    // Student caller
    db.session.userId = aaravUserId;
    const studentMarks = await marks.list(i, { where: { examId: created10AId }, limit: 100 });
    assert.equal(studentMarks.items.length, 0, 'student sees 0 marks for unpublished exam');
    await assert.rejects(() => marks.get(i, partlyMarkId));
    const studentResults = await results.listForStudent(i, aaravStudentId);
    assert.ok(!studentResults.some((r) => r.examId === created10AId), 'unpublished result hidden from student');
    assert.ok(studentResults.some((r) => r.examId !== created10AId), 'published Unit Test 3 remains visible');
    const s360 = await progress.getStudent360(i, aaravStudentId);
    assert.ok(!s360.results.some((r) => r.examId === created10AId), 'Student360 hides unpublished results');

    // Parent caller
    db.session.userId = anitaParentUserId;
    const parentMarks = await marks.list(i, { where: { examId: created10AId }, limit: 100 });
    assert.equal(parentMarks.items.length, 0, 'parent sees 0 marks for unpublished exam');
    const parentResults = await results.list(i, { where: { examId: created10AId } });
    assert.equal(parentResults.items.length, 0, 'parent sees 0 results for unpublished exam');
  });

  await check('publishing results notifies exactly the students and parents in that batch and reveals marks', async () => {
    db.session.userId = SEED.ownerId;
    const class9AId = '00000000-0000-4000-8000-000000000010';
    const class9AStudents = new Set(
      db.enrollments.all(i, { batchId: class9AId, status: 'active' }).map((e) => e.studentId),
    );
    const class10AStudentUserIds = new Set(SEED.studentIds); // sid(14..25)
    const class10AParentUserIds = new Set(
      SEED.studentIds.flatMap((studentId) =>
        db.parentLinks
          .all(i, { studentId })
          .map((l) => db.guardians.get(i, l.guardianId).membershipId!)
          .map((mid) => db.memberships.get(i, mid).userId),
      ),
    );
    assert.equal(class10AStudentUserIds.size, 12);
    assert.equal(class10AParentUserIds.size, 12);

    const beforeNotifs = db.notifications.all(i, { type: 'exam_published' }).length;
    const published = await exams.publish(i, created10AId);
    assert.equal(published.status, 'published');
    assert.ok(published.publishedAt);

    const examNotifs = db.notifications
      .all(i, { type: 'exam_published' })
      .filter((n) => n.data.examId === created10AId);
    assert.equal(examNotifs.length - beforeNotifs, 24, '12 students + 12 parents notified');

    const notifiedUsers = new Set(examNotifs.map((n) => n.userId));
    for (const uid of class10AStudentUserIds) assert.ok(notifiedUsers.has(uid), 'each 10-A student notified');
    for (const uid of class10AParentUserIds) assert.ok(notifiedUsers.has(uid), 'each 10-A parent notified');
    for (const sid9 of class9AStudents) assert.ok(!notifiedUsers.has(sid9), '9-A student not notified');

    // Idempotent re-publish does not duplicate notifications
    await exams.publish(i, created10AId);
    const afterRePublish = db.notifications
      .all(i, { type: 'exam_published' })
      .filter((n) => n.data.examId === created10AId);
    assert.equal(afterRePublish.length, 24);

    // Student inbox & marks are now visible
    db.session.userId = SEED.studentIds[0];
    const inbox = await notifications.list(i);
    assert.ok(inbox.items.some((n) => n.data.examId === created10AId));
    const visibleMarks = await marks.list(i, { where: { examId: created10AId }, limit: 100 });
    assert.equal(visibleMarks.items.length, 5);
    const visibleResults = await results.listForStudent(i, SEED.studentIds[0]);
    assert.ok(visibleResults.some((r) => r.examId === created10AId));
  });

  await check('study task reminder saves per student and CSV export handles quoting and formulas', async () => {
    db.session.userId = SEED.ownerId;
    const task = await progress.saveTask(i, {
      studentId: SEED.studentIds[0],
      subjectId: mathId,
      title: 'Prepare for Physics Quiz',
      dueOn: today,
      source: 'teacher',
      priority: 'medium',
      status: 'todo',
    });
    const list = await progress.listTasks(i, SEED.studentIds[0]);
    assert.ok(list.some((t) => t.id === task.id));

    const exam = await exams.get(i, created10AId);
    const csv = buildExamCsv(exam, 'Mathematics', 'Class 10-A', [
      { rollNumber: 14, fullName: '=SUM(A1)', status: 'Scored', marksObtained: 45, maxMarks: 50, percentage: 90, grade: 'A+' },
    ]);
    assert.ok(csv.startsWith('\uFEFF'));
    assert.ok(csv.includes("'=SUM(A1)"));
    assert.ok(csv.includes('\r\n'));
    assert.match(examCsvFilename(exam), /^exam-algebra-quiz-/);
  });

  await check('tenant isolation prevents cross-institute reads or publishes', async () => {
    db.session.userId = SEED.ownerId;
    const other = '00000000-0000-4000-8000-999999999999';
    await assert.rejects(() => exams.get(other, created10AId));
    await assert.rejects(() => exams.publish(other, created10AId));
    assert.equal((await exams.list(other)).items.length, 0);
  });

  console.log(`\n${passed} checks passed`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
