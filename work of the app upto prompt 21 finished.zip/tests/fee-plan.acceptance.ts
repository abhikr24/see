import assert from 'node:assert/strict';
import { createDb } from '../src/backends/memory/db';
import { seed, SEED } from '../src/backends/memory/seed';
import { batchRepo } from '../src/backends/memory/academics';
import * as D from '../src/backends/memory/defaults';
import { feeRepo, paymentRepo, receiptRepo } from '../src/backends/memory/finance';
import { capture, restore } from '../src/backends/memory/persist';
import { addDays, todayIso } from '../src/backends/memory/store';
import {
  addMonths,
  allocate,
  buildSchedule,
  rebalanceInstallments,
  scheduleTotal,
  validatePlan,
} from '../src/core/contracts/fee-plan';
import type { PlanDiscount, SavePlanInput } from '../src/core/contracts/models';
import {
  cleanMoney,
  draftFromView,
  isDirty,
  parseMoney,
  planReducer,
  problemsOf,
  toInput,
  type PlanFormState,
} from '../src/features/fees/plan-model';

let passed = 0;
const check = (name: string, fn: () => void | Promise<void>) =>
  Promise.resolve(fn()).then(() => {
    passed += 1;
    console.log(`  ✓ ${name}`);
  });

const sumOf = (xs: number[]) => Math.round(xs.reduce((a, b) => a + b, 0) * 100) / 100;

async function main() {
  const db = createDb();
  seed(db);
  const i = SEED.instituteId;
  db.session.userId = SEED.ownerId;
  const fees = feeRepo(db);
  const payments = paymentRepo(db);
  const receipts = receiptRepo(db);
  const batches = batchRepo(db);
  const today = todayIso();

  // A clean batch of four students with no fee and no payment yet.
  const lab = await batches.create(i, { name: 'Class 12-A', academicYear: '2026-27', feeAmount: 12000, feePlan: 'term' });
  const names = ['Neha Arora', 'Samar Dutta', 'Tanvi Rao', 'Yash Malhotra'];
  const students = [] as { id: string; name: string }[];
  for (const [k, name] of names.entries()) {
    const s = db.students.insert(i, { ...D.student(), fullName: name });
    await batches.enroll(i, lab.id, { studentId: s.id, rollNumber: k + 1 });
    students.push({ id: s.id, name });
  }
  const [neha, samar, tanvi, yash] = students;

  const discounts: PlanDiscount[] = [
    { id: 'd1', label: 'Merit scholarship', type: 'percent', amount: 25, note: 'Scored 95%+' },
    { id: 'd2', label: 'Sibling discount', type: 'flat', amount: 500, note: '' },
    { id: 'd3', label: 'Full-ride', type: 'flat', amount: 9000, note: 'Trust sponsored' },
  ];
  const plan = (over: Partial<SavePlanInput> = {}): SavePlanInput => ({
    batchId: lab.id,
    batchIds: [lab.id],
    name: 'Class 12-A fees',
    frequency: 'term',
    totalAmount: 12000,
    schedule: [
      { id: 'i1', label: 'Instalment 1', amount: 4000, dueDate: addDays(today, 10) },
      { id: 'i2', label: 'Instalment 2', amount: 4000, dueDate: addDays(today, 130) },
      { id: 'i3', label: 'Instalment 3', amount: 4000, dueDate: addDays(today, 250) },
    ],
    discounts,
    ...over,
  });

  console.log('Fee plans acceptance');

  await check('pure rules: paisa-exact split, month-end dates, schedules always add up', () => {
    assert.deepEqual(allocate(10000, [1, 1, 1]), [3333.33, 3333.33, 3333.34]);
    assert.equal(addMonths('2026-01-31', 1), '2026-02-28');
    assert.equal(addMonths('2026-11-30', 3), '2027-02-28');
    for (const f of ['monthly', 'quarterly', 'term'] as const) {
      for (const total of [4999, 10000, 12345.67]) {
        const rows = buildSchedule(f, total, today);
        assert.equal(scheduleTotal(rows), total);
        assert.equal(rows.length, f === 'monthly' ? 12 : f === 'quarterly' ? 4 : 3);
      }
    }
  });

  await check('total must equal the sum of the instalments — the repo refuses a mismatch and writes nothing', async () => {
    const before = JSON.stringify([db.feeStructures.dump(), db.studentFees.dump(), db.installments.dump()]);
    const bad = plan({ totalAmount: 12500 });
    const verdict = validatePlan(bad);
    assert.equal(verdict.ok, false);
    assert.match(verdict.total ?? '', /₹500 short/);
    assert.equal(verdict.difference, 500);
    await assert.rejects(() => fees.savePlan(i, bad), /short of the total/);
    await assert.rejects(() => fees.savePlan(i, plan({ totalAmount: 11000 })), /over the total/);
    await assert.rejects(() => fees.savePlan(i, plan({ schedule: [] })), /at least one instalment/);
    await assert.rejects(() => fees.savePlan(i, plan({ batchIds: [] })), /Choose at least one batch/);
    assert.equal(JSON.stringify([db.feeStructures.dump(), db.studentFees.dump(), db.installments.dump()]), before);
  });

  let v1Id = '';
  await check('saving a plan shows every student the correct total', async () => {
    const out = await fees.savePlan(i, plan());
    v1Id = out.structure.id;
    assert.equal(out.versioned, false);
    assert.equal(out.structure.version, 1);
    assert.equal(out.studentsUpdated, 4);
    for (const s of students) {
      const st = await fees.studentStatement(i, s.id);
      assert.ok(st);
      assert.equal(st.gross, 12000);
      assert.equal(st.net, 12000);
      assert.equal(st.due, 12000);
      assert.equal(sumOf(st.installments.map((x) => x.amount)), 12000);
      assert.deepEqual(st.installments.map((x) => x.label), ['Instalment 1', 'Instalment 2', 'Instalment 3']);
    }
    const view = await fees.getPlan(i, lab.id);
    assert.equal(view.structure?.totalAmount, 12000);
    assert.equal(view.students.length, 4);
    assert.equal(view.batches.find((b) => b.batchId === lab.id)?.studentCount, 4);
  });

  await check('a scholarship reduces the student due, not the batch total', async () => {
    const before = await fees.getPlan(i, lab.id);
    await fees.applyStudentDiscounts(i, { studentId: neha.id, discountIds: ['d1', 'd2'] });
    const st = await fees.studentStatement(i, neha.id);
    assert.ok(st);
    assert.equal(st.gross, 12000);
    assert.equal(st.discount, 3500); // 25% of 12,000 + ₹500
    assert.equal(st.net, 8500);
    assert.equal(st.due, 8500);
    assert.equal(sumOf(st.installments.map((x) => x.amount)), 8500);
    assert.deepEqual(st.discountLabels, ['Merit scholarship (Scored 95%+); Sibling discount']);
    const after = await fees.getPlan(i, lab.id);
    assert.equal(after.structure?.totalAmount, 12000);
    assert.equal(after.structure?.id, before.structure?.id);
    assert.deepEqual(after.structure?.schedule, before.structure?.schedule);
    for (const s of [samar, tanvi, yash]) assert.equal((await fees.studentStatement(i, s.id))?.net, 12000);
    // The student's own fee row carries the override.
    const row = db.studentFees.all(i, { studentId: neha.id }).find((f) => f.status === 'active');
    assert.deepEqual(row?.discountIds, ['d1', 'd2']);
    assert.equal(row?.netAmount, 8500);
  });

  await check('a scholarship can be removed again and an unknown one is refused', async () => {
    await fees.applyStudentDiscounts(i, { studentId: yash.id, discountIds: ['d2'] });
    assert.equal((await fees.studentStatement(i, yash.id))?.net, 11500);
    await fees.applyStudentDiscounts(i, { studentId: yash.id, discountIds: [] });
    assert.equal((await fees.studentStatement(i, yash.id))?.net, 12000);
    await assert.rejects(() => fees.applyStudentDiscounts(i, { studentId: yash.id, discountIds: ['nope'] }), /not part of the saved plan/);
  });

  let receiptsBefore = '';
  let paymentId = '';
  await check('recording a payment issues a receipt on the first plan version', async () => {
    const insts = await fees.listInstallments(i, { studentId: samar.id });
    const fee = db.studentFees.all(i, { studentId: samar.id }).find((f) => f.status === 'active')!;
    const payment = await payments.record(i, {
      studentId: samar.id,
      studentFeeId: fee.id,
      installmentId: insts[0].id,
      amount: 4000,
      method: 'upi',
    });
    paymentId = payment.id;
    const receipt = await receipts.getForPayment(i, payment.id);
    assert.ok(receipt);
    assert.equal(receipt.amount, 4000);
    receiptsBefore = JSON.stringify(db.receipts.dump());
  });

  await check('a scholarship on a student who already paid only lowers what is unpaid', async () => {
    const before = await fees.listInstallments(i, { studentId: samar.id });
    await fees.applyStudentDiscounts(i, { studentId: samar.id, discountIds: ['d2'] });
    const after = await fees.listInstallments(i, { studentId: samar.id });
    assert.equal(after[0].amount, 4000);
    assert.equal(after[0].paidAmount, 4000);
    assert.equal(sumOf(after.map((x) => x.amount)), 11500);
    assert.notEqual(after[1].amount, before[1].amount);
    // More than is left to reduce is refused, and nothing changes.
    await assert.rejects(
      () => fees.applyStudentDiscounts(i, { studentId: samar.id, discountIds: ['d3'] }),
      /more than what is still unpaid/,
    );
    assert.equal(sumOf((await fees.listInstallments(i, { studentId: samar.id })).map((x) => x.amount)), 11500);
    assert.equal(JSON.stringify(db.receipts.dump()), receiptsBefore);
  });

  let v2Id = '';
  await check('the plan screen knows saving now must create a version', async () => {
    const view = await fees.getPlan(i, lab.id);
    assert.equal(view.hasPayments, true);
    assert.equal(view.structure?.version, 1);
  });

  await check('editing a plan with payments creates version 2 and leaves receipts untouched', async () => {
    const paymentsBefore = JSON.stringify(db.payments.dump());
    const samarFeeBefore = JSON.stringify(db.studentFees.all(i, { studentId: samar.id }).filter((f) => f.status === 'active'));
    const samarInstBefore = JSON.stringify(db.installments.all(i, { studentId: samar.id }));

    const out = await fees.savePlan(i, plan({
      id: v1Id,
      totalAmount: 15000,
      schedule: [
        { id: 'i1', label: 'Instalment 1', amount: 5000, dueDate: addDays(today, 10) },
        { id: 'i2', label: 'Instalment 2', amount: 5000, dueDate: addDays(today, 130) },
        { id: 'i3', label: 'Instalment 3', amount: 5000, dueDate: addDays(today, 250) },
      ],
    }));
    v2Id = out.structure.id;
    assert.equal(out.versioned, true);
    assert.equal(out.structure.version, 2);
    assert.equal(out.previousId, v1Id);
    assert.equal(out.studentsKept, 1);
    assert.equal(out.studentsUpdated, 3);

    // The old version is kept, retired and linked forward.
    const v1 = db.feeStructures.get(i, v1Id);
    assert.equal(v1.isActive, false);
    assert.equal(v1.supersededById, v2Id);
    assert.equal(v1.totalAmount, 12000);
    assert.deepEqual(v1.schedule.map((x) => x.amount), [4000, 4000, 4000]);

    // History did not move: receipts, payments, Samar's fee and instalments are byte-for-byte equal.
    assert.equal(JSON.stringify(db.receipts.dump()), receiptsBefore);
    assert.equal(JSON.stringify(db.payments.dump()), paymentsBefore);
    assert.equal(JSON.stringify(db.studentFees.all(i, { studentId: samar.id }).filter((f) => f.status === 'active')), samarFeeBefore);
    assert.equal(JSON.stringify(db.installments.all(i, { studentId: samar.id })), samarInstBefore);
    const payment = db.payments.get(i, paymentId);
    assert.equal(db.studentFees.get(i, payment.studentFeeId).feeStructureId, v1Id);

    // Everyone else owes the new total; scholarships carry over and re-price on the new total.
    assert.equal((await fees.studentStatement(i, tanvi.id))?.net, 15000);
    assert.equal((await fees.studentStatement(i, yash.id))?.net, 15000);
    const neha2 = await fees.studentStatement(i, neha.id);
    assert.equal(neha2?.discount, 4250); // 25% of 15,000 + ₹500
    assert.equal(neha2?.net, 10750);
    assert.equal(neha2?.installments.length, 3);
    const samar2 = await fees.studentStatement(i, samar.id);
    assert.equal(samar2?.net, 11500);
    assert.equal(samar2?.paid, 4000);
    assert.equal(samar2?.version, 1);
  });

  await check('the plan screen read shows both versions and who is on which', async () => {
    const view = await fees.getPlan(i, lab.id);
    assert.equal(view.structure?.id, v2Id);
    // Money sits on version 1; the current version has none yet, so the next edit is in place.
    assert.equal(view.hasPayments, false);
    assert.deepEqual(view.versions.map((v) => [v.version, v.isActive, v.students, v.withPayments]), [
      [2, true, 3, 0],
      [1, false, 1, 1],
    ]);
    const samarRow = view.students.find((s) => s.studentId === samar.id);
    assert.equal(samarRow?.onVersion, 1);
    assert.equal(samarRow?.hasPayments, true);
    assert.equal(samarRow?.onPlan, true);
    assert.equal(view.students.find((s) => s.studentId === tanvi.id)?.onVersion, 2);
    // Old fees were not duplicated into the totals.
    const summary = await fees.summary(i);
    assert.ok(summary.billed > 0);
    assert.equal(db.installments.all(i, { studentId: tanvi.id }).length, 3);
  });

  await check('editing a stale version is refused instead of forking the history', async () => {
    await assert.rejects(() => fees.savePlan(i, plan({ id: v1Id })), /replaced/);
  });

  await check('a plan with no payments is edited in place: same version, no duplicate fees', async () => {
    const other = await batches.create(i, { name: 'Class 12-B', academicYear: '2026-27' });
    const kid = db.students.insert(i, { ...D.student(), fullName: 'Ira Sen' });
    await batches.enroll(i, other.id, { studentId: kid.id, rollNumber: 1 });
    const mk = (total: number, n: number): SavePlanInput => ({
      batchId: other.id,
      batchIds: [other.id],
      frequency: 'quarterly',
      totalAmount: total,
      schedule: buildSchedule('quarterly', total, today).slice(0, n).map((x, k, all) => ({ ...x, amount: k === all.length - 1 ? total - (n - 1) * Math.floor(total / n) : Math.floor(total / n) })),
      discounts: [],
    });
    const first = await fees.savePlan(i, mk(8000, 4));
    const again = await fees.savePlan(i, { ...mk(9000, 3), id: first.structure.id });
    assert.equal(again.versioned, false);
    assert.equal(again.structure.version, 1);
    assert.equal(again.structure.id, first.structure.id);
    const st = await fees.studentStatement(i, kid.id);
    assert.equal(st?.net, 9000);
    assert.equal(st?.installments.length, 3);
    assert.equal(db.studentFees.all(i, { studentId: kid.id }).filter((f) => f.status !== 'cancelled').length, 1);
    assert.equal(db.feeStructures.all(i).filter((f) => f.batchIds.includes(other.id)).length, 1);
  });

  await check('a batch can only belong to one active plan', async () => {
    const other = await batches.create(i, { name: 'Class 12-C', academicYear: '2026-27' });
    await assert.rejects(
      () => fees.savePlan(i, plan({ id: undefined, batchId: other.id, batchIds: [other.id, lab.id], name: 'Combined' })),
      /already uses/,
    );
    // "Applies to" several batches works when they are free.
    const out = await fees.savePlan(i, plan({ batchId: other.id, batchIds: [other.id], name: 'Class 12-C fees' }));
    assert.deepEqual(out.structure.batchIds, [other.id]);
  });

  await check('unpaid fees from an older plan are replaced, not stacked', async () => {
    // Seeded Class 9-A students already carry the institute-wide fee. Those without any payment move to the plan.
    const nine = db.batches.all(i).find((b) => b.name.includes('9'))!;
    const rosterBefore = db.enrollments.all(i, { batchId: nine.id, status: 'active' }).length;
    const out = await fees.savePlan(i, { ...plan({ batchId: nine.id, batchIds: [nine.id], name: 'Class 9-A fees' }) });
    assert.equal(out.studentsUpdated + out.studentsKept, rosterBefore);
    assert.ok(out.studentsKept > 0, 'seeded students who paid keep their fee');
    const view9 = await fees.getPlan(i, nine.id);
    assert.equal(view9.students.filter((r) => r.onPlan).length, out.studentsUpdated);
    assert.ok(view9.students.some((r) => !r.onPlan && r.hasPayments), 'kept students are flagged as not on the plan');
    for (const e of db.enrollments.all(i, { batchId: nine.id, status: 'active' })) {
      const live = db.studentFees.all(i, { studentId: e.studentId }).filter((f) => f.status !== 'cancelled');
      assert.equal(live.length, 1);
      const rows = db.installments.all(i, { studentFeeId: live[0].id });
      assert.equal(sumOf(rows.map((x) => x.amount)), live[0].netAmount);
    }
  });

  await check('only the owner can change a plan; a student reads only their own statement', async () => {
    const login = db.studentMemberships.find(i, { studentId: SEED.studentIds[0] })!;
    const userId = db.memberships.get(i, login.membershipId).userId;
    db.session.userId = userId;
    await assert.rejects(() => fees.savePlan(i, plan({ id: undefined })), /Only the owner/);
    await assert.rejects(() => fees.getPlan(i, lab.id), /Only the owner/);
    await assert.rejects(() => fees.applyStudentDiscounts(i, { studentId: neha.id, discountIds: [] }), /Only the owner/);
    await assert.rejects(() => fees.studentStatement(i, neha.id), /your own fees/);
    assert.ok(await fees.studentStatement(i, SEED.studentIds[0]));
    db.session.userId = SEED.ownerId;
  });

  await check('rebalance never touches an instalment with money on it', () => {
    const rows = [
      { id: 'a', amount: 4000, paidAmount: 4000 },
      { id: 'b', amount: 4000, paidAmount: 0 },
      { id: 'c', amount: 4000, paidAmount: 0 },
    ];
    const r = rebalanceInstallments(rows, 9000);
    assert.ok(r.ok);
    if (r.ok) assert.deepEqual([...r.amounts], [['a', 4000], ['b', 2500], ['c', 2500]]);
    assert.equal(rebalanceInstallments(rows, 3000).ok, false);
  });

  await check('plans, versions and overrides survive a snapshot round-trip; an old snapshot still opens', async () => {
    const raw = capture(db);
    const db2 = createDb();
    assert.ok(restore(db2, raw));
    db2.session.userId = SEED.ownerId;
    const fees2 = feeRepo(db2);
    assert.equal((await fees2.getPlan(i, lab.id)).versions.length, 2);
    assert.equal((await fees2.studentStatement(i, neha.id))?.net, 10750);
    // A snapshot written before plans existed has none of the new fields.
    const old = JSON.parse(raw) as { tables: Record<string, Record<string, unknown>[]> };
    for (const row of old.tables.feeStructures) for (const k of ['version', 'supersededById', 'batchIds', 'schedule', 'discounts']) delete row[k];
    for (const row of old.tables.studentFees) delete row.discountIds;
    const db3 = createDb();
    assert.ok(restore(db3, JSON.stringify(old)));
    db3.session.userId = SEED.ownerId;
    const view = await feeRepo(db3).getPlan(i, lab.id);
    assert.equal(view.structure, null);
    assert.ok(await feeRepo(db3).studentStatement(i, SEED.studentIds[0]));
  });

  await check('the form model mirrors the repo: live total, blocked save, split evenly, add and remove', async () => {
    const view = await fees.getPlan(i, lab.id);
    let form: PlanFormState = draftFromView(view);
    assert.equal(isDirty(form, view), false);
    assert.equal(problemsOf(form).ok, true);

    // Editing one instalment by hand breaks the sum: the verdict names the gap and Save would be blocked.
    form = planReducer(form, { type: 'row', id: 'i1', patch: { amount: '5500' } });
    const broken = problemsOf(form);
    assert.equal(broken.ok, false);
    assert.equal(broken.sum, 15500);
    assert.equal(broken.difference, -500);
    assert.match(broken.total ?? '', /₹500 over/);
    assert.equal(isDirty(form, view), true);

    // Split evenly repairs it; changing the total while in sync carries the instalments along.
    form = planReducer(form, { type: 'splitEvenly' });
    assert.equal(problemsOf(form).ok, true);
    form = planReducer(form, { type: 'total', text: '18000' });
    assert.equal(problemsOf(form).ok, true);
    assert.deepEqual(form.rows.map((r) => r.amount), ['6000', '6000', '6000']);

    // Add an instalment: it starts at whatever is missing, and the sum disagrees until the total follows.
    form = planReducer(form, { type: 'addRow' });
    assert.equal(form.rows.length, 4);
    assert.equal(form.rows[3].label, 'Instalment 4');
    assert.equal(problemsOf(form).ok, false);
    form = planReducer(form, { type: 'row', id: form.rows[3].id, patch: { amount: '1000' } });
    form = planReducer(form, { type: 'total', text: '19000' });
    assert.equal(problemsOf(form).ok, true);
    form = planReducer(form, { type: 'removeRow', id: form.rows[1].id });
    assert.deepEqual(form.rows.map((r) => r.label), ['Instalment 1', 'Instalment 2', 'Instalment 3']);

    // Switching frequency rebuilds a schedule that adds up to the typed total.
    form = planReducer(form, { type: 'frequency', frequency: 'monthly' });
    assert.equal(form.rows.length, 12);
    assert.equal(problemsOf(form).ok, true);
    assert.equal(parseMoney('1,250.50'), 1250.5);
    assert.equal(parseMoney('abc'), 0);
    assert.equal(cleanMoney('1.2.555x'), '1.25');
    assert.equal(toInput(form, view).id, view.structure?.id);
    assert.equal(toInput(form, view).batchIds.includes(lab.id), true);

    // An unsaved plan can be saved; a discount that is too large is blocked.
    form = planReducer(planReducer(form, { type: 'addDiscount' }), { type: 'discount', id: 'd4', patch: { label: 'Bad', amount: '150' } });
    assert.match(problemsOf(form).discounts.d4, /above 100/);
  });

  await check('an audit row is written for every plan save and scholarship', () => {
    const actions = db.auditLogs.all(i).map((a) => a.action);
    assert.ok(actions.filter((a) => a === 'fee_plan.saved').length >= 4);
    assert.ok(actions.includes('student_fee.discount_set'));
    const v2 = db.auditLogs.all(i).find((a) => a.action === 'fee_plan.saved' && a.targetId === v2Id);
    assert.deepEqual(v2?.before, { version: 1, totalAmount: 12000 });
  });

  console.log(`\n${passed} checks passed`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
