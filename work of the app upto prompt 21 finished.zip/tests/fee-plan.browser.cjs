const { chromium } = require('@playwright/test');
const { execFileSync } = require('node:child_process');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

/**
 * Browser acceptance for the fee plan screen. Build first:
 *   EXPO_PUBLIC_BACKEND=memory npx expo export --platform web
 *   node tests/fee-plan.browser.cjs
 * Walks: owner → Batches → Class 10-A → Fee plan → total vs instalments (Save blocked,
 * live gap) → split evenly → add a scholarship → save → assign it to one student →
 * the student's Fees tab shows the reduced total and the plan total is unchanged.
 */
const root = path.join(process.cwd(), 'dist');
const types = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.ttf': 'font/ttf', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  let file = path.join(root, decodeURIComponent(req.url.split('?')[0]));
  if (!file.startsWith(root)) { res.writeHead(403).end(); return; }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(root, 'index.html');
  res.setHeader('Content-Type', types[path.extname(file)] || 'application/octet-stream');
  fs.createReadStream(file).pipe(res);
}).listen(8126);

const BASE = 'http://localhost:8126';
const shots = process.env.SHOTS_DIR;
const shot = async (page, name) => { if (shots) await page.screenshot({ path: path.join(shots, `${name}.png`), fullPage: false }); };
const tab = (page, i) => page.locator('[role="tab"]').nth(i);

async function signIn(page) {
  await page.goto(`${BASE}/`);
  const skip = page.getByText('Skip', { exact: true });
  await skip.waitFor({ state: 'visible', timeout: 30000 }).catch(() => {});
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.locator('input:not([type="password"])').first().fill('owner@sunrise.test');
  await page.locator('input[type="password"]').first().fill('demo1234');
  await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  await page.getByText('Enter code', { exact: true }).waitFor({ state: 'visible', timeout: 30000 });
  const box = page.locator('input:visible').first();
  await box.click();
  await page.keyboard.type('123456', { delay: 60 });
  await page.getByRole('button', { name: 'Verify', exact: true }).click();
  await page.locator('[role="tab"]').first().waitFor({ state: 'visible', timeout: 30000 });
}

const step = (msg) => console.log(`PASS: ${msg}`);

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const context = await browser.newContext({ viewport: { width: 400, height: 860 } });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  try {
    await signIn(page);
    step('signed in as the seeded owner');

    await tab(page, 2).click();
    await page.getByRole('button', { name: 'Open Class 10-A', exact: true }).click({ timeout: 30000 });
    await page.getByText('Fee plan', { exact: true }).first().click();
    await page.getByLabel('Plan total').waitFor({ timeout: 20000 });
    assert.match(page.url(), /fees\/plan\//);
    step('Batch → Fee plan opens /fees/plan/[batchId]');

    await page.getByLabel('Plan total').fill('12000');
    await page.getByRole('tab', { name: 'Term', exact: true }).click();
    await page.getByLabel('Instalment 3 amount').waitFor();
    assert.equal(await page.getByLabel('Instalment 1 amount').inputValue(), '4000');
    await page.getByText('Matches the plan total').waitFor();
    step('Term → three instalments of ₹4,000 that match the ₹12,000 total');
    await shot(page, 'fee-1-plan');

    await page.getByLabel('Instalment 1 amount').fill('5000');
    await page.getByText('₹1,000 over the total. Saving is blocked').waitFor();
    const save = page.getByRole('button', { name: 'Save plan', exact: true });
    assert.equal(await save.getAttribute('aria-disabled'), 'true');
    step('editing one instalment shows the live gap and blocks Save');
    await shot(page, 'fee-2-blocked');

    await page.getByText('Split evenly', { exact: true }).click();
    await page.getByText('Matches the plan total').waitFor();
    assert.notEqual(await save.getAttribute('aria-disabled'), 'true');
    step('Split evenly repairs the total and Save unlocks');

    await page.getByRole('button', { name: 'Add discount or scholarship' }).click();
    await page.getByLabel('Discount name').fill('Merit scholarship');
    await page.getByLabel('Merit scholarship amount').fill('25');
    await page.getByLabel('Note').fill('Scored 95%+');
    await page.getByText('Students see this instantly in their Fees tab.').waitFor();
    await shot(page, 'fee-3-discount');

    await save.click();
    await page.getByText(/Fee plan saved/).first().waitFor({ timeout: 20000 });
    step('Save plan → "Fee plan saved"');
    await page.getByText('Version 1', { exact: true }).waitFor();

    await page.getByText('Choose students', { exact: true }).click();
    await page.getByText('Lowers only the chosen student', { exact: false }).waitFor();
    await page.getByRole('switch', { name: /^Sara Khan/ }).click();
    await page.getByText(/Roll 25 · owes ₹9,000/).waitFor({ timeout: 20000 });
    step('scholarship assigned to Sara Khan → she owes ₹9,000');
    await shot(page, 'fee-4-assign');
    await page.getByRole('button', { name: 'Close' }).last().click();

    await page.getByLabel('Plan total').waitFor();
    assert.equal(await page.getByLabel('Plan total').inputValue(), '12000');
    step('the batch plan total is still ₹12,000');

    await page.getByRole('button', { name: 'Back' }).click();
    await tab(page, 1).click();
    await page.getByRole('button', { name: 'Search students' }).click();
    await page.getByPlaceholder('Search name, roll or phone').fill('Sara Khan');
    await page.getByRole('button', { name: /^Sara Khan/ }).first().click({ timeout: 20000 });
    await page.getByText('Fees', { exact: true }).first().click();
    await page.getByText('Total fee', { exact: true }).waitFor({ timeout: 20000 });
    await page.getByText('₹12,000 plan fee − ₹3,000 scholarship').waitFor();
    assert.ok(await page.getByText('₹9,000', { exact: true }).first().isVisible());
    step("student's Fees tab: ₹9,000 total, ₹12,000 plan fee − ₹3,000 scholarship");
    await shot(page, 'fee-5-student');

    // ---- Phase 2: a plan with a payment on it saves as a new version. --------------------------------
    const snapshot = execFileSync('npx', ['tsx', 'tests/support/fee-plan-snapshot.ts'], { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
    const page2 = await context.newPage();
    page2.on('pageerror', (e) => errors.push(e.message));
    await page2.addInitScript((raw) => localStorage.setItem('gf.memory.snapshot.v1', raw), snapshot);
    await signIn(page2);
    await tab(page2, 2).click();
    await page2.getByRole('button', { name: 'Open Class 10-A', exact: true }).click({ timeout: 30000 });
    await page2.getByText('Fee plan', { exact: true }).first().click();
    await page2.getByLabel('Plan total').waitFor({ timeout: 20000 });
    await page2.getByText('Version 1', { exact: true }).waitFor();
    assert.equal(await page2.getByLabel('Plan total').inputValue(), '12000');
    assert.equal(await page2.getByLabel('Instalment 2 amount').inputValue(), '4000');
    step('a saved plan reloads from the snapshot: Version 1, ₹12,000, three instalments');

    await page2.getByLabel('Plan total').fill('15000');
    await page2.getByText('Matches the plan total').waitFor();
    await page2.getByText('Payments exist on this plan.').waitFor();
    const saveV2 = page2.getByRole('button', { name: 'Save as version 2', exact: true });
    await shot(page2, 'fee-6-version-notice');
    await saveV2.click();
    await page2.getByText('Version 1 is kept exactly as it is', { exact: false }).waitFor();
    await shot(page2, 'fee-7-version-confirm');
    await page2.getByRole('button', { name: 'Save version 2', exact: true }).click();
    await page2.getByText(/Version 2 saved/).first().waitFor({ timeout: 20000 });
    await page2.getByText('Current', { exact: true }).waitFor();
    await page2.getByText('Kept', { exact: true }).waitFor();
    await page2.getByText(/1 with payments/).waitFor();
    step('Save as version 2 → confirm → Version 2 current, Version 1 kept with its paid student');
    await page2.waitForTimeout(700);
    assert.equal(await page2.getByText('Save as version 3').count(), 0);
    // Money is on version 1 only, so the next edit of version 2 is in place: no warning, plain Save.
    assert.equal(await page2.getByText('Payments exist on this plan.').count(), 0);
    await shot(page2, 'fee-8-versions');

    assert.deepEqual(errors, [], `runtime errors: ${errors.join(' | ')}`);
    step('no runtime errors');
  } catch (error) {
    await shot(page, 'fee-failure').catch(() => {});
    console.error(error);
    process.exitCode = 1;
  } finally {
    await browser.close();
    server.close();
  }
})();
