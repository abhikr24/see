import { registerCorrections } from './register.corrections';
import { registerRules } from './register.rules';
import { context, passedCount } from './support/register-harness';

/** Acceptance for the monthly register, corrections and CSV (memory backend). */
async function main() {
  const ctx = context();
  console.log('Register & corrections acceptance');
  await registerCorrections(ctx);
  await registerRules(ctx);
  console.log(`\n${passedCount()} checks passed (as of ${ctx.today})`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
