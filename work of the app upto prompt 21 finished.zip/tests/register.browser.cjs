const { chromium } = require('@playwright/test');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

/**
 * Browser acceptance for the attendance register. Build first:
 *   EXPO_PUBLIC_BACKEND=memory npx expo export --platform web
 *   node tests/register.browser.cjs
 * Walks: sign in as owner → register → heatmap + summary → correct a past day
 * with a note → pencil badge → history shows who/why → CSV download.
 */
const root = path.join(process.cwd(), 'dist');
const types = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.ttf': 'font/ttf', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  let file = path.join(root, decodeURIComponent(req.url.split('?')[0]));
  if (!file.startsWith(root)) { res.writeHead(403).end(); return; }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(root, 'index.html');
  res.setHeader('Content-Type', types[path.extname(file)] || 'application/octet-stream');
  fs.createReadStream(file).pipe(res);
}).listen(8125);

const BASE = 'http://localhost:8125';
const BATCH = '00000000-0000-4000-8000-000000000009';
const shots = process.env.SHOTS_DIR;
const shot = async (page, name) => { if (shots) await page.screenshot({ path: path.join(shots, `${name}.png`) }); };
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const label = (d) => `${DOW[d.getUTCDay()]}, ${d.getUTCDate()} ${MON[d.getUTCMonth()]}`;

async function signIn(page) {
  await page.goto(`${BASE}/`);
  const skip = page.getByText('Skip', { exact: true });
  await skip.waitFor({ state: 'visible', timeout: 30000 }).catch(() => {});
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.locator('input:not([type="password"])').first().fill('owner@sunrise.test');
  await page.locator('input[type="password"]').first().fill('demo1234');
  await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  await page.getByText('Enter code', { exact: true }).waitFor({ state: 'visible', timeout: 30000 });
  const box = page.locator('input:visible').first();
  await box.click();
  await page.keyboard.type('123456', { delay: 60 });
  await page.getByRole('button', { name: 'Verify', exact: true }).click();
  await page.locator('[role="tab"]').first().waitFor({ state: 'visible', timeout: 30000 });
}

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const context = await browser.newContext({ viewport: { width: 400, height: 860 }, acceptDownloads: true });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  try {
    await signIn(page);
    console.log('PASS: signed in as the seeded owner');

    // Entry point: dashboard → Take attendance → the header's register button.
    await page.getByRole('button', { name: /Take attendance/ }).first().click();
    await page.getByRole('button', { name: 'Open the monthly register' }).click();
    await page.getByText('Attendance register', { exact: true }).waitFor({ timeout: 20000 });
    assert.match(page.url(), /attendance\/register/);
    console.log('PASS: Take attendance → register button opens the register route');

    const now = new Date();
    const today = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
    const todayCell = page.getByRole('button', { name: new RegExp(`^${label(today)}: \\d+ present`) });
    await todayCell.waitFor({ timeout: 20000 });
    const todayText = await todayCell.getAttribute('aria-label');
    console.log(`PASS: heatmap loaded — ${todayText}`);
    for (const word of ['Present', 'Late', 'Absent']) assert.ok(await page.getByText(word, { exact: true }).first().isVisible());
    await shot(page, 'register-1-month');

    // Correct a day 3 days back (kept inside the current month when possible).
    const target = new Date(today); target.setUTCDate(today.getUTCDate() - 3);
    const cell = page.getByRole('button', { name: new RegExp(`^${label(target)}: `) });
    if (!(await cell.count())) { await page.getByRole('button', { name: 'Previous month' }).click(); }
    const before = await cell.getAttribute('aria-label');
    assert.ok(!/Corrected/.test(before), 'not corrected yet');
    await cell.click();
    await page.getByText(/P present · L late · A absent/).waitFor({ timeout: 15000 });
    const save = page.getByRole('button', { name: /Save correction/ });
    assert.equal(await save.isDisabled(), true, 'save waits for a change and a note');
    await page.getByRole('button', { name: 'Aarav Sharma: Absent' }).click();
    assert.equal(await save.isDisabled(), true, 'a note is still required');
    await page.getByPlaceholder(/What changed/).fill('Parent confirmed the absence by phone');
    await shot(page, 'register-2-sheet');
    assert.equal(await save.isDisabled(), false);
    await save.click();
    await page.getByText(/Correction saved/).waitFor({ timeout: 15000 });
    console.log('PASS: correction saved with a note');

    const after = page.getByRole('button', { name: new RegExp(`^${label(target)}: .*Corrected`) });
    await after.waitFor({ timeout: 15000 });
    console.log(`PASS: pencil badge on the corrected day — ${await after.getAttribute('aria-label')}`);
    await shot(page, 'register-3-badge');

    await after.click();
    await page.getByText('EARLIER CORRECTIONS').waitFor({ timeout: 15000 });
    await page.getByText('“Parent confirmed the absence by phone”').waitFor();
    await page.getByText(/Rahul Sharma \(Owner\)/).waitFor();
    await page.getByText('Aarav Sharma: Present → Absent').waitFor();
    await page.getByText('Originally present').waitFor();
    await page.getByText('EARLIER CORRECTIONS').scrollIntoViewIfNeeded();
    await shot(page, 'register-5-note');
    console.log('PASS: history shows who changed what and why; the original value is kept');
    await shot(page, 'register-4-history');
    await page.getByRole('button', { name: 'Close' }).last().click();

    // Future dates never open anything; the next-month chevron is off on the current month.
    assert.equal(await page.getByRole('button', { name: 'Next month' }).isDisabled(), true);

    const [download] = await Promise.all([
      page.waitForEvent('download', { timeout: 15000 }),
      page.getByRole('button', { name: 'Download monthly sheet' }).click(),
    ]);
    const file = await download.path();
    const text = fs.readFileSync(file, 'utf8');
    assert.match(download.suggestedFilename(), /^attendance-class-10-a-\d{4}-\d{2}\.csv$/);
    assert.equal(text.charCodeAt(0), 0xfeff, 'BOM');
    assert.ok(text.includes('\r\n') && text.includes('Aarav Sharma'));
    assert.ok(/A\*/.test(text), 'the corrected cell is starred');
    console.log(`PASS: CSV downloaded (${download.suggestedFilename()}, ${text.split('\r\n').length} lines)`);

    assert.deepEqual(errors, [], `page errors: ${errors.join(' | ')}`);
    console.log('PASS: no runtime errors');
  } catch (error) {
    await shot(page, 'register-failure');
    console.error('FAIL:', error.message);
    process.exitCode = 1;
  } finally {
    await browser.close();
    server.close();
  }
})();
