import assert from 'node:assert/strict';
import { SEED } from '../src/backends/memory/seed';
import type { Ctx } from './support/register-harness';
import { check, rejects } from './support/register-harness';
import { addDaysIso } from '../src/features/attendance/model';
import { shiftMonth } from '../src/features/attendance/register-model';

/** Heatmap, summary rows and the correction write. */
export async function registerCorrections(ctx: Ctx) {
  const { db, attendance, audit, i, batchId, today, month, rawDay, count, assertHeat, rowOf } = ctx;
  await check('heatmap cells match the raw records exactly (this month and last)', async () => {
    for (const m of [month, shiftMonth(month, -1)]) {
      const register = await attendance.monthRegister(i, { batchId, month: m });
      assertHeat(register);
      assert.equal(register.days.length, new Date(Date.UTC(Number(m.slice(0, 4)), Number(m.slice(5)), 0)).getUTCDate());
      assert.equal(register.startOffset, (new Date(`${m}-01T00:00:00Z`).getUTCDay() + 6) % 7);
    }
    const register = await attendance.monthRegister(i, { batchId, month });
    assert.equal(register.days.filter((d) => d.isToday).length, 1);
    assert.equal(register.days.find((d) => d.isToday)?.state, 'marked');
  });

  await check('the three summary rows are shares of the month’s records, from the repo', async () => {
    const register = await attendance.monthRegister(i, { batchId, month });
    const raw = register.days.flatMap((d) => rawDay(d.date));
    const s = register.summary;
    assert.equal(s.total, raw.length);
    assert.equal(s.present, count(raw, 'present'));
    assert.equal(s.late, count(raw, 'late'));
    assert.equal(s.absent, count(raw, 'absent'));
    assert.equal(s.presentPercent, Math.round((s.present / s.total) * 1000) / 10);
    assert.equal(s.latePercent, Math.round((s.late / s.total) * 1000) / 10);
    assert.equal(s.absentPercent, Math.round((s.absent / s.total) * 1000) / 10);
    const first = register.days[0].date;
    const repo = await attendance.summary(i, { batchId, from: first, to: register.days.at(-1)?.date });
    assert.equal(repo.percent, s.attendedPercent, 'same percentage the student/batch summary reports');
    assert.equal(register.summary.markedDays, register.days.filter((d) => d.state === 'marked').length);
  });

  const yesterday = addDaysIso(today, -1);
  const aarav = SEED.studentIds[0];
  await check('a correction updates the record, the register and the student’s percentage', async () => {
    const before = await attendance.summary(i, { studentId: aarav });
    const row = await rowOf(yesterday, aarav);
    const regBefore = await attendance.monthRegister(i, { batchId, month: yesterday.slice(0, 7) });
    const cellBefore = regBefore.days.find((d) => d.date === yesterday)!;
    assert.equal(row.status, 'present');
    const saved = await attendance.correctAttendance(i, {
      batchId, date: yesterday, reason: 'Parent confirmed the absence by phone', changes: [{ recordId: row.recordId, status: 'absent' }],
    });
    assert.equal(saved.length, 1);
    assert.equal((await rowOf(yesterday, aarav)).status, 'absent');
    const after = await attendance.summary(i, { studentId: aarav });
    assert.equal(after.absent, before.absent + 1);
    assert.equal(after.present, before.present - 1);
    assert.ok(after.percent < before.percent, `${after.percent} < ${before.percent}`);
    const regAfter = await attendance.monthRegister(i, { batchId, month: yesterday.slice(0, 7) });
    const cellAfter = regAfter.days.find((d) => d.date === yesterday)!;
    assert.equal(cellAfter.absent, cellBefore.absent + 1);
    assert.equal(cellAfter.present, cellBefore.present - 1);
    assert.equal(cellAfter.corrected, true);
    assert.equal(cellBefore.corrected, false);
    assertHeat(regAfter);
    const student = regAfter.students.find((s) => s.studentId === aarav)!;
    const m = yesterday.slice(0, 7);
    const monthOnly = await attendance.summary(i, { studentId: aarav, from: `${m}-01`, to: regAfter.days.at(-1)?.date });
    assert.equal(student.percent, monthOnly.percent, 'register row = the student’s own summary for that month');
    assert.equal(student.cells[yesterday].corrected, true);
    assert.equal(student.cells[yesterday].status, 'absent');
  });

  await check('the original value stays in attendance_corrections: who, what, why', async () => {
    const rows = db.attendanceCorrections.all(i, { studentId: aarav });
    assert.equal(rows.length, 1);
    const [c] = rows;
    assert.equal(c.currentStatus, 'present', 'original kept');
    assert.equal(c.requestedStatus, 'absent');
    assert.equal(c.reason, 'Parent confirmed the absence by phone');
    assert.equal(c.requestedBy, SEED.ownerId);
    assert.equal(c.reviewedBy, SEED.ownerId);
    assert.equal(c.status, 'approved');
    const day = await attendance.registerDay(i, { batchId, date: yesterday });
    const entry = day.corrections[0];
    assert.equal(entry.changedByName, 'Rahul Sharma');
    assert.equal(entry.changedByRole, 'owner');
    assert.equal(entry.studentName, 'Aarav Sharma');
    assert.equal(entry.date, yesterday);
    const row = day.sheets[0].rows.find((r) => r.studentId === aarav)!;
    assert.equal(row.corrected, true);
    assert.equal(row.originalStatus, 'present');
  });

  await check('the correction is in the audit trail with its reason', async () => {
    const page = await audit.listAuditLogs(i, { where: { action: 'attendance.corrected' } });
    assert.equal(page.items.length, 1);
    const log = page.items[0];
    assert.equal(log.actorId, SEED.ownerId);
    assert.equal(log.actorRole, 'owner');
    assert.equal(log.targetType, 'attendance_record');
    assert.deepEqual(log.before, { status: 'present' });
    assert.equal((log.after as { status: string }).status, 'absent');
    assert.equal((log.after as { reason: string }).reason, 'Parent confirmed the absence by phone');
  });

  await check('a second correction keeps the very first value as the original', async () => {
    const row = await rowOf(yesterday, aarav);
    await attendance.correctAttendance(i, {
      batchId, date: yesterday, reason: 'Arrived after roll call', changes: [{ recordId: row.recordId, status: 'late' }],
    });
    const rows = db.attendanceCorrections.all(i, { studentId: aarav });
    assert.equal(rows.length, 2);
    assert.deepEqual(rows.map((r) => [r.currentStatus, r.requestedStatus]).sort(), [['absent', 'late'], ['present', 'absent']]);
    const after = await rowOf(yesterday, aarav);
    assert.equal(after.status, 'late');
    assert.equal(after.originalStatus, 'present');
    assert.equal(db.auditLogs.all(i, { action: 'attendance.corrected' }).length, 2);
  });

  await check('a reason is required; nothing-changed and bad input are rejected without writing', async () => {
    const row = await rowOf(yesterday, SEED.studentIds[1]);
    const writes = () => db.attendanceCorrections.all(i).length;
    const n = writes();
    await rejects(attendance.correctAttendance(i, { batchId, date: yesterday, reason: '  ', changes: [{ recordId: row.recordId, status: 'absent' }] }), 'VALIDATION', 'note');
    await rejects(attendance.correctAttendance(i, { batchId, date: yesterday, reason: 'x'.repeat(301), changes: [{ recordId: row.recordId, status: 'absent' }] }), 'VALIDATION');
    await rejects(attendance.correctAttendance(i, { batchId, date: yesterday, reason: 'Same as before', changes: [{ recordId: row.recordId, status: row.status }] }), 'VALIDATION', 'Nothing');
    await rejects(attendance.correctAttendance(i, { batchId, date: yesterday, reason: 'No changes', changes: [] }), 'VALIDATION');
    await rejects(attendance.correctAttendance(i, { batchId, date: today, reason: 'Wrong day', changes: [{ recordId: row.recordId, status: 'absent' }] }), 'VALIDATION', 'not on this day');
    await rejects(attendance.correctAttendance(i, { batchId, date: addDaysIso(today, 1), reason: 'Tomorrow', changes: [] }), 'VALIDATION', 'future');
    await rejects(attendance.correctAttendance(i, { batchId, date: yesterday, reason: 'Half and half', changes: [{ recordId: row.recordId, status: 'absent' }, { recordId: 'nope', status: 'late' }] }), 'NOT_FOUND');
    assert.equal(writes(), n, 'a rejected save writes nothing');
    assert.equal((await rowOf(yesterday, SEED.studentIds[1])).status, row.status);
  });

  await check('several changes in one save: one correction row and one audit row each, all-or-nothing', async () => {
    const day = await attendance.registerDay(i, { batchId, date: yesterday });
    const [a, b] = day.sheets[0].rows.filter((r) => r.status === 'present' && r.studentId !== aarav);
    const n = db.attendanceCorrections.all(i).length;
    const out = await attendance.correctAttendance(i, {
      batchId, date: yesterday, reason: 'Entered against the wrong students',
      changes: [{ recordId: a.recordId, status: 'absent' }, { recordId: b.recordId, status: 'absent' }],
    });
    assert.equal(out.length, 2);
    assert.equal(db.attendanceCorrections.all(i).length, n + 2);
    assert.equal(db.auditLogs.all(i, { action: 'attendance.corrected' }).length, 4);
  });

  await check('a day turns red when the absent share reaches the threshold, and the pencil shows', async () => {
    const register = await attendance.monthRegister(i, { batchId, month: yesterday.slice(0, 7) });
    const cell = register.days.find((d) => d.date === yesterday)!;
    assert.ok(cell.absent / cell.total >= 0.15);
    assert.equal(cell.tone, 'absent');
    assert.equal(cell.corrected, true);
    assertHeat(register);
  });

  await check('a day turns amber when late reaches the threshold', async () => {
    const date = addDaysIso(today, -3);
    const day = await attendance.registerDay(i, { batchId, date });
    const present = day.sheets[0].rows.filter((r) => r.status === 'present').slice(0, 2);
    await attendance.correctAttendance(i, {
      batchId, date, reason: 'Arrived after roll call', changes: present.map((r) => ({ recordId: r.recordId, status: 'late' as const })),
    });
    const register = await attendance.monthRegister(i, { batchId, month: date.slice(0, 7) });
    assert.equal(register.days.find((d) => d.date === date)?.tone, 'late');
    assertHeat(register);
  });
}
