import assert from 'node:assert/strict';
import { SEED } from '../src/backends/memory/seed';
import { capture, restore } from '../src/backends/memory/persist';
import { OWNER_ONLY_AFTER_DAYS } from '../src/core/contracts/attendance-register';
import type { MonthRegister } from '../src/core/contracts/models';
import { csvFilename, registerCsv } from '../src/features/attendance/csv';
import { addDaysIso } from '../src/features/attendance/model';
import { createDb } from '../src/backends/memory/db';
import type { Ctx } from './support/register-harness';
import { check, parseCsv, rejects } from './support/register-harness';

/** The 7-day owner rule, roles, the CSV and persistence. Runs after the correction checks, on the same data. */
export async function registerRules(ctx: Ctx) {
  const { db, attendance, i, batchId, today, month, asOwner, asTeacher, asParent, rowOf } = ctx;
  const yesterday = addDaysIso(today, -1);
  await check(`corrections older than ${OWNER_ONLY_AFTER_DAYS} days need the owner`, async () => {
    const edge = addDaysIso(today, -OWNER_ONLY_AFTER_DAYS);
    const old = addDaysIso(today, -(OWNER_ONLY_AFTER_DAYS + 1));
    const pick = async (date: string) => (await attendance.registerDay(i, { batchId, date })).sheets[0].rows.find((r) => r.status === 'present')!;
    asTeacher();
    const edgeDay = await attendance.registerDay(i, { batchId, date: edge });
    assert.equal(edgeDay.access.canCorrect, true, 'exactly 7 days old is still fine for a teacher');
    const oldDay = await attendance.registerDay(i, { batchId, date: old });
    assert.equal(oldDay.access.canCorrect, false);
    assert.equal(oldDay.access.block, 'owner_only');
    assert.equal(oldDay.access.ageDays, OWNER_ONLY_AFTER_DAYS + 1);
    const oldRow = await pick(old);
    const n = db.attendanceCorrections.all(i).length;
    await rejects(attendance.correctAttendance(i, { batchId, date: old, reason: 'Late entry', changes: [{ recordId: oldRow.recordId, status: 'absent' }] }), 'FORBIDDEN', '7 days');
    assert.equal(db.attendanceCorrections.all(i).length, n);
    const edgeRow = await pick(edge);
    const ok = await attendance.correctAttendance(i, { batchId, date: edge, reason: 'Entered for the wrong student', changes: [{ recordId: edgeRow.recordId, status: 'absent' }] });
    assert.equal(ok[0].changedByRole, 'teacher');
    asOwner();
    assert.equal((await attendance.registerDay(i, { batchId, date: old })).access.canCorrect, true);
    const done = await attendance.correctAttendance(i, { batchId, date: old, reason: 'Late entry', changes: [{ recordId: oldRow.recordId, status: 'absent' }] });
    assert.equal(done[0].changedByRole, 'owner');
    assert.equal(db.attendanceRecords.get(i, oldRow.recordId).status, 'absent');
    assert.equal(db.attendanceRecords.get(i, oldRow.recordId).markedBy, SEED.teacherId, 'who first marked it is untouched');
  });

  await check('parents, students and signed-out callers cannot correct', async () => {
    const row = await rowOf(yesterday, SEED.studentIds[2]);
    const attempt = () => attendance.correctAttendance(i, { batchId, date: yesterday, reason: 'Please change this', changes: [{ recordId: row.recordId, status: 'absent' }] });
    asParent();
    assert.equal((await attendance.registerDay(i, { batchId, date: yesterday })).access.block, 'role');
    await rejects(attempt(), 'FORBIDDEN');
    db.session.userId = null;
    assert.equal((await attendance.registerDay(i, { batchId, date: yesterday })).access.block, 'role');
    await rejects(attempt(), 'UNAUTHENTICATED');
    asOwner();
  });

  await check('the monthly CSV matches the register and parses back cleanly', async () => {
    const register = await attendance.monthRegister(i, { batchId, month: yesterday.slice(0, 7) });
    const text = registerCsv(register);
    assert.equal(text.charCodeAt(0), 0xfeff, 'UTF-8 BOM for Excel');
    assert.ok(!/[^\r]\n/.test(text), 'CRLF only');
    const rows = parseCsv(text.slice(1));
    const header = rows[0];
    const marked = register.days.filter((d) => d.state === 'marked');
    assert.deepEqual(header.slice(0, 2), ['Roll', 'Student']);
    assert.deepEqual(header.slice(2, 2 + marked.length), marked.map((d) => d.date));
    assert.deepEqual(header.slice(-5), ['Present', 'Late', 'Absent', 'Leave', 'Attendance %']);
    const body = rows.slice(1, 1 + register.students.length);
    assert.equal(body.length, 12);
    for (const line of body) assert.equal(line.length, header.length, 'every row is as wide as the header');
    const letter = { present: 'P', late: 'L', absent: 'A', leave: 'LV' } as const;
    body.forEach((line, idx) => {
      const s = register.students[idx];
      assert.equal(line[1], s.fullName);
      marked.forEach((d, col) => {
        const raw = db.attendanceRecords.all(i, { batchId, studentId: s.studentId }).find((r) => {
          const session = db.attendanceSessions.get(i, r.sessionId);
          return session.date === d.date;
        })!;
        const cell = line[2 + col];
        assert.equal(cell.replace('*', ''), letter[raw.status], `${s.fullName} ${d.date}`);
        assert.equal(cell.endsWith('*'), db.attendanceCorrections.all(i, { recordId: raw.id }).length > 0, 'corrected marker');
      });
      assert.equal(Number(line.at(-1)), s.percent);
    });
    assert.ok(body.some((line) => line.some((c) => c.endsWith('*'))), 'corrected days are marked');
    assert.equal(rows[1 + register.students.length][1], 'Attended (present + late)');
    assert.equal(csvFilename(register), `attendance-class-10-a-${register.month}.csv`);
  });

  await check('CSV quoting and formula safety', () => {
    const register: MonthRegister = {
      batchId, batchName: 'Class "10-A", Patna', month: '2026-11', startOffset: 0, days: [],
      summary: { total: 0, present: 0, late: 0, absent: 0, leave: 0, markedDays: 0, presentPercent: 0, latePercent: 0, absentPercent: 0, attendedPercent: 0 },
      students: [
        { studentId: 'a', fullName: 'Sharma, Aarav', rollNumber: 1, cells: {}, present: 0, late: 0, absent: 0, leave: 0, percent: 0 },
        { studentId: 'b', fullName: '=HYPERLINK("http://x")', rollNumber: 2, cells: {}, present: 0, late: 0, absent: 0, leave: 0, percent: 0 },
        { studentId: 'c', fullName: 'Zoë "ZZ" Ahmed', rollNumber: 3, cells: {}, present: 0, late: 0, absent: 0, leave: 0, percent: 0 },
      ],
    };
    const rows = parseCsv(registerCsv(register).slice(1));
    assert.equal(rows[1][1], 'Sharma, Aarav');
    assert.equal(rows[2][1], `'=HYPERLINK("http://x")`, 'never starts with =');
    assert.equal(rows[3][1], 'Zoë "ZZ" Ahmed');
    assert.ok(rows.every((r) => r.length === 0 || r.length === rows[0].length || r.length === 1));
  });

  await check('register reads are tenant-scoped', async () => {
    await rejects(attendance.monthRegister('00000000-0000-4000-8000-0000000000ff', { batchId, month }), 'NOT_FOUND');
    await rejects(attendance.monthRegister(i, { batchId, month: '2026-13' }), 'VALIDATION');
  });

  await check('corrections survive a snapshot round trip, and old snapshots still restore', async () => {
    const snap = capture(db);
    const fresh = createDb();
    assert.equal(restore(fresh, snap), true);
    assert.equal(fresh.attendanceCorrections.all(i).length, db.attendanceCorrections.all(i).length);
    const legacy = JSON.parse(snap) as { tables: Record<string, unknown[]> };
    delete legacy.tables.attendanceCorrections;
    const old = createDb();
    assert.equal(restore(old, JSON.stringify(legacy)), true);
    assert.equal(old.attendanceCorrections.all(i).length, 0);
    assert.equal(old.attendanceRecords.all(i).length, db.attendanceRecords.all(i).length);
  });
}
