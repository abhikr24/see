/**
 * Prints a memory-backend snapshot in which Class 10-A already has a saved fee plan
 * and one student (Sara Khan) has paid ₹4,000 on it. The browser test loads it into
 * localStorage so the plan screen opens on a plan that has payments.
 */
import { batchRepo } from '../../src/backends/memory/academics';
import { createDb } from '../../src/backends/memory/db';
import { feeRepo, paymentRepo } from '../../src/backends/memory/finance';
import { capture } from '../../src/backends/memory/persist';
import { seed, SEED } from '../../src/backends/memory/seed';
import { addDays, todayIso } from '../../src/backends/memory/store';

async function main() {
  const db = createDb();
  seed(db);
  db.session.userId = SEED.ownerId;
  const i = SEED.instituteId;
  const fees = feeRepo(db);
  const today = todayIso();
  await batchRepo(db).get(i, SEED.batchId);
  await fees.savePlan(i, {
    batchId: SEED.batchId,
    batchIds: [SEED.batchId],
    name: 'Class 10-A fees',
    frequency: 'term',
    totalAmount: 12000,
    schedule: [4000, 4000, 4000].map((amount, n) => ({
      id: `i${n + 1}`,
      label: `Instalment ${n + 1}`,
      amount,
      dueDate: addDays(today, 10 + n * 120),
    })),
    discounts: [{ id: 'd1', label: 'Merit scholarship', type: 'percent', amount: 25, note: '' }],
  });
  const sara = db.students.all(i).find((s) => s.fullName === 'Sara Khan')!;
  const fee = db.studentFees.all(i, { studentId: sara.id }).find((f) => f.status === 'active')!;
  const first = (await fees.listInstallments(i, { studentId: sara.id }))[0];
  await paymentRepo(db).record(i, {
    studentId: sara.id,
    studentFeeId: fee.id,
    installmentId: first.id,
    amount: 4000,
    method: 'cash',
  });
  process.stdout.write(capture(db));
}

void main();
