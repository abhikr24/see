import assert from 'node:assert/strict';
import { createDb } from '../../src/backends/memory/db';
import { seed, SEED } from '../../src/backends/memory/seed';
import { ensureGuardians } from '../../src/backends/memory/seed-guardians';
import { attendanceRepo } from '../../src/backends/memory/academics';
import { analyticsRepo } from '../../src/backends/memory/business';
import { isBackendError } from '../../src/core/contracts/errors';
import type { AttendanceRecord, AttendanceStatus, MonthRegister } from '../../src/core/contracts/models';
import { todayIso } from '../../src/features/attendance/model';

/** Shared setup for the register acceptance checks (memory backend). */

let passed = 0;
export const passedCount = () => passed;
export const check = (name: string, fn: () => void | Promise<void>) =>
  Promise.resolve(fn()).then(() => {
    passed += 1;
    console.log(`  ✓ ${name}`);
  });

export const rejects = async (promise: Promise<unknown>, code: string, includes?: string) => {
  try {
    await promise;
  } catch (error) {
    assert.ok(isBackendError(error), `expected a BackendError, got ${String(error)}`);
    assert.equal(error.code, code, error.message);
    if (includes) assert.ok(error.message.includes(includes), error.message);
    return;
  }
  assert.fail(`expected ${code}`);
};

/** RFC 4180 reader, written separately from the writer so the round trip is a real check. */
export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let field = '';
  let row: string[] = [];
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quoted) {
      if (ch === '"' && text[i + 1] === '"') {
        field += '"';
        i += 1;
      } else if (ch === '"') quoted = false;
      else field += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ',') {
      row.push(field);
      field = '';
    } else if (ch === '\r' && text[i + 1] === '\n') {
      row.push(field);
      rows.push(row);
      row = [];
      field = '';
      i += 1;
    } else field += ch;
  }
  if (field || row.length) {
    row.push(field);
    rows.push(row);
  }
  return rows;
}

export function context() {
  const db = createDb();
  seed(db);
  ensureGuardians(db);
  const attendance = attendanceRepo(db);
  const audit = analyticsRepo(db);
  const i = SEED.instituteId;
  const batchId = SEED.batchId;
  const today = todayIso();
  const month = today.slice(0, 7);
  const sid = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
  const asOwner = () => (db.session.userId = SEED.ownerId);
  const asTeacher = () => (db.session.userId = SEED.teacherId);
  const asParent = () => (db.session.userId = sid(37));
  asOwner();

  /** The raw rows of one day, read straight from the tables. */
  const rawDay = (date: string): AttendanceRecord[] => {
    const ids = new Set(db.attendanceSessions.all(i, { batchId, date }).map((s) => s.id));
    return db.attendanceRecords.all(i, { batchId }).filter((r) => ids.has(r.sessionId));
  };
  const count = (rows: AttendanceRecord[], status: AttendanceStatus) => rows.filter((r) => r.status === status).length;
  /** The colour rule, restated: red ≥ 15% absent, amber ≥ 15% late, else teal by present share. */
  const expectedColour = (rows: AttendanceRecord[]) => {
    const total = rows.length;
    if (count(rows, 'absent') / total >= 0.15) return 'red';
    if (count(rows, 'late') / total >= 0.15) return 'amber';
    const present = count(rows, 'present') / total;
    return present >= 0.95 ? 'teal-3' : present >= 0.85 ? 'teal-2' : 'teal-1';
  };
  const colourOf = (cell: MonthRegister['days'][number]) =>
    cell.tone === 'absent' ? 'red' : cell.tone === 'late' ? 'amber' : `teal-${cell.tint}`;
  /** Every cell of a register against the raw records. */
  const assertHeat = (register: MonthRegister) => {
    for (const cell of register.days) {
      const rows = rawDay(cell.date);
      if (cell.date > today) {
        assert.equal(cell.state, 'future', cell.date);
        assert.equal(cell.tone, null);
      } else if (rows.length === 0) {
        assert.equal(cell.state, 'unmarked', cell.date);
        assert.equal(cell.tone, null);
      } else {
        assert.equal(cell.state, 'marked', cell.date);
        assert.equal(colourOf(cell), expectedColour(rows), cell.date);
        assert.deepEqual(
          [cell.present, cell.late, cell.absent, cell.leave, cell.total],
          [count(rows, 'present'), count(rows, 'late'), count(rows, 'absent'), count(rows, 'leave'), rows.length],
          cell.date,
        );
      }
      assert.equal(cell.isToday, cell.date === today);
    }
  };
  const rowOf = async (date: string, studentId: string) => {
    const day = await attendance.registerDay(i, { batchId, date });
    return day.sheets[0].rows.find((r) => r.studentId === studentId)!;
  };
  return { db, attendance, audit, i, batchId, today, month, asOwner, asTeacher, asParent, rawDay, count, assertHeat, rowOf };
}

export type Ctx = ReturnType<typeof context>;
