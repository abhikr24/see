import assert from 'node:assert/strict';
import { createDb } from '../src/backends/memory/db';
import { seed, SEED } from '../src/backends/memory/seed';
import { ensureHomework } from '../src/backends/memory/seed-homework';
import { attendanceRepo, batchRepo, timetableRepo } from '../src/backends/memory/academics';
import { analyticsRepo } from '../src/backends/memory/business';
import { examRepo, markRepo, submissionRepo } from '../src/backends/memory/coursework';
import { progressPort } from '../src/backends/memory/progress';
import { isBackendError } from '../src/core/contracts/errors';
import { FALLING_RULES } from '../src/core/contracts/teacher';
import { takeParamsFromRoute } from '../src/features/attendance/links';
import { addDaysIso, todayIso } from '../src/features/attendance/model';
import {
  alertRowsOf,
  attentionOf,
  classCardsOf,
  daysLabel,
  filterClasses,
  heroLine,
  quickActionsOf,
  scheduleRowsOf,
  statsOf,
} from '../src/features/teacher/model';

let passed = 0;
const check = (name: string, fn: () => void | Promise<void>) =>
  Promise.resolve(fn()).then(() => {
    passed += 1;
    console.log(`  ✓ ${name}`);
  });

const rejects = async (promise: Promise<unknown>, code: string) => {
  try {
    await promise;
  } catch (error) {
    assert.ok(isBackendError(error), `expected a BackendError, got ${String(error)}`);
    assert.equal(error.code, code, error.message);
    return error;
  }
  return assert.fail(`expected ${code}`);
};

const sid = (n: number) => `00000000-0000-4000-8000-${String(n).padStart(12, '0')}`;
const ROHIT = sid(3); // Mathematics, assigned teacher of Class 10-A
const PRIYA = sid(4); // Physics, assigned teacher of Class 9-A
const MEERA = sid(5); // Chemistry, assigned teacher of Class 11-A
const SNEHA = sid(6); // English, no batch of her own
const CLASS_10A = sid(9);
const CLASS_9A = sid(10);
const CLASS_11A = sid(11);

async function main() {
  const db = createDb();
  seed(db);
  const i = SEED.instituteId;
  const today = todayIso();
  const batches = batchRepo(db);
  const attendance = attendanceRepo(db);
  const analytics = analyticsRepo(db);
  const progress = progressPort(db);
  const timetable = timetableRepo(db);
  const as = (userId: string | null) => (db.session.userId = userId);
  const names = (rows: { name: string }[]) => rows.map((row) => row.name).sort();
  const rosterOf = (batchId: string) =>
    new Set(db.enrollments.all(i, { batchId, status: 'active' }).map((e) => e.studentId));

  console.log('Teacher home and My Classes acceptance');

  await check('a second teacher account sees a different class list', async () => {
    as(ROHIT);
    const rohit = await batches.listMyClasses(i);
    as(PRIYA);
    const priya = await batches.listMyClasses(i);
    assert.deepEqual(names(rohit), ['Class 10-A']);
    assert.deepEqual(names(priya), ['Class 9-A']);
    assert.equal(rohit.filter((a) => priya.some((b) => b.batchId === a.batchId)).length, 0, 'no class in common');
    as(SNEHA);
    assert.deepEqual(await batches.listMyClasses(i), [], 'a teacher with no batch of her own sees none');
  });

  await check('every batch read is scoped in the repo, not only the teacher card list', async () => {
    as(ROHIT);
    assert.deepEqual(names((await batches.list(i)).items), ['Class 10-A']);
    assert.equal((await batches.list(i)).total, 1);
    assert.deepEqual(names(await batches.listSummaries(i)), ['Class 10-A']);
    assert.deepEqual(names(await batches.listMine(i)), ['Class 10-A']);
    assert.equal((await batches.list(i, { search: 'Class' })).total, 1, 'a search cannot widen the scope');
    as(SEED.ownerId);
    assert.deepEqual(names((await batches.list(i)).items), ['Class 10-A', 'Class 11-A', 'Class 9-A']);
    assert.equal((await batches.listSummaries(i)).length, 3, 'the owner still sees every batch');
  });

  await check("another teacher's batch id returns not_found, exactly like an id that does not exist", async () => {
    as(ROHIT);
    assert.equal((await batches.get(i, CLASS_10A)).name, 'Class 10-A');
    const theirs = await rejects(batches.get(i, CLASS_9A), 'NOT_FOUND');
    const missing = await rejects(batches.get(i, sid(999999)), 'NOT_FOUND');
    assert.equal(theirs.message, missing.message, 'the two cases cannot be told apart');
    await rejects(batches.listRoster(i, CLASS_9A), 'NOT_FOUND');
    await rejects(batches.listEnrollments(i, CLASS_9A), 'NOT_FOUND');
    await rejects(attendance.openRoll(i, { batchId: CLASS_9A, date: today }), 'NOT_FOUND');
    await rejects(attendance.monthRegister(i, { batchId: CLASS_9A, month: today.slice(0, 7) }), 'NOT_FOUND');
    await rejects(attendance.registerDay(i, { batchId: CLASS_9A, date: today }), 'NOT_FOUND');
    await rejects(attendance.listSheets(i, { date: today, batchId: CLASS_9A }), 'NOT_FOUND');
    as(PRIYA);
    await rejects(batches.get(i, CLASS_10A), 'NOT_FOUND');
    assert.equal((await attendance.openRoll(i, { batchId: CLASS_9A, date: today })).students.length, 10);
  });

  await check("a teacher cannot save a roll call into another teacher's batch, and nothing is written", async () => {
    as(ROHIT);
    const before = db.attendanceRecords.all(i, { batchId: CLASS_9A }).length;
    const [student] = [...rosterOf(CLASS_9A)];
    await rejects(
      attendance.saveSheet(i, { batchId: CLASS_9A, date: today, records: [{ studentId: student, status: 'absent' }] }),
      'NOT_FOUND',
    );
    assert.equal(db.attendanceRecords.all(i, { batchId: CLASS_9A }).length, before);
    assert.equal(db.attendanceSessions.all(i, { batchId: CLASS_9A }).length, 0);
  });

  await check('teaching a period in a batch does not make it yours: the assignment decides', async () => {
    const rohitTeacher = db.teachers.find(i, { userId: ROHIT });
    assert.ok(rohitTeacher);
    const elsewhere = db.timetables.all(i, { teacherId: rohitTeacher.id }).filter((p) => p.batchId !== CLASS_10A);
    assert.ok(elsewhere.length > 0, 'the seed has Rohit taking periods in other batches');
    as(ROHIT);
    for (const period of elsewhere) await rejects(batches.get(i, period.batchId), 'NOT_FOUND');
    assert.ok((await timetable.listForDay(i, { dayOfWeek: elsewhere[0].dayOfWeek, teacherId: rohitTeacher.id })).length > 0);
  });

  await check('home: today\'s own periods with subject, batch, room, student count and the two numbers', async () => {
    as(ROHIT);
    const home = await analytics.teacherHome(i);
    assert.equal(home.date, today);
    assert.equal(home.classCount, 1);
    assert.equal(home.periods.length, 1, 'the Chemistry period Meera takes in 10-A today is not one of his classes');
    const [period] = home.periods;
    assert.deepEqual(
      [period.batchName, period.subjectName, period.roomName, period.startsAt, period.studentCount, period.period],
      ['Class 10-A', 'Mathematics', 'Room 1', '16:00', 12, 1],
    );
    assert.equal(period.attendanceMarked, true, 'the seed has today\'s roll call for 10-A');
    assert.equal(home.homeworkDue, 2);
    assert.equal(home.submissionsToGrade, 12);
    assert.equal(heroLine(home), '1 class · 2 homework due');
    assert.deepEqual(statsOf(home).map((s) => [s.value, s.label]), [['1', 'Classes today'], ['12', 'Submissions to grade']]);
    const [row] = scheduleRowsOf(home);
    assert.deepEqual([row.clock, row.meridiem, row.title, row.meta], ['4:00', 'PM', 'Mathematics · Class 10-A', 'Room 1 · 12 students']);
    const attention = attentionOf(home);
    assert.equal(attention?.title, '12 submissions to grade');
    assert.equal(attention?.detail, 'Quadratic equations worksheet · Class 10-A');

    as(PRIYA);
    const hers = await analytics.teacherHome(i);
    assert.deepEqual(hers.periods.map((p) => [p.batchName, p.subjectName, p.attendanceMarked]), [['Class 9-A', 'Physics', false]]);
    assert.equal(heroLine(hers), '1 class · 0 homework due');
    assert.equal(hers.submissionsToGrade, 6);

    as(MEERA);
    assert.equal(attentionOf(await analytics.teacherHome(i)), null, 'no pending submissions, no card');
    as(SNEHA);
    const none = await analytics.teacherHome(i);
    assert.equal(none.classCount, 0);
    assert.equal(heroLine(none), 'No classes today · 0 homework due');
  });

  await check('the attendance deep-link opens the correct batch and date', async () => {
    as(ROHIT);
    const home = await analytics.teacherHome(i);
    const { link } = scheduleRowsOf(home)[0];
    assert.equal(link.pathname, '/(teacher)/[batchId]');
    assert.deepEqual(link.params, { batchId: CLASS_10A, date: today, period: '1', subjectId: sid(44) });
    // What the route does with those params, then what the screen loads.
    const params = takeParamsFromRoute(link.params ?? {}, today);
    assert.deepEqual(params, { batchId: CLASS_10A, date: today, period: 1, subjectId: sid(44) });
    const roll = await attendance.openRoll(i, params);
    assert.deepEqual([roll.batchId, roll.batchName, roll.date, roll.subjectName], [CLASS_10A, 'Class 10-A', today, 'Mathematics']);
    assert.equal(roll.students.length, 12);
    assert.ok(roll.existing, 'today is already marked, so the sheet opens in edit mode');

    const card = classCardsOf(await batches.listMyClasses(i), today)[0];
    assert.equal(card.attendanceLink.params?.batchId, CLASS_10A);
    assert.equal(card.attendanceLink.params?.date, today);
    assert.equal(quickActionsOf(home)[0].link.params?.batchId, CLASS_10A);

    // A tampered or stale link never opens a future day, and never someone else's batch.
    assert.equal(takeParamsFromRoute({ batchId: CLASS_10A, date: addDaysIso(today, 3) }, today).date, today);
    assert.equal(takeParamsFromRoute({ batchId: CLASS_10A, date: 'yesterday' }, today).date, today);
    const past = addDaysIso(today, -2);
    assert.equal(takeParamsFromRoute({ batchId: CLASS_10A, date: past }, today).date, past);
    await rejects(attendance.openRoll(i, takeParamsFromRoute({ batchId: CLASS_9A, date: today }, today)), 'NOT_FOUND');
  });

  await check('in period mode the link carries the period\'s ordinal for its batch', async () => {
    // An earlier period today in 10-A, taken by someone else: Rohit's 16:00 class becomes the batch's second.
    as(SEED.ownerId);
    const dayOfWeek = new Date(`${today}T00:00:00Z`).getUTCDay();
    const earlier = await timetable.create(i, {
      batchId: CLASS_10A, dayOfWeek, startsAt: '14:00', endsAt: '15:00', teacherId: sid(4), subjectId: sid(45),
    });
    as(ROHIT);
    const daily = await analytics.teacherHome(i);
    assert.deepEqual(daily.periods.map((p) => [p.startsAt, p.period, p.attendanceMarked]), [['16:00', 1, true]]);

    const institute = db.institutes.get(i, i);
    db.institutes.put({ ...institute, settings: { ...institute.settings, attendanceMode: 'period' } });
    const perPeriod = await analytics.teacherHome(i);
    assert.deepEqual(perPeriod.periods.map((p) => [p.startsAt, p.period, p.attendanceMarked]), [['16:00', 2, false]]);
    assert.equal(scheduleRowsOf(perPeriod)[0].link.params?.period, '2');

    db.institutes.put(institute);
    as(SEED.ownerId);
    await timetable.remove(i, earlier.id);
  });

  await check('the alert card names only students in this teacher\'s batches', async () => {
    as(ROHIT);
    const mine = await progress.listFallingStudents(i);
    const roster10 = rosterOf(CLASS_10A);
    assert.deepEqual(mine.map((s) => s.fullName).sort(), ['Ritesh Mehta', 'Zoya Ahmed']);
    assert.ok(mine.every((s) => s.batchId === CLASS_10A && roster10.has(s.studentId)));
    const rows = alertRowsOf(mine);
    assert.equal(rows[0].reason, 'Attendance fell from 93% to 86%');
    assert.equal(mine[0].signals[0].detail, 'Present for 12 of the last 14 classes, against 13 of the 14 before.');
    as(PRIYA);
    assert.deepEqual(await progress.listFallingStudents(i), [], 'nothing recorded for 9-A yet');
  });

  // Give Class 9-A a history as the owner: four weeks of roll calls in which
  // Arnav stops coming, and two published tests in which Kavya's marks drop.
  const arnav = sid(26);
  const kavya = sid(27);
  const roster9 = [...rosterOf(CLASS_9A)];
  await check('students who start falling in another batch reach that batch\'s teacher only', async () => {
    as(SEED.ownerId);
    for (let day = 28; day >= 1; day -= 1) {
      const absent = day <= 14 && day % 3 === 0; // 4 absences in the latest 14 roll calls, none before
      await attendance.saveSheet(i, {
        batchId: CLASS_9A,
        date: addDaysIso(today, -day),
        records: roster9.map((studentId) => ({ studentId, status: studentId === arnav && absent ? 'absent' : 'present' })),
      });
    }
    const exams = examRepo(db);
    const marks = markRepo(db);
    for (const [name, daysAgo, score] of [['Physics Test 1', 20, 40], ['Physics Test 2', 6, 31]] as const) {
      const exam = await exams.create(i, {
        batchId: CLASS_9A, name, subjectId: sid(45), totalMarks: 50, startsOn: addDaysIso(today, -daysAgo),
      });
      await marks.saveMany(i, exam.id, roster9.map((studentId) => ({
        studentId, subjectId: sid(45), maxMarks: 50, marksObtained: studentId === kavya ? score : 40,
      })));
      await exams.publish(i, exam.id);
    }

    as(PRIYA);
    const hers = await progress.listFallingStudents(i);
    assert.deepEqual(hers.map((s) => s.fullName).sort(), ['Arnav Mehta', 'Kavya Reddy']);
    assert.ok(hers.every((s) => s.batchId === CLASS_9A && roster9.includes(s.studentId)));
    const byName = new Map(hers.map((s) => [s.fullName, s.signals[0]]));
    assert.deepEqual([byName.get('Arnav Mehta')?.kind, byName.get('Arnav Mehta')?.reason], ['attendance', 'Attendance fell from 100% to 71%']);
    assert.deepEqual([byName.get('Kavya Reddy')?.kind, byName.get('Kavya Reddy')?.reason], ['marks', 'Marks fell from 80% to 62%']);
    assert.equal(hers[0].fullName, 'Arnav Mehta', 'the biggest drop comes first');

    as(ROHIT);
    const his = await progress.listFallingStudents(i);
    assert.deepEqual(his.map((s) => s.fullName).sort(), ['Ritesh Mehta', 'Zoya Ahmed'], 'Rohit still sees only 10-A');
    assert.ok(his.every((s) => !roster9.includes(s.studentId)));

    as(SEED.ownerId);
    assert.equal((await progress.listFallingStudents(i)).length, 4, 'the owner sees every batch');
    as(SEED.studentIds[0]);
    await rejects(progress.listFallingStudents(i), 'FORBIDDEN');
    await rejects(analytics.teacherHome(i), 'FORBIDDEN');
    as(null);
    await rejects(progress.listFallingStudents(i), 'UNAUTHENTICATED');
    await rejects(batches.listMyClasses(i), 'UNAUTHENTICATED');
  });

  await check('a drop smaller than the rule, or too few roll calls, is not an alert', async () => {
    assert.deepEqual(
      [FALLING_RULES.ATTENDANCE_WINDOW, FALLING_RULES.ATTENDANCE_MIN_RECORDS, FALLING_RULES.ATTENDANCE_DROP, FALLING_RULES.MARKS_DROP],
      [14, 5, 5, 10],
    );
    as(MEERA);
    const roster11 = [...rosterOf(CLASS_11A)];
    // Four roll calls only: one student absent for all of the latest two. Not enough history to call it a trend.
    for (let day = 4; day >= 1; day -= 1) {
      await attendance.saveSheet(i, {
        batchId: CLASS_11A,
        date: addDaysIso(today, -day),
        records: roster11.map((studentId, n) => ({ studentId, status: n === 0 && day <= 2 ? 'absent' : 'present' })),
      });
    }
    assert.deepEqual(await progress.listFallingStudents(i), []);
  });

  await check('class cards: schedule, room, attendance bar and the submissions-pending pill', async () => {
    as(ROHIT);
    const [card] = classCardsOf(await batches.listMyClasses(i), today);
    assert.equal(card.name, 'Class 10-A');
    assert.equal(card.subject, 'Mathematics');
    assert.ok(card.schedule.endsWith('· 4:00 PM – 5:00 PM'), card.schedule);
    assert.equal(card.place, 'Room 1 · 12 students');
    assert.equal(card.pendingLabel, '12 submissions pending');
    // The bar is the batch's own records, the same figure the owner's batch card shows.
    as(SEED.ownerId);
    const owner = (await batches.listSummaries(i)).find((b) => b.id === CLASS_10A);
    assert.equal(card.attendanceValue, owner?.attendancePct);
    assert.equal(card.attendanceLabel, '92%');
    assert.equal(owner?.teacherName, 'Rohit Verma', 'the owner card names the same assigned teacher');

    as(SNEHA);
    assert.deepEqual(classCardsOf(await batches.listMyClasses(i), today), []);
    assert.equal(daysLabel([1, 2, 3, 4, 5]), 'Mon – Fri');
    assert.equal(daysLabel([5, 1, 3]), 'Mon, Wed, Fri');
    assert.equal(daysLabel([0, 6]), 'Sat, Sun');
    assert.equal(daysLabel([]), 'No days set');
  });

  await check('a class with no roll call shows a dash, not 0%; header search narrows the cards', async () => {
    const fresh = createDb();
    seed(fresh);
    fresh.session.userId = PRIYA;
    const [card] = classCardsOf(await batchRepo(fresh).listMyClasses(i), today);
    assert.equal(card.attendanceValue, null);
    assert.equal(card.attendanceLabel, '—');
    assert.equal(card.pendingLabel, '6 submissions pending');
    assert.equal(filterClasses([card], 'physics').length, 1);
    assert.equal(filterClasses([card], 'room 2').length, 1);
    assert.equal(filterClasses([card], '  9-A  PHYS ').length, 1);
    assert.equal(filterClasses([card], 'maths').length, 0);
    assert.equal(filterClasses([card], '').length, 1);
  });

  await check('grading a submission lowers the count on the home and on the class card together', async () => {
    as(ROHIT);
    const waiting = db.submissions.all(i, { batchId: CLASS_10A, status: 'submitted' });
    assert.equal(waiting.length, 12);
    await submissionRepo(db).grade(i, waiting[0].id, { marksAwarded: 20 });
    assert.equal((await analytics.teacherHome(i)).submissionsToGrade, 11);
    assert.equal((await batches.listMyClasses(i))[0].pendingSubmissions, 11);
    as(PRIYA);
    assert.equal((await analytics.teacherHome(i)).submissionsToGrade, 6, 'another teacher\'s count does not move');
  });

  await check('reassigning a batch moves it between class lists', async () => {
    as(SEED.ownerId);
    const rohitTeacher = db.teachers.find(i, { userId: ROHIT });
    await batches.update(i, CLASS_11A, { teacherId: rohitTeacher?.id });
    as(ROHIT);
    assert.deepEqual(names(await batches.listMyClasses(i)), ['Class 10-A', 'Class 11-A']);
    assert.equal((await batches.get(i, CLASS_11A)).name, 'Class 11-A');
    as(MEERA);
    assert.deepEqual(await batches.listMyClasses(i), []);
    await rejects(batches.get(i, CLASS_11A), 'NOT_FOUND');
    await rejects(attendance.openRoll(i, { batchId: CLASS_11A, date: today }), 'NOT_FOUND');
  });

  await check('another institute is invisible; an older snapshot is topped up once', async () => {
    as(ROHIT);
    await rejects(analytics.teacherHome(sid(777)), 'NOT_FOUND');
    await rejects(batches.get(sid(777), CLASS_10A), 'NOT_FOUND');

    // A snapshot saved before this change: no class teacher on the batches, no homework.
    const old = createDb();
    seed(old);
    for (const batch of old.batches.all(i)) old.batches.put({ ...batch, teacherId: undefined });
    for (const row of old.assignments.all(i)) old.assignments.remove(i, row.id);
    for (const row of old.submissions.all(i)) old.submissions.remove(i, row.id);
    old.session.userId = ROHIT;
    assert.deepEqual(names(await batchRepo(old).listMyClasses(i)), ['Class 10-A'], 'falls back to the first period, like migration 0009');
    ensureHomework(old);
    ensureHomework(old);
    assert.equal(old.batches.get(i, CLASS_10A).teacherId, sid(3));
    assert.equal(old.assignments.all(i).length, 6);
    assert.equal((await analyticsRepo(old).teacherHome(i)).submissionsToGrade, 12);
  });

  console.log(`\n${passed} checks passed`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
