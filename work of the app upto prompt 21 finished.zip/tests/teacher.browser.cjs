const { chromium } = require('@playwright/test');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');

// Drives the exported web build (`npm run build` first) as two teachers.
const root = path.join(process.cwd(), 'dist');
const shots = path.join(process.cwd(), '.shots');
const types = { '.html': 'text/html', '.js': 'application/javascript', '.css': 'text/css', '.ttf': 'font/ttf', '.png': 'image/png' };
const server = http.createServer((req, res) => {
  let file = path.join(root, decodeURIComponent(req.url.split('?')[0]));
  if (!file.startsWith(root)) { res.writeHead(403).end(); return; }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(root, 'index.html');
  res.setHeader('Content-Type', types[path.extname(file)] || 'application/octet-stream');
  fs.createReadStream(file).pipe(res);
}).listen(8131);

const BASE = 'http://localhost:8131';
const CLASS_10A = '00000000-0000-4000-8000-000000000009';
const CLASS_9A = '00000000-0000-4000-8000-000000000010';
const today = new Date().toISOString().slice(0, 10);
const tab = (page, label) => page.getByRole('tab', { name: label, exact: true });
const step = (msg) => console.log(`PASS: ${msg}`);
const seen = (page, text, timeout = 15000) => page.getByText(text, { exact: true }).first().waitFor({ state: 'visible', timeout });
const visible = (page, text) => page.getByText(text, { exact: true }).first().isVisible().catch(() => false);
async function shot(page, name) {
  fs.mkdirSync(shots, { recursive: true });
  await page.screenshot({ path: path.join(shots, `teacher-${name}.png`) });
}

/** Signs in from the login screen. `pill` taps a demo pill; otherwise the address is typed. */
async function signIn(page, { pill, email }) {
  const skip = page.getByText('Skip', { exact: true });
  await skip.waitFor({ state: 'visible', timeout: 15000 }).catch(() => {});
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.locator('input[type="password"]').first().waitFor({ state: 'visible', timeout: 30000 });
  if (pill) await page.getByText(pill, { exact: true }).click();
  else {
    await page.locator('input:not([type="password"])').first().fill(email);
    await page.locator('input[type="password"]').first().fill('demo1234');
  }
  await page.getByRole('button', { name: 'Sign in', exact: true }).click();
  await page.getByText('Enter code', { exact: true }).waitFor({ state: 'visible', timeout: 30000 });
  await page.locator('input:visible').first().click();
  await page.keyboard.type('123456', { delay: 60 });
  await page.getByRole('button', { name: 'Verify', exact: true }).click();
  await tab(page, 'Classes').waitFor({ state: 'visible', timeout: 30000 });
}

/** In-app navigation to a typed URL: a reload would drop the reference backend's session. */
async function go(page, url) {
  await page.evaluate((to) => {
    window.history.pushState({}, '', to);
    window.dispatchEvent(new PopStateEvent('popstate', { state: {} }));
  }, url);
}

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  const page = await browser.newPage({ viewport: { width: 400, height: 860 } });
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));

  try {
    await page.goto(`${BASE}/`);
    await signIn(page, { pill: 'Teacher' });
    step('the Teacher demo pill signs in and lands on the teacher shell');

    // ---- Home, as Rohit Verma (assigned teacher of Class 10-A) ----
    await page.getByText(/^Good (morning|afternoon|evening), Rohit$/).waitFor({ timeout: 20000 });
    for (const text of [
      '1 class · 2 homework due', 'Classes today', 'Submissions to grade', "Today's schedule",
      'Mathematics', 'Class 10-A', 'Room 1 · 12 students', 'Needs attention', '12 submissions to grade',
      'Quadratic equations worksheet · Class 10-A', 'Student alerts', 'Ritesh Mehta', 'Zoya Ahmed',
      'Take attendance', 'Assign homework', 'Enter marks', 'Share material',
    ]) await seen(page, text);
    step('home shows the hero, the two numbers, the schedule row, needs attention, alerts and four quick actions');
    await shot(page, '1-home');
    await page.evaluate(() => document.querySelectorAll('*').forEach((el) => { if (el.scrollHeight > el.clientHeight + 40) el.scrollTop = el.scrollHeight; }));
    await shot(page, '2-home-lower');

    const body = await page.locator('body').innerText();
    assert.equal(await page.getByLabel('Mathematics · Class 10-A. Room 1 · 12 students').count(), 1);
    for (const other of ['Arnav Mehta', 'Kavya Reddy', 'Class 9-A', 'Class 11-A', 'Aryan Kapoor']) {
      assert.ok(!body.includes(other), `home must not mention ${other}`);
    }
    assert.match(body, /Attendance fell from 93% to 86%/);
    step("the alert card names only Class 10-A students, each with a one-line reason");

    await page.getByRole('link', { name: 'View Ritesh Mehta' }).click();
    await seen(page, 'Class 10-A · Roll 18');
    await seen(page, 'Present for 12 of the last 14 classes, against 13 of the 14 before.');
    await page.waitForTimeout(700);
    await shot(page, '3-alert-sheet');
    await page.getByRole('button', { name: 'Open attendance for Class 10-A' }).click();
    await page.getByText('Editing saved sheet').waitFor({ timeout: 20000 });
    assert.ok(new URL(page.url()).pathname.endsWith(CLASS_10A));
    step('"View" opens the student, and its attendance button opens that student\'s batch');
    await page.getByRole('button', { name: 'Back' }).click();
    await seen(page, "Today's schedule");

    // ---- The schedule row's Attendance button ----
    await page.getByRole('button', { name: /^Attendance for Class 10-A/ }).click();
    await page.getByText('Editing saved sheet').waitFor({ timeout: 20000 });
    let url = new URL(page.url());
    assert.ok(url.pathname.endsWith(`/${CLASS_10A}`), url.pathname);
    assert.equal(url.searchParams.get('date'), today);
    assert.equal(url.searchParams.get('period'), '1');
    await seen(page, 'Class 10-A · Mathematics');
    await seen(page, 'Today');
    assert.equal(await page.getByRole('button', { name: /roll \d+/ }).count(), 12, '12 tiles for 12 students');
    assert.equal(await tab(page, 'Classes').count(), 0, 'no tab bar on the full-screen register');
    assert.equal(await page.getByRole('button', { name: 'Open the monthly register' }).count(), 0);
    step(`the attendance deep-link opens the right batch and date (${url.pathname}${url.search})`);
    await shot(page, '4-attendance');
    await page.getByRole('button', { name: 'Back' }).click();
    await seen(page, "Today's schedule");

    // ---- My Classes ----
    await tab(page, 'Classes').click();
    for (const text of ['My classes', '1 class', 'Class 10-A', 'Mathematics', 'Room 1 · 12 students', '92%', '12 submissions pending']) {
      await seen(page, text);
    }
    await page.getByText(/· 4:00 PM – 5:00 PM$/).waitFor({ timeout: 10000 });
    assert.equal(await visible(page, 'Class 9-A'), false);
    assert.equal(await visible(page, 'Class 11-A'), false);
    step('My Classes lists Class 10-A only, with schedule, room, attendance % and the pending pill');
    await shot(page, '5-classes');

    const search = page.getByPlaceholder('Search by class, subject or room');
    await search.fill('physics');
    await seen(page, 'No class matches');
    await search.fill('10-a math');
    await seen(page, '12 submissions pending');
    await search.fill('');
    step('header search narrows the cards and recovers');

    await page.getByRole('button', { name: 'Homework for Class 10-A' }).click();
    await page.waitForFunction((id) => location.search.includes(id), CLASS_10A, { timeout: 10000 });
    assert.match(new URL(page.url()).pathname, /homework/);
    step('the Homework button opens the Homework tab with the batch prefilled');
    await tab(page, 'Classes').click();
    await page.getByRole('button', { name: 'Attendance for Class 10-A' }).click();
    await page.getByText('Editing saved sheet').waitFor({ timeout: 20000 });
    url = new URL(page.url());
    assert.ok(url.pathname.endsWith(`/${CLASS_10A}`));
    assert.equal(url.searchParams.get('date'), today);
    step('the card\'s Attendance button opens the same batch for today');

    // ---- Another teacher's batch id ----
    await go(page, `/${CLASS_9A}?date=${today}&period=1`);
    await seen(page, 'Class not found');
    assert.equal(await page.getByRole('button', { name: /roll \d+/ }).count(), 0, 'no student of 9-A is shown');
    step("another teacher's batch id shows \"Class not found\"");
    await shot(page, '6-not-found');
    await page.getByRole('button', { name: 'Go back' }).click();

    // ---- A second teacher account ----
    await tab(page, 'Home').waitFor({ state: 'visible', timeout: 20000 });
    await page.getByRole('button', { name: 'Sign out' }).click();
    await signIn(page, { email: 'priya.nair@sunrise.test' });
    await page.getByText(/^Good (morning|afternoon|evening), Priya$/).waitFor({ timeout: 20000 });
    for (const text of ['1 class · 0 homework due', 'Physics', 'Class 9-A', 'Room 2 · 10 students', '6 submissions to grade']) {
      await seen(page, text);
    }
    const hers = await page.locator('body').innerText();
    for (const other of ['Class 10-A', 'Ritesh Mehta', 'Zoya Ahmed', 'Student alerts']) {
      assert.ok(!hers.includes(other), `Priya's home must not mention ${other}`);
    }
    await shot(page, '7-second-teacher-home');
    await tab(page, 'Classes').click();
    await seen(page, 'Class 9-A');
    await seen(page, '6 submissions pending');
    assert.equal(await visible(page, 'Class 10-A'), false);
    step('a second teacher account sees a different class list and a different home');
    await shot(page, '8-second-teacher-classes');

    // She takes her own roll call from the deep link; the home row then shows it as marked.
    await tab(page, 'Home').click();
    await page.getByRole('button', { name: 'Take attendance for Class 9-A' }).click();
    await seen(page, 'Class 9-A · Physics');
    assert.ok(new URL(page.url()).pathname.endsWith(`/${CLASS_9A}`));
    await page.getByRole('button', { name: /^Arnav Mehta, roll/ }).click();
    await page.getByRole('button', { name: /Save attendance/ }).click();
    await page.getByText(/Attendance saved/).waitFor({ timeout: 15000 });
    await page.getByRole('button', { name: 'Back' }).click();
    await page.getByRole('button', { name: 'Attendance for Class 9-A, already marked' }).waitFor({ timeout: 15000 });
    step('saving her roll call marks the period on her home without a reload');

    assert.deepEqual(errors, []);
    step('no runtime errors');
  } catch (error) {
    await shot(page, 'failure').catch(() => {});
    console.error(error);
    process.exitCode = 1;
  } finally {
    await browser.close();
    server.closeAllConnections?.();
    server.close();
  }
})();
