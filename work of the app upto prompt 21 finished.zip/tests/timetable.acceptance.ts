import assert from 'node:assert/strict';
import { createDb } from '../src/backends/memory/db';
import { seed, SEED } from '../src/backends/memory/seed';
import { batchRepo, subjectRepo, timetableRepo } from '../src/backends/memory/academics';
import { staffRepo } from '../src/backends/memory/people';
import { capture, restore } from '../src/backends/memory/persist';
import type { Timetable } from '../src/core/contracts/models';
import {
  buildRows,
  dayOfWeekOf,
  diffPeriods,
  findClashes,
  makeNames,
  moveToDay,
  reorderDay,
  sortDay,
  touchedDays,
  todayIso,
} from '../src/features/timetable/model';

type Clashes = ReturnType<typeof findClashes>;

/**
 * The screen's save rule, restated: diff the draft against the base, and if a
 * teacher clash sits on any day the change touches, the save is blocked.
 */
function wouldBlock(base: Timetable[], draft: Timetable[], names: ReturnType<typeof makeNames>): boolean {
  const changes = diffPeriods(base, draft);
  if (changes.length === 0) return false;
  const days = touchedDays(base, changes);
  return findClashes(draft, names).teacher.some((c) => days.has(c.dayOfWeek));
}

async function main() {
  const db = createDb();
  seed(db);
  const repo = timetableRepo(db);
  const i = SEED.instituteId;
  const dow = dayOfWeekOf(todayIso());
  /** The seed's weekday list: today first, then Mon–Fri. Index 1 is "di = 1". */
  const seededDays = [...new Set([dow, 1, 2, 3, 4, 5])];
  const diOneDay = seededDays[1] as number;
  /** A weekday that is not today: exactly three first periods, no overlaps. */
  const cleanDay = ([1, 2, 3, 4, 5] as number[]).find((d) => d !== dow) as number;
  /** A day the seed never schedules — the resolved clash can park a period there. */
  const quietDay = dow === 6 ? 0 : 6;

  const load = async (): Promise<Timetable[]> => (await repo.list(i, { limit: 200 })).items;
  const names = makeNames({
    periods: await load(),
    batches: (await batchRepo(db).list(i, { limit: 50 })).items,
    subjects: (await subjectRepo(db).list(i, { limit: 50 })).items,
    teachers: (await staffRepo(db).listTeachers(i, { limit: 50 })).items,
    classrooms: await repo.listClassrooms(i),
  });

  let periods = await load();
  assert.ok(periods.length >= 18, 'the seed fills the week');
  assert.equal(findClashes(periods, names).room.length, 0, 'the seed has no room clash');
  assert.equal(periods.filter((p) => p.dayOfWeek === quietDay).length, 0, 'the quiet day is empty');

  // ---- 1. The seeded clash is detected on load and named ------------------
  // Today's second periods put Meera Iyer on Class 10-A 17:15–18:15 and
  // Class 11-A 18:00–19:00 — a real overlap the board must surface at once.
  const seedClash = findClashes(periods, names).teacher.find((c) => c.dayOfWeek === dow);
  assert.ok(seedClash, "today's seeded overlap is detected");
  assert.equal(seedClash.teacherName, 'Meera Iyer', 'the card names the teacher');
  assert.deepEqual(
    [seedClash.a.batchName, seedClash.b.batchName].sort(),
    ['Class 10-A', 'Class 11-A'],
    'the card names both batches',
  );
  console.log('PASS: the seeded teacher clash is detected and names both batches and the teacher.');

  // ---- 2. A deliberate teacher clash blocks the save ----------------------
  // Class 9-A's 17:00 period on the di=1 day is taught by Meera; dropping it
  // on today overlaps her 17:15 second period.
  const batch9A = periods.find((p) => p.dayOfWeek === dow && p.startsAt === '17:00')?.batchId;
  assert.ok(batch9A, "Class 9-A's first period is on today's weekday");
  const clashPeriod = periods.find(
    (p) => p.dayOfWeek === diOneDay && p.batchId === batch9A && p.startsAt === '17:00',
  );
  assert.ok(clashPeriod, 'the same batch meets on the di=1 day');
  const clashDraft = moveToDay(periods, clashPeriod.id, dow);
  assert.ok(wouldBlock(periods, clashDraft, names), 'moving into a teacher overlap blocks the save');
  const clash = findClashes(clashDraft, names).teacher.find(
    (c) => c.a.periodId === clashPeriod.id || c.b.periodId === clashPeriod.id,
  ) as Clashes['teacher'][number] | undefined;
  assert.ok(clash, 'the new clash is the one reported');
  assert.equal(clash.teacherName, 'Meera Iyer');
  assert.deepEqual(
    [clash.a.batchName, clash.b.batchName].sort(),
    ['Class 10-A', 'Class 9-A'],
  );
  // The screen does not write while blocked:
  assert.equal((await repo.get(i, clashPeriod.id)).dayOfWeek, diOneDay, 'nothing was saved while blocked');
  console.log('PASS: a deliberate teacher clash blocks the save and names both batches and the teacher.');

  // ---- 3. Removing the clash clears the warning ---------------------------
  const undone = moveToDay(clashDraft, clashPeriod.id, diOneDay);
  assert.equal(diffPeriods(periods, undone).length, 0, 'dragging it back leaves nothing to save');
  assert.equal(
    findClashes(undone, names).teacher.some((c) => c.a.periodId === clashPeriod.id || c.b.periodId === clashPeriod.id),
    false,
    'the deliberate clash warning is gone',
  );
  // Resolve the seeded clash too: park Class 11-A's 18:00 period on the quiet day.
  const meera = [...names.teacher.entries()].find(([, name]) => name === 'Meera Iyer')?.[0];
  assert.ok(meera);
  const meeraFirst = periods.find((p) => p.dayOfWeek === dow && p.teacherId === meera && p.startsAt === '18:00');
  assert.ok(meeraFirst);
  const resolved = moveToDay(periods, meeraFirst.id, quietDay);
  assert.equal(findClashes(resolved, names).teacher.length, 0, 'no teacher clash remains');
  assert.equal(wouldBlock(periods, resolved, names), false, 'the fix is savable');
  for (const change of diffPeriods(periods, resolved)) await repo.update(i, change.id, change.patch);
  periods = await load();
  assert.equal(findClashes(periods, names).teacher.length, 0, 'the saved week is clean');
  console.log('PASS: removing the clash clears the warning and the fix saves.');

  // ---- 4. A room clash is a softer warning: detected, but it saves --------
  // Class 10-A meets in Room 1 at 16:00 on every seeded day. Moving the clean
  // day's 16:00 period onto today double-books Room 1 — different teachers, so
  // it is a warning only, and the save gate stays open.
  const roomMate = periods.find((p) => p.dayOfWeek === cleanDay && p.startsAt === '16:00' && p.batchId === SEED.batchId);
  assert.ok(roomMate);
  const roomDraft = moveToDay(periods, roomMate.id, dow);
  const roomClash = findClashes(roomDraft, names).room.find(
    (c) => c.a.periodId === roomMate.id || c.b.periodId === roomMate.id,
  );
  assert.ok(roomClash, 'the double-booked room is detected');
  assert.equal(roomClash.roomName, 'Room 1');
  assert.equal(
    findClashes(roomDraft, names).teacher.some((c) => c.a.periodId === roomMate.id || c.b.periodId === roomMate.id),
    false,
    'different teachers — no hard clash',
  );
  assert.equal(wouldBlock(periods, roomDraft, names), false, 'a room clash never blocks the save');
  console.log('PASS: room clash (Room 1) warns softly and does not block.');

  // ---- 5. Reorder a clean day, save, and survive a reload -----------------
  const cleanRows = sortDay(periods.filter((p) => p.dayOfWeek === cleanDay));
  assert.equal(cleanRows.length, 3);
  const dragged = cleanRows[0];
  const reordered = reorderDay(periods, cleanDay, dragged.id, 3);
  assert.equal(wouldBlock(periods, reordered, names), false, 'a clean reorder is not blocked');
  const changes = diffPeriods(periods, reordered);
  assert.equal(changes.length, 3, 'every period keeps a slot, the slots change hands');
  for (const change of changes) await repo.update(i, change.id, change.patch);
  periods = await load();
  const afterSave = sortDay(periods.filter((p) => p.dayOfWeek === cleanDay));
  assert.deepEqual(afterSave.map((p) => p.id), [cleanRows[1].id, cleanRows[2].id, dragged.id]);
  assert.equal(afterSave[2].startsAt, '18:00', 'the dragged period took the last slot');

  const snapshot = capture(db);
  const db2 = createDb();
  assert.ok(restore(db2, snapshot), 'the snapshot restores');
  const reloaded = sortDay(
    (await timetableRepo(db2).list(i, { limit: 200 })).items.filter((p) => p.dayOfWeek === cleanDay),
  );
  assert.deepEqual(reloaded.map((p) => p.id), afterSave.map((p) => p.id), 'the reorder persists after a reload');
  console.log('PASS: reordering saves, and the snapshot restore still has the new order.');

  // ---- 6. The teacher reads the same table --------------------------------
  const moved = await repo.get(i, dragged.id);
  assert.equal(moved.startsAt, '18:00');
  const teacherDay = await repo.listForDay(i, { dayOfWeek: cleanDay, teacherId: moved.teacherId as string });
  const boardDay = sortDay(periods.filter((p) => p.dayOfWeek === cleanDay && p.teacherId === moved.teacherId));
  assert.deepEqual(teacherDay.map((p) => p.id), boardDay.map((p) => p.id), 'listForDay reads the owner\u2019s rows');
  assert.equal(
    teacherDay.find((p) => p.id === dragged.id)?.startsAt,
    '18:00',
    "the teacher sees the owner's reorder",
  );
  const teacherRows = buildRows(teacherDay, names, 'teacher');
  const ownerRows = buildRows(boardDay, names, 'owner');
  assert.deepEqual(
    teacherRows.map((r) => [r.id, r.range]),
    ownerRows.map((r) => [r.id, r.range]),
    'same rows, same times, one table',
  );
  console.log('PASS: the teacher\u2019s day is the same table — the reorder shows in their app.');

  // ---- 7. Tenant isolation -------------------------------------------------
  assert.equal((await repo.list('other-tenant', { limit: 200 })).items.length, 0);
  await assert.rejects(() => repo.get('other-tenant', dragged.id));
  console.log('PASS: tenant isolation.');
}

main().catch((e: unknown) => {
  console.error(e);
  process.exitCode = 1;
});
